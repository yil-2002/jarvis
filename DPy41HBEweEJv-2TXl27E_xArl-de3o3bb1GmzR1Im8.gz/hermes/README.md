# Hermes-Prime — MoE Multi-Model Router

A production-grade runtime for the **Hermes-Prime** agent: a Mixture-of-Experts router that
sends each request to the cheapest model capable of handling it, backs the model with
schema-guarded tools, and keeps long conversations cheap by compressing memory into
SQLite fact-triplets.

```
Tier 1  Planning & routing    Groq 120B          ultra-low latency, JSON tool-calling, plans
Tier 2  Deep cognition        Llama 3.1 405B     algorithms, architecture, debugging, proofs
Tier 3  Multimodal / heavy    Gemini             vision, >100k-token docs, bulk logs
```

The router itself never touches Tier 2/3, so routing cost stays near zero. Heavy formatting
and inference are offloaded to the model APIs — the host VPS only does I/O, validation and
SQLite writes.

---

## Layout

```
hermes/
├── main.py                     # CLI / single-shot runner
├── server.py                   # aiohttp HTTP service + Telegram webhook (the deployable backend)
├── requirements.txt
├── pyproject.toml              # packaging + console scripts (hermes, hermes-server, hermes-telegram)
├── Dockerfile                  # slim, non-root, read-only-FS-ready container
├── .env.example
├── prompts/
│   └── HERMES_CORE_SYSTEM.md   # system prompt + tool-calling JSON Schema contract
├── deploy/
│   ├── hermes.service          # hardened systemd unit for the Hetzner VPS
│   ├── install.sh              # idempotent one-shot VPS install
│   └── nginx-hermes.conf       # TLS termination + reverse proxy + webhook IP allowlist & rate limit
├── hermes/
│   ├── config.py               # typed settings, model profiles, retry policies, TelegramConfig
│   ├── schemas.py              # JSON Schemas: tools, router decision, triplets, envelope
│   ├── llm.py                  # async client: retries, circuit breaker, tier failover
│   ├── router.py               # heuristics + Tier-1 LLM classifier + compressor
│   ├── tools.py                # web_search, web_fetch, python_exec, sql_query, memory_recall
│   ├── memory.py               # SQLite (WAL) store, FTS5 recall, compression, spend_ledger
│   ├── documents.py            # uploaded-file text extraction (UTF-8 + pypdf), size/type guards
│   ├── telegram.py             # Bot API client (transport seam) + file download/upload + webhook CLI
│   ├── voice.py                # STT (Gemini via Tier-3) + TTS (edge-tts) client (transport seam)
│   └── orchestrator.py         # the agentic tool loop (+ fire-and-forget compression, budget cap)
├── docs/architecture.svg       # system diagram
└── tests/
    ├── fake_transport.py       # test-only scripted LLM + Telegram + voice (never used in prod)
    ├── test_hermes.py          # 43 unit + e2e + adversarial security + concurrency + budget cases
    ├── test_server.py          # 19 HTTP cases (endpoints, validation, CORS, budget 429)
    ├── test_resilience.py      # 25 resilience cases (retries, breaker, failover, escalation)
    ├── test_telegram.py        # 42 Telegram cases (client, split, webhook auth/dedup/delivery, whitelist, documents, voice STT/TTS)
    ├── test_voice.py           # 30 voice cases (truncate_for_speech, VoiceConfig policy, VoiceClient guards, Gemini STT, edge-tts TTS, VoiceError)
    └── test_documents.py       # 14 document-ingestion cases (text/PDF extraction, size/type guards, read-only-FS guard)
```

---

## Quick start

```bash
cd hermes
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env && chmod 600 .env      # then fill in your keys
set -a; source .env; set +a

# Self-test with NO credentials and NO network (scripted transport):
python main.py --offline --trace "Design a distributed rate limiter architecture"

# Real run:
python main.py "Refactor this FastAPI service to use async SQLAlchemy 2.0"
python main.py --session proj42 --stdin < big_logs.txt   # heavy context -> Tier 3
```

Run the test suite:

```bash
python -m pytest -q                # 173 cases (43 library + 19 HTTP + 25 resilience + 42 telegram + 30 voice + 14 documents), unified
python -m tests.test_hermes        # built-in library runner, 43 cases
python -m tests.test_server        # built-in HTTP runner, 19 cases
python -m tests.test_resilience    # built-in resilience runner, 25 cases
python -m tests.test_telegram      # built-in telegram runner, 42 cases
python -m tests.test_voice         # built-in voice runner, 30 cases
python -m tests.test_documents     # built-in document-ingestion runner, 14 cases
```

---

## How a request flows

1. **Route.** Hard rules fire first (any image → Tier 3; ≥100k tokens → Tier 3). Otherwise
   lexical/structural heuristics produce a candidate tier + confidence. If
   `HERMES_LLM_ROUTING=true`, a Tier-1 classifier refines the decision — but only wins when its
   confidence ≥ `HERMES_ROUTER_FLOOR`. The decision is validated against `ROUTER_DECISION_SCHEMA`.
2. **Assemble context.** System prompt + a rendered memory preamble (recent summaries + top
   triplets) + the last N raw messages.
3. **Tool loop.** The chosen model is called with only the tools the router allowed. Each
   `tool_call`'s arguments are validated against its JSON Schema before execution. Results come
   back as a fixed envelope and are fed to the model. The loop is bounded by `HERMES_MAX_STEPS`.
4. **Answer & persist.** The final text is stored. If the uncompressed message count crosses
   `HERMES_COMPRESS_EVERY`, the oldest window is folded into a summary + fact-triplets by a
   Tier-1 call (with a deterministic extractive fallback if that call fails).

---

## HTTP service

The deployable backend. Run it locally (offline self-test, no keys):

```bash
python server.py --offline --host 0.0.0.0 --port 8081
```

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/healthz` | liveness — no upstream calls |
| `GET` | `/readyz` | readiness — DB reachable + which tier keys are present |
| `GET` | `/metrics` | Prometheus-style counters from the audit log (per-tier, per-step, failures, avg latency) |
| `GET` | `/v1/models` | configured tier → model map, failover chains, tool list |
| `POST` | `/v1/route` | **dry-run the router only** — inspect tier selection & plan without paying for an answer |
| `POST` | `/v1/chat` | full agent run |
| `POST` | `/webhook/telegram` | Telegram Bot API webhook (authenticated, fast-ack + background) — see [Telegram bot](#telegram-bot-webhook) |

`POST /v1/chat` request:

```json
{
  "message": "Design a distributed rate limiter for a multi-tenant gateway",
  "session_id": "proj42",
  "image_urls": [],
  "attachments": 0,
  "tools": null
}
```

Response is the `AgentResponse` (answer + tier + model + intent + plan + per-step trace +
token usage + latency + any error envelopes). Memory compression runs as a **background task**
here, so it never adds latency to the HTTP response.

```bash
curl -s localhost:8081/v1/route -H 'Content-Type: application/json' \
  -d '{"message":"Prove the complexity of Dijkstra with a Fibonacci heap"}'
# -> {"ok":true,"decision":{"tier":"tier2_deep","confidence":0.84,...}}
```

Validation is strict: empty/oversized `message` → `422`/`413`, malformed JSON → `400`,
wrong `tools`/`image_urls` types → `422`, upstream LLM failure → `502` with the real
error payload + fallback. CORS preflight (`OPTIONS`) is handled; set `HERMES_CORS_ORIGIN`
to lock it down.

---

## Telegram bot (webhook)

The backend doubles as a Telegram bot over a **webhook** (no polling, no extra
process, no long-lived connection — Telegram pushes each update to nginx, which
proxies it to `server.py`). This is the lowest-memory way to run the agent on a
small VPS.

```
Telegram user ──HTTPS──> nginx (TLS, rate-limit) ──> 127.0.0.1:8081/webhook/telegram
                                                            │  verify secret → dedup → fast-ack 200
                                                            ▼  (background task)
                                              HermesOrchestrator.handle() → MoE router
                                                            │  T1 Groq / T2 Llama 405B / T3 Gemini
                                                            ▼
                                              sendMessage (chunked, typing indicator)
```

### Why not the naive handler

A straightforward "await the agent, then reply" webhook breaks in production. The
shipped handler fixes each failure mode:

| Naive approach | Shipped behaviour |
|---|---|
| Await the full agent run before answering | **Fast-ack 200**, run in a background task — Telegram retries any webhook that doesn't answer in a few seconds, which would duplicate every long Tier-2/3 answer |
| Trust whoever hits the URL | **Secret-token auth** — Telegram echoes `X-Telegram-Bot-Api-Secret-Token`; constant-time compare, `403` on mismatch (stops credit burn if the URL leaks) |
| Process every delivery once | **`update_id` dedup** (bounded LRU) — Telegram retries are dropped, not re-run |
| One `sendMessage` | **4096-char chunking** on paragraph/line/word boundaries — deep answers don't silently vanish |
| `parse_mode="Markdown"`, hope for the best | **Plain-text fallback** — a 400 "can't parse entities" (unbalanced `*`/`_` in model output) is retried once without `parse_mode` so the user always gets the answer |
| Fire-and-forget `ClientSession` per call | **Shared session**, `429` honours `retry_after`, every failure raises `TelegramError` with the exact payload + fallback (never a fabricated success) |
| Unbounded concurrency | **Semaphore** (`HERMES_TELEGRAM_MAX_CONCURRENT`) — a message burst can't exhaust the VPS |
| One `sendChatAction("typing")`, then silence | **Typing heartbeat** — Telegram expires the indicator after ~5s, but a Tier-2/3 run takes 15–40s; `_keep_typing` re-sends every `HERMES_TELEGRAM_TYPING_REFRESH` (default 4s) so the bot never looks frozen |
| `systemctl restart` kills in-flight answers | **Graceful drain** — on SIGTERM, `_on_cleanup` waits up to `HERMES_TELEGRAM_SHUTDOWN_DRAIN` (default 12s) for background replies to finish before cancelling stragglers; `TimeoutStopSec=45` in the unit covers drain + the orchestrator's own 15s compression drain |

### Setup

```bash
# 1. Talk to @BotFather, create a bot, copy the token.
# 2. Generate a webhook secret:
openssl rand -hex 32

# 3. Put both in /etc/hermes/hermes.env (mode 0600):
#      TELEGRAM_BOT_TOKEN=123456:ABC-...
#      TELEGRAM_WEBHOOK_SECRET=<the hex string>
#      HERMES_DOMAIN=https://agent.example.uz
sudo systemctl restart hermes

# 4. Register the webhook with Telegram (uses the secret + domain from env):
/opt/hermes/.venv/bin/hermes-telegram set-webhook
#    -> setWebhook -> https://agent.example.uz/webhook/telegram: True

# 5. Confirm Telegram accepted it:
/opt/hermes/.venv/bin/hermes-telegram get-info

# 6. (Optional) Point the chat menu button at the J.A.R.V.I.S. Mini App:
/opt/hermes/.venv/bin/hermes-telegram set-menu-button
#    -> setChatMenuButton -> https://<your-domain>/: True
```

`hermes-telegram` refuses to register an insecure webhook: it exits non-zero if
the URL isn't `https://` or if `TELEGRAM_WEBHOOK_SECRET` is empty. The equivalent
raw call (if you prefer curl) is:

```bash
curl -F "url=https://agent.example.uz/webhook/telegram" \
     -F "secret_token=$TELEGRAM_WEBHOOK_SECRET" \
     -F "drop_pending_updates=true" \
     "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/setWebhook"
```

nginx TLS + reverse proxy: see [`deploy/nginx-hermes.conf`](deploy/nginx-hermes.conf)
(allowlists Telegram's official source CIDRs — IPv4 **and** IPv6, so a dual-stack
`listen [::]:443` VPS doesn't `deny all` IPv6 peers — rate-limits the webhook,
terminates TLS, and keeps `/v1/chat` off the public internet).
Set `TELEGRAM_BOT_TOKEN` empty/unset to run the HTTP API standalone — the webhook
route then answers a clean `503 telegram_disabled` instead of a confusing 404.

Each Telegram chat maps to a stable session (`tg_<chat_id>`), so memory
compression and fact-triplet recall work across messages exactly as they do for
`/v1/chat`.

### Mini App (J.A.R.V.I.S. web console inside Telegram)

The same web console `server.py` serves at `/` doubles as a **Telegram Mini App**
(Web App). It boots the Telegram WebApp SDK (`telegram-web-app.js`), calls
`ready()`/`expand()`, matches the native header to the arc-reactor palette, greets
the user by their Telegram first name, and fires haptics on each action. The
"Ask J.A.R.V.I.S." button POSTs to `/v1/chat` and renders the answer chat-style.

Two entry points open it, both driven by `HERMES_DOMAIN` (or `HERMES_MINIAPP_URL`):

| Entry | How | Wiring |
|---|---|---|
| **Menu button** (left of the input field) | `setChatMenuButton` → `web_app` | `hermes-telegram set-menu-button` (one-time) |
| **Inline button** on `/start` and `/menu` | `reply_markup` inline keyboard → `web_app` | automatic on every `/start`, no LLM spend |

The Mini App URL must be **HTTPS** (Telegram rejects plain HTTP). When no HTTPS
domain is configured, `miniapp_enabled` is `False`, the inline button is omitted,
and `/start` degrades to a plain-text greeting — the bot stays fully functional.

> **ngrok free-tier caveat.** `*.ngrok-free.dev` serves a browser interstitial
> warning page (`ERR_NGROK_6024`) for top-level navigation. Telegram's Mini App
> WebView uses a browser User-Agent, so the interstitial can appear **over** the
> console, and the in-page `ngrok-skip-browser-warning` header does **not**
> suppress it (Telegram owns that top-level request, not your JS). Workarounds:
> tap through the warning once (a cookie is set, though WebView cookies are
> unreliable), use a **paid** ngrok domain, or front the app with an
> interstitial-free tunnel (Cloudflare Tunnel / tunnelto / Pinggy). The
> **webhook is unaffected** — Telegram's servers fetch it, not a browser.

---

## Access control, cost guard & document ingestion

Three production guards sit on top of the routing core. All are opt-in and default
to "off", so a fresh checkout behaves exactly as before.

### Whitelist (`HERMES_ALLOWED_USERS`)

A comma-separated list of Telegram user IDs permitted to drive the agent. The gate
runs in `_process_telegram_update` **before** the concurrency semaphore and **before**
any router/LLM call, so an unauthorized sender costs **zero compute and zero
concurrency slot** — they get an immediate `403: Ruxsat berilmagan foydalanuvchi`
and the webhook still fast-acks `200` to Telegram.

```bash
HERMES_ALLOWED_USERS=123456789,987654321   # find your id via @userinfobot
```

An **unset or empty** value disables the gate (single-user/dev default), preserving
the existing behaviour and test-suite.

### Daily cost guard (`HERMES_DAILY_TOKEN_BUDGET`)

Every completed request writes its token usage (`tokens_in + tokens_out`) to a
lightweight `spend_ledger` table in `memory.db`, bucketed by UTC day. Once the
running day's total crosses the cap, the orchestrator **auto-degrades every request
to Tier-1** (the cheapest model) and **blocks tier escalation on failure**, so a
runaway day cannot climb back to Tier-2/3 and burn credits.

The budget takes precedence even over a document's forced Tier-3 routing — cost
protection is paramount. But Tier-1's context window is far smaller than Tier-3's,
so degrading a large document would only overflow Groq and fail with a confusing
`context_length_exceeded` **after** burning a call. To avoid that, when the budget
is exhausted **and** the request exceeds `HERMES_T1_CONTEXT_TOKENS` (default 64k),
the orchestrator **fails fast** with a clear `BudgetExceededError` (zero tokens
spent) instead of sending an oversized payload to a model that cannot hold it:

> Kunlik token byudjeti tugaganligi sababli katta hujjatlarni tahlil qilish
> vaqtincha cheklandi.

```bash
HERMES_DAILY_TOKEN_BUDGET=1000000   # 0 = disabled (default)
HERMES_T1_CONTEXT_TOKENS=64000      # max input Tier-1 takes when budget-degraded
```

The ledger is pruned by the same retention TTL as the audit log during the periodic
`maintenance()` pass, so it cannot grow unbounded on a small Hetzner volume.

### Document ingestion (uploaded files → Tier-3)

Send the bot a document and it is fetched via the Bot API `getFile` endpoint,
extracted to text, and pinned to **Tier-3** (Gemini's large context) — no vision
model required:

| Type | Handling |
| --- | --- |
| `.txt .py .json .log .md .csv .yaml .yml` | decoded as UTF-8 (invalid bytes replaced, never a hard failure) |
| `.pdf` | text layer extracted with **pypdf** (the lightest pure-Python option, no native deps) |
| `> 20 MB` | rejected up front (Telegram bots cannot download larger files anyway) |
| unsupported / image-only PDF / empty | rejected with a `DocumentError` carrying the exact payload + a concrete fallback |

Extracted text is truncated to `HERMES_TELEGRAM_DOCUMENT_MAX_CHARS` (default 400k)
before it is appended to the prompt. PDF support needs the optional extra:

```bash
pip install "hermes-prime[pdf]"     # or: pip install pypdf
```

Because a large document must not be sent to the cheap Tier-1 classifier just to be
told "use Tier-3", `HermesOrchestrator.handle(..., force_tier=Tier.T3)` builds a
synthetic routing decision and skips the router LLM call entirely.

---

### Voice notes (speech-to-text + spoken replies)

Send the bot a **voice note** and J.A.R.V.I.S. hears it, thinks, and — by default —
answers back in kind. Voice is **free and keyless by design**: there is no OpenAI
Whisper key and no ElevenLabs key to buy. Both directions reuse what the agent
already has, so a fresh checkout spends nothing extra and the text flow is untouched.

| Direction | Provider | Flow |
| --- | --- | --- |
| **STT** (voice → text) | **Gemini** multimodal via the existing **Tier-3** (Omni Router) path | The Telegram `.ogg`/Opus bytes are fetched via `getFile`, base64-encoded into an `input_audio` chat part, and Gemini is asked to transcribe them **verbatim in the original language**. It reuses `GEMINI_API_KEY` plus the existing retry / circuit-breaker / failover stack in `LLMClient` — no Whisper, no extra provider, no extra key, zero VPS transcoding. |
| **TTS** (text → speech) | **edge-tts** (Microsoft Edge neural voices, `en-GB-ThomasNeural`) | The answer is streamed to **MP3** in memory and sent with `sendAudio` (plays inline). edge-tts needs **no API key at all** — only egress to `speech.platform.bing.com`. |

Why `sendAudio` and not `sendVoice`: a true voice *bubble* requires OGG/Opus, i.e. an
ffmpeg transcode of the MP3. That is deliberate compute we avoid on a small Hetzner
box — `sendAudio` plays the MP3 inline with no server-side conversion.

Enable it (see `.env.example`): STT turns on automatically once the Tier-3 key is
present; TTS turns on once `edge-tts` is installed (it ships in `requirements.txt`).

```bash
GEMINI_API_KEY=...             # already set for Tier-3 — it doubles as the STT key
pip install edge-tts           # keyless TTS; no API key required
```

The spoken-reply policy is `HERMES_TTS_REPLY_MODE`:

- **`mirror`** (default) — voice-in → voice-out. A typed message gets text only; a voice
  note gets text **and** audio. Natural and cost-light.
- **`always`** — every answer also gets audio.
- **`off`** — never synthesize. STT still works whenever `GEMINI_API_KEY` is set.

Guards and honesty rules:

- TTS input is truncated to `HERMES_TTS_MAX_CHARS` (default 2500) at a word boundary, with
  Markdown code fences/backticks stripped so they are not read aloud. The **full** text answer
  is always delivered as a normal message regardless — only the spoken rendition is shortened.
- A voice note with STT unconfigured raises a `VoiceError` (stage `stt`) surfaced to the user
  with the exact payload + a concrete fallback — never a fabricated transcript.
- Silence (empty transcript) gets an in-character nudge and spends **zero** LLM calls.
- TTS is **non-fatal**: the text answer is already sent, so any synth/send failure is logged
  with its payload and swallowed rather than alarming the user with a second error.

> **Voice tuning:** `HERMES_TTS_VOICE` defaults to `en-GB-ThomasNeural` (a formal British
> male voice, JARVIS-appropriate). Adjust delivery with `HERMES_TTS_RATE` / `HERMES_TTS_VOLUME`
> / `HERMES_TTS_PITCH`; list every free voice with `edge-tts --list-voices`. STT rides
> `HERMES_STT_TIER` (default `tier3_multimodal`) and the verbatim-transcription instruction
> `HERMES_STT_PROMPT`.

---

## Deployment (Hetzner VPS)

**Option A — systemd (bare metal).** One-shot, idempotent:

```bash
sudo bash deploy/install.sh          # creates user, venv, /etc/hermes/hermes.env, unit
sudo nano /etc/hermes/hermes.env     # add GROQ / OPENROUTER / GEMINI / TAVILY keys
sudo systemctl start hermes && systemctl status hermes
journalctl -u hermes -f
```

The unit is hardened: non-root `hermes` user, `ProtectSystem=strict`, `ReadWritePaths`
limited to `/var/lib/hermes`, `MemoryMax=1G`, `CPUQuota=150%`, secrets via `EnvironmentFile`
(mode `0600`, never inline). Keep `8081` behind nginx/caddy + TLS or a Hetzner Cloud
firewall — do not expose it raw.

**Option B — container.**

> Note: the `Dockerfile` is provided but was **not** built in the authoring sandbox
> (docker unavailable there). It follows standard `python:3.12-slim` multi-stage
> conventions; build it once on the target host to confirm before relying on it.

```bash
docker build -t hermes-prime .
docker run -d --name hermes \
  --env-file /etc/hermes/hermes.env \
  --read-only --tmpfs /tmp \
  -v hermes-state:/var/lib/hermes \
  -p 127.0.0.1:8081:8081 \
  hermes-prime
```

Runs as non-root, read-only root FS, only the `hermes-state` volume writable, with a
built-in `HEALTHCHECK` against `/healthz`. Bind to `127.0.0.1` and front it with a TLS proxy.

---

## Safety & robustness

| Concern | Mechanism |
|---|---|
| Malformed tool calls | `jsonschema` validation both directions; invalid args returned as a `SchemaViolation` envelope, never executed |
| Prompt-injected code execution | `python_exec` AST guard blocks `socket/subprocess/ctypes/eval/exec/__globals__/__subclasses__…`, then runs in a subprocess with `RLIMIT_AS/CPU/NPROC/FSIZE`, `-I` isolated mode, secrets stripped from env, no network by default |
| SSRF via `web_fetch` | private/loopback/link-local/reserved hosts rejected before any request |
| SQL injection / writes | `sql_query` allows a single `SELECT`/`WITH … SELECT` only; write keywords and statement batching rejected; opened `mode=ro` |
| Provider outage | per-tier model failover chain + exponential-backoff retries + circuit breaker; escalates tier then degrades with a real error envelope |
| Fabricated results | the runtime never invents tool output; a failure carries the exact error payload + a concrete `fallback` string |
| Unbounded memory | bounded summaries/triplets per session, WAL mode, compression keeps the raw window small |
| Disk bloat on a small VPS | `audit_log` retention (TTL `HERMES_AUDIT_RETENTION_DAYS` + row cap `HERMES_AUDIT_MAX_ROWS`) and a maintenance pass that runs `PRAGMA optimize` + `wal_checkpoint(TRUNCATE)` at boot and every `HERMES_MAINTENANCE_INTERVAL_H` hours, so the DB and its `-wal` file can't grow unbounded |
| Cross-thread DB corruption | `MemoryStore` uses **thread-local SQLite connections** (never one shared handle): event-loop writes stay serialized while `asyncio.to_thread` reads each get their own WAL connection. Verified by a 1200-op concurrency stress test + a regression test proven to fail if the fix is reverted |

---

## Configuration

All knobs are environment-driven (see `.env.example`). Notable ones:

- `HERMES_LLM_ROUTING=false` → heuristic-only routing (cheapest possible; no Tier-1 call to route).
- `HERMES_MAX_STEPS` → tool-loop budget per request.
- `HERMES_HEAVY_TOKENS` / `HERMES_MEDIUM_TOKENS` → routing thresholds.
- `HERMES_COMPRESS_EVERY` / `HERMES_KEEP_RECENT` → memory compression cadence.
- `HERMES_EXEC_NETWORK` → leave `false` in production.
- `TELEGRAM_BOT_TOKEN` / `TELEGRAM_WEBHOOK_SECRET` / `HERMES_DOMAIN` → enable + register the
  Telegram webhook (see [Telegram bot](#telegram-bot-webhook)). The secret is mandatory: the
  webhook 403s any update that doesn't carry it. `HERMES_DOMAIN` also derives the Mini App URL.
- `HERMES_MINIAPP_URL` / `HERMES_MINIAPP_BUTTON_TEXT` → the J.A.R.V.I.S. Mini App (Web App)
  entry URL and its button label. The URL defaults to `$HERMES_DOMAIN/` (the web console), must
  be HTTPS, and drives both the `set-menu-button` menu button and the inline `/start` button.
  With no HTTPS URL, `miniapp_enabled` is false and buttons are omitted (see
  [Mini App](#mini-app-jarvis-web-console-inside-telegram)).
- `HERMES_TELEGRAM_MAX_CONCURRENT` → bound on simultaneous agent runs triggered by Telegram
  (VPS protection); `HERMES_TELEGRAM_TIMEOUT` → seconds per Bot API call.
- `HERMES_TELEGRAM_TYPING_REFRESH` → seconds between "typing" heartbeats (Telegram expires the
  indicator at 5s; default 4). `HERMES_TELEGRAM_SHUTDOWN_DRAIN` → on SIGTERM, seconds to let
  in-flight replies finish before cancelling (default 12). Keep this + the orchestrator's 15s
  compression drain under the unit's `TimeoutStopSec` (45).
- `HERMES_AUDIT_RETENTION_DAYS` / `HERMES_AUDIT_MAX_ROWS` → `audit_log` retention bounds
  (0 disables each). `HERMES_MAINTENANCE_INTERVAL_H` → hours between prune + `wal_checkpoint(TRUNCATE)`
  passes (0 = run once at boot only).
- `HERMES_ALLOWED_USERS` → comma-separated Telegram user IDs permitted to drive the agent;
  unset/empty disables the gate. Unauthorized senders are rejected before any LLM/semaphore spend.
- `HERMES_DAILY_TOKEN_BUDGET` → per-UTC-day token cap recorded in `spend_ledger`; once crossed,
  every request auto-degrades to Tier-1 and tier escalation is blocked (0 = disabled).
- `HERMES_TELEGRAM_MAX_DOCUMENT_BYTES` (default 20 MB) / `HERMES_TELEGRAM_DOCUMENT_MAX_CHARS`
  (default 400k) → document-ingestion size guards. PDF extraction needs `pip install "hermes-prime[pdf]"`.
- Voice is **keyless** — no OpenAI Whisper key, no ElevenLabs key. **Speech-to-text** rides the
  existing Tier-3 (Gemini via Omni Router) path, so `GEMINI_API_KEY` (already set for Tier-3)
  doubles as the STT key; **text-to-speech** uses `edge-tts` (in `requirements.txt`), which needs
  no API key at all. See [Voice notes](#voice-notes-speech-to-text--spoken-replies).
- `HERMES_TTS_REPLY_MODE` → `mirror` (default: voice-in → voice-out) / `always` / `off`.
  `HERMES_TTS_VOICE` (default `en-GB-ThomasNeural`, a formal British male) / `HERMES_TTS_RATE` /
  `HERMES_TTS_VOLUME` / `HERMES_TTS_PITCH` / `HERMES_TTS_MAX_CHARS` (default 2500) → spoken-reply
  voice, delivery and input cap. `HERMES_STT_TIER` (default `tier3_multimodal`) / `HERMES_STT_PROMPT`
  / `HERMES_STT_TIMEOUT` / `HERMES_TTS_TIMEOUT` → provider tuning.

Model IDs/endpoints default to Groq (T1), OpenRouter→Llama 3.1 405B (T2), Gemini via
OpenRouter (T3); override any of them with `HERMES_T{1,2,3}_MODEL` / `_BASE_URL`.

---

## Notes

- The "Groq 120B / Llama 3.1 405B / Gemini" labels are the roles from the Hermes-Prime spec;
  concrete model IDs are configurable and default to currently-served equivalents.
- `tests/fake_transport.py` is a **test seam only**. It exists so the loop can be exercised
  deterministically offline. Production always uses `HTTPTransport`.
