#!/usr/bin/env bash
# Hermes-Prime — one-shot install for a fresh Hetzner (Debian/Ubuntu) VPS.
# Idempotent. Run as root:  sudo bash deploy/install.sh
set -euo pipefail

APP_DIR=/opt/hermes
STATE_DIR=/var/lib/hermes
CONFIG_DIR=/etc/hermes
SERVICE_USER=hermes
PY_BIN=python3

log() { printf '\033[1;32m[install]\033[0m %s\n' "$*"; }
die() { printf '\033[1;31m[error]\033[0m %s\n' "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "run as root (sudo bash deploy/install.sh)"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

log "1/7 system user"
id -u "$SERVICE_USER" &>/dev/null || useradd --system --home "$STATE_DIR" --shell /usr/sbin/nologin "$SERVICE_USER"

log "2/7 directories"
mkdir -p "$APP_DIR" "$STATE_DIR/sandbox" "$CONFIG_DIR"
# python3-venv ensures the venv module is present on slim Debian images
command -v "$PY_BIN" &>/dev/null || die "python3 not found; apt-get install -y python3 python3-venv"

log "3/7 copy application"
rsync -a --delete \
  --exclude '__pycache__' --exclude '*.db*' --exclude '.venv' \
  --exclude '.git' --exclude '.hermes_sandbox' \
  "$SRC_DIR"/ "$APP_DIR"/

log "4/7 virtualenv + dependencies"
[[ -d "$APP_DIR/.venv" ]] || "$PY_BIN" -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install --upgrade pip wheel >/dev/null
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt" >/dev/null

log "5/7 secrets file"
if [[ ! -f "$CONFIG_DIR/hermes.env" ]]; then
  install -m 0600 "$APP_DIR/.env.example" "$CONFIG_DIR/hermes.env"
  chown "$SERVICE_USER":"$SERVICE_USER" "$CONFIG_DIR/hermes.env"
  log "    -> created $CONFIG_DIR/hermes.env (EDIT IT: add your API keys)"
else
  log "    -> $CONFIG_DIR/hermes.env exists, leaving untouched"
fi

log "6/7 ownership"
chown -R "$SERVICE_USER":"$SERVICE_USER" "$APP_DIR" "$STATE_DIR"

log "7/7 systemd unit"
install -m 0644 "$APP_DIR/deploy/hermes.service" /etc/systemd/system/hermes.service
systemctl daemon-reload
systemctl enable hermes.service >/dev/null 2>&1 || true

log "smoke test (offline, no keys needed)"
if sudo -u "$SERVICE_USER" "$APP_DIR/.venv/bin/python" "$APP_DIR/main.py" --offline "hello" >/dev/null 2>&1; then
  log "    -> offline self-test PASSED"
else
  log "    -> offline self-test FAILED (check $APP_DIR manually)"
fi

cat <<EOF

Done.
  1. Edit secrets:   nano $CONFIG_DIR/hermes.env      (add GROQ/OPENROUTER/GEMINI/TAVILY keys)
  2. Start:          systemctl start hermes && systemctl status hermes
  3. Logs:           journalctl -u hermes -f
  4. Health:         curl http://127.0.0.1:8081/healthz

The service binds 0.0.0.0:8081. Put nginx + TLS in front, or restrict with a
Hetzner Cloud firewall — do NOT expose 8081 raw to the internet.

TLS / reverse proxy (a hardened config is shipped at $APP_DIR/deploy/nginx-hermes.conf):
  sudo cp $APP_DIR/deploy/nginx-hermes.conf /etc/nginx/sites-available/hermes
  sudo sed -i 's/agent.example.uz/YOUR_DOMAIN/g' /etc/nginx/sites-available/hermes
  sudo ln -s /etc/nginx/sites-available/hermes /etc/nginx/sites-enabled/
  sudo certbot --nginx -d YOUR_DOMAIN && sudo nginx -t && sudo systemctl reload nginx

Optional Telegram bot (webhook, no polling). In $CONFIG_DIR/hermes.env set:
  TELEGRAM_BOT_TOKEN, TELEGRAM_WEBHOOK_SECRET (openssl rand -hex 32), HERMES_DOMAIN
Then:  sudo systemctl restart hermes
       sudo -u $SERVICE_USER $APP_DIR/.venv/bin/hermes-telegram set-webhook
       sudo -u $SERVICE_USER $APP_DIR/.venv/bin/hermes-telegram get-info
EOF
