"""Hermes-Prime: MoE (Mixture-of-Experts) multi-model router runtime.

Tiers
-----
T1 planning/routing  -> ultra-low-latency model (Groq)
T2 deep synthesis    -> 405B-class reasoning model (Omni Router / OpenRouter)
T3 multimodal/heavy  -> 1M-context vision model (Gemini)
"""

from __future__ import annotations

from .config import (
    ExecutorConfig,
    MemoryConfig,
    ModelProfile,
    RouterConfig,
    Settings,
    TelegramConfig,
    Tier,
    VoiceConfig,
    load_settings,
)
from .documents import MAX_DOWNLOAD_BYTES, extract_document_text, is_supported_document
from .errors import (
    BudgetExceededError,
    DocumentError,
    HermesError,
    LLMError,
    LLMTimeoutError,
    MissingCredentialError,
    SecurityViolation,
    TelegramError,
    ToolExecutionError,
    VoiceError,
)
from .llm import LLMClient, LLMResult, LLMTransport, extract_json
from .memory import MemoryStore, estimate_tokens, heuristic_compression
from .orchestrator import AgentResponse, HermesOrchestrator, Step
from .router import RouteDecision, Router, heuristic_route
from .schemas import (
    ROUTER_DECISION_SCHEMA,
    TOOL_INDEX,
    TOOL_SCHEMAS,
    SchemaViolation,
    openai_tools_payload,
    parse_tool_args,
    validate,
)
from .telegram import HttpTelegramTransport, TelegramClient, TelegramTransport, split_message
from .tools import ToolRegistry, build_registry
from .voice import GeminiEdgeVoiceTransport, VoiceClient, VoiceTransport, truncate_for_speech

__version__ = "1.0.0"

__all__ = [
    "AgentResponse",
    "BudgetExceededError",
    "DocumentError",
    "ExecutorConfig",
    "HermesError",
    "HermesOrchestrator",
    "GeminiEdgeVoiceTransport",
    "HttpTelegramTransport",
    "LLMClient",
    "LLMError",
    "LLMResult",
    "LLMTimeoutError",
    "LLMTransport",
    "MAX_DOWNLOAD_BYTES",
    "MemoryConfig",
    "MemoryStore",
    "MissingCredentialError",
    "ModelProfile",
    "ROUTER_DECISION_SCHEMA",
    "RouteDecision",
    "Router",
    "RouterConfig",
    "SchemaViolation",
    "SecurityViolation",
    "Settings",
    "Step",
    "TOOL_INDEX",
    "TOOL_SCHEMAS",
    "TelegramClient",
    "TelegramConfig",
    "TelegramError",
    "TelegramTransport",
    "Tier",
    "ToolExecutionError",
    "ToolRegistry",
    "VoiceClient",
    "VoiceConfig",
    "VoiceError",
    "VoiceTransport",
    "build_registry",
    "estimate_tokens",
    "extract_document_text",
    "extract_json",
    "heuristic_compression",
    "heuristic_route",
    "is_supported_document",
    "load_settings",
    "openai_tools_payload",
    "parse_tool_args",
    "split_message",
    "truncate_for_speech",
    "validate",
    "__version__",
]
