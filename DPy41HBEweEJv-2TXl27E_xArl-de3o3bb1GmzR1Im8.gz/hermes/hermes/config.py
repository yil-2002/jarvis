"""Hermes-Prime configuration.

Strictly typed, environment-driven, zero secrets in code.
Every tier declares: endpoint, model id, timeout, retry policy and failover chain.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Final

from .errors import MissingCredentialError

_ENV_PREFIX: Final[str] = "HERMES_"


class Tier(StrEnum):
    """Inference tiers of the MoE router."""

    T1 = "tier1_planning"      # ultra-low latency: routing, classification, chat
    T2 = "tier2_deep"          # deep cognition: architecture, algorithms, synthesis
    T3 = "tier3_multimodal"    # heavy context / vision: images, >100k token payloads


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    """Exponential backoff with jitter."""

    attempts: int = 3
    base_delay_s: float = 0.4
    max_delay_s: float = 6.0
    backoff_factor: float = 2.0
    jitter: float = 0.2
    # HTTP statuses worth retrying
    retry_on_status: frozenset[int] = frozenset({408, 409, 425, 429, 500, 502, 503, 504})


@dataclass(frozen=True, slots=True)
class ModelProfile:
    tier: Tier
    provider: str
    model: str
    base_url: str
    api_key_env: str
    max_output_tokens: int = 4096
    context_window: int = 131_072
    timeout_s: float = 60.0
    temperature: float = 0.2
    supports_vision: bool = False
    supports_json_mode: bool = True
    retry: RetryPolicy = field(default_factory=RetryPolicy)
    failover: tuple[str, ...] = ()  # model ids tried in order on hard failure

    @property
    def api_key(self) -> str:
        key = os.environ.get(self.api_key_env, "").strip()
        if not key:
            raise MissingCredentialError(self.api_key_env)
        return key


def _f(name: str, default: str) -> str:
    return os.environ.get(_ENV_PREFIX + name, default).strip()


def _i(name: str, default: int) -> int:
    raw = os.environ.get(_ENV_PREFIX + name)
    return int(raw) if raw and raw.isdigit() else default


def _bool(name: str, default: bool) -> bool:
    raw = os.environ.get(_ENV_PREFIX + name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True, slots=True)
class RouterConfig:
    """Deterministic + LLM routing knobs."""

    heavy_context_tokens: int = 100_000   # -> Tier 3
    medium_context_tokens: int = 8_000    # -> Tier 2 candidate
    tier1_context_tokens: int = 64_000    # max input Tier-1 can safely take when budget-degraded
    chars_per_token: float = 3.6          # cheap heuristic estimator
    max_agent_steps: int = 8              # hard stop for the tool loop
    llm_routing_enabled: bool = True      # T1 classifier pass
    router_confidence_floor: float = 0.55 # below -> fall back to heuristic tier


@dataclass(frozen=True, slots=True)
class MemoryConfig:
    db_path: str = "hermes_state.db"
    compress_every_n_messages: int = 10
    keep_recent_messages: int = 12
    max_triplets_per_summary: int = 24
    max_summary_chars: int = 1_800
    top_k_triplets: int = 8
    # Retention: the audit_log table grows with every routed step. Without a cap
    # it (and the SQLite -wal file) bloats a small Hetzner disk over months.
    audit_retention_days: int = 30        # delete audit rows older than this (0 = keep forever)
    audit_max_rows: int = 100_000         # hard cap on audit rows kept (0 = no cap)
    maintenance_interval_h: int = 24      # re-run prune+checkpoint every N hours (0 = startup only)
    # Cost guard: total tokens (in+out) recorded in spend_ledger per UTC day. When
    # the running day crosses this, the orchestrator degrades routing to Tier-1.
    daily_token_budget: int = 0           # 0 = disabled (single-user default: no cap)


@dataclass(frozen=True, slots=True)
class ExecutorConfig:
    """Sandbox limits for the local python_exec tool."""

    timeout_s: float = 20.0
    max_output_chars: int = 20_000
    max_memory_mb: int = 512
    allow_network: bool = False
    workspace_dir: str = ".hermes_sandbox"


@dataclass(frozen=True, slots=True)
class TelegramConfig:
    """Telegram Bot API webhook integration.

    Secrets are read from the environment at access time (never stored on the
    frozen dataclass), so the same Settings object is safe to log/repr.
    """

    bot_token_env: str = "TELEGRAM_BOT_TOKEN"
    webhook_secret_env: str = "TELEGRAM_WEBHOOK_SECRET"
    allowed_users_env: str = "HERMES_ALLOWED_USERS"
    domain: str = ""                       # e.g. https://agent.example.uz (HERMES_DOMAIN)
    webhook_path: str = "/webhook/telegram"
    # Telegram Mini App (Web App) entry point. Defaults to the domain root (the
    # JARVIS web console served by server.py); override with HERMES_MINIAPP_URL.
    miniapp_url: str = ""
    miniapp_button_text: str = "Open J.A.R.V.I.S."
    allowed_updates: tuple[str, ...] = ("message", "edited_message")
    api_base: str = "https://api.telegram.org"
    max_message_chars: int = 4_096         # Telegram hard limit per sendMessage
    timeout_s: float = 30.0
    max_concurrent: int = 8                # bound concurrent agent runs (VPS protection)
    typing_refresh_s: float = 4.0          # re-send "typing" before it expires (5s)
    dedupe_window: int = 4_096             # recent update_ids remembered to drop retries
    shutdown_drain_s: float = 12.0         # let in-flight webhook tasks finish on SIGTERM
    # Document ingestion (Tier-3 large-context analysis of uploaded files).
    max_document_bytes: int = 20 * 1024 * 1024   # Telegram Bot API hard download cap
    document_text_extensions: tuple[str, ...] = (".txt", ".py", ".json", ".log", ".md", ".csv", ".yaml", ".yml")
    document_max_chars: int = 400_000      # truncate extracted text before it hits the prompt

    @property
    def bot_token(self) -> str:
        return os.environ.get(self.bot_token_env, "").strip()

    @property
    def webhook_secret(self) -> str:
        return os.environ.get(self.webhook_secret_env, "").strip()

    @property
    def allowed_users(self) -> frozenset[int]:
        """Telegram user IDs permitted to drive the agent.

        Empty set => allowlist DISABLED (single-user/dev default; every existing
        test and a fresh bot keep working). When non-empty, only these ``from.id``
        values are served; everyone else is rejected before any LLM/semaphore spend.
        """

        raw = os.environ.get(self.allowed_users_env, "")
        ids: set[int] = set()
        for part in raw.replace(";", ",").split(","):
            part = part.strip()
            if part.lstrip("-").isdigit():
                ids.add(int(part))
        return frozenset(ids)

    @property
    def enabled(self) -> bool:
        return bool(self.bot_token)

    @property
    def webhook_url(self) -> str:
        if not self.domain:
            return ""
        return f"{self.domain.rstrip('/')}{self.webhook_path}"

    @property
    def resolved_miniapp_url(self) -> str:
        """Mini App entry URL. Explicit ``miniapp_url`` wins; otherwise the
        domain root (where ``server.py`` serves the JARVIS web console). Must be
        HTTPS — Telegram rejects plain-HTTP Web App URLs. Empty when no domain
        is configured (Mini App buttons are then omitted, bot stays text-only).
        """
        if self.miniapp_url:
            return self.miniapp_url.rstrip("/") + "/"
        if self.domain:
            return self.domain.rstrip("/") + "/"
        return ""

    @property
    def miniapp_enabled(self) -> bool:
        """True when a usable (HTTPS) Mini App URL is configured."""
        url = self.resolved_miniapp_url
        return url.startswith("https://")


def _edge_tts_available() -> bool:
    """True when the optional ``edge-tts`` package is importable (no API key needed)."""

    import importlib.util

    try:
        return importlib.util.find_spec("edge_tts") is not None
    except (ImportError, ValueError):  # pragma: no cover - defensive
        return False


# Default STT instruction. Kept at module scope because a slotted dataclass exposes
# its field defaults as member descriptors on the class, not as plain strings, so
# ``load_settings`` cannot read ``VoiceConfig.stt_prompt`` for its own default.
_DEFAULT_STT_PROMPT: Final[str] = (
    "Transcribe the following audio exactly as spoken, in the original language. "
    "Output ONLY the transcript text — no preamble, no translation, no commentary."
)


@dataclass(frozen=True, slots=True)
class VoiceConfig:
    """Speech-to-text (Gemini via Omni Router) + text-to-speech (edge-tts).

    Neither direction needs a *dedicated* paid voice API key — the whole point of
    this design is to run blocked-region-safe and cost-light:

      * **STT** rides the Tier-3 multimodal model the agent already uses (Gemini
        through OpenRouter / "Omni Router"). The Telegram voice note's ``.ogg``/Opus
        bytes are base64-encoded into an ``input_audio`` chat part and the model is
        asked to transcribe them verbatim. No Whisper, no extra provider, no extra
        key — it reuses ``GEMINI_API_KEY`` and the existing retry/circuit-breaker/
        failover stack in :class:`~hermes.llm.LLMClient`.
      * **TTS** uses Microsoft's ``edge-tts`` (the free Edge "read aloud" neural
        voices). It requires **no API key at all** and streams MP3, which we deliver
        with Telegram ``sendAudio`` (plays inline). A true ``sendVoice`` bubble would
        need OGG/Opus i.e. an ffmpeg transcode — deliberately avoided so the Hetzner
        box does zero audio compute.

    Both stay opt-in and degrade gracefully: STT activates only when the Tier-3 key
    is present; TTS only when ``tts_reply_mode != "off"`` *and* ``edge-tts`` is
    installed. Secrets are read at access time (never stored on the frozen
    dataclass), so a ``Settings`` object stays safe to log/repr.
    """

    # --- STT: Gemini multimodal via the existing Tier-3 (Omni Router) path ---
    stt_api_key_env: str = "GEMINI_API_KEY"    # same key that already powers Tier-3
    stt_tier: str = "tier3_multimodal"         # Tier value used to transcribe
    stt_prompt: str = _DEFAULT_STT_PROMPT
    stt_timeout_s: float = 60.0
    stt_max_bytes: int = 20 * 1024 * 1024      # Telegram bot download ceiling

    # --- TTS: edge-tts (free Microsoft neural voices, no API key) ---
    tts_voice: str = "en-GB-ThomasNeural"      # British male, JARVIS-appropriate
    tts_rate: str = "+0%"
    tts_volume: str = "+0%"
    tts_pitch: str = "+0Hz"
    tts_timeout_s: float = 60.0
    tts_max_chars: int = 2_500                 # cap TTS input (latency/length guard)
    # When to attach a spoken reply:
    #   "mirror" (default) = voice-in -> voice-out (natural conversation)
    #   "always"           = every answer also gets audio
    #   "off"              = never synthesize
    tts_reply_mode: str = "mirror"

    @property
    def stt_key(self) -> str:
        return os.environ.get(self.stt_api_key_env, "").strip()

    @property
    def stt_enabled(self) -> bool:
        """Transcription rides Tier-3, so it's live whenever that key is set."""
        return bool(self.stt_key)

    @property
    def tts_enabled(self) -> bool:
        """edge-tts needs no key; TTS is on unless mode is 'off' or edge-tts is missing."""
        return self.tts_reply_mode != "off" and _edge_tts_available()

    def should_speak(self, *, incoming_was_voice: bool) -> bool:
        """Decide whether to attach a spoken (TTS) reply to this answer."""
        if not self.tts_enabled:
            return False
        if self.tts_reply_mode == "always":
            return True
        return incoming_was_voice  # "mirror": speak only when the user spoke


@dataclass(frozen=True, slots=True)
class Settings:
    router: RouterConfig = field(default_factory=RouterConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    executor: ExecutorConfig = field(default_factory=ExecutorConfig)
    telegram: TelegramConfig = field(default_factory=TelegramConfig)
    voice: VoiceConfig = field(default_factory=VoiceConfig)
    profiles: dict[Tier, ModelProfile] = field(default_factory=dict)
    audit_log: bool = True
    offline: bool = False  # test harness only: injects FakeTransport

    def profile(self, tier: Tier) -> ModelProfile:
        try:
            return self.profiles[tier]
        except KeyError:  # pragma: no cover - defensive
            raise KeyError(f"No model profile configured for {tier}") from None


def default_profiles() -> dict[Tier, ModelProfile]:
    """Baseline MoE model allocation (override via HERMES_* env vars)."""

    t1 = ModelProfile(
        tier=Tier.T1,
        provider="groq",
        model=_f("T1_MODEL", "meta-llama/llama-3.3-70b-versatile"),
        base_url=_f("T1_BASE_URL", "https://api.groq.com/openai/v1"),
        api_key_env="GROQ_API_KEY",
        max_output_tokens=_i("T1_MAX_TOKENS", 2_048),
        context_window=131_072,
        timeout_s=float(_f("T1_TIMEOUT", "30")),
        temperature=0.1,
        failover=("meta-llama/llama-3.1-8b-instant",),
    )
    t2 = ModelProfile(
        tier=Tier.T2,
        provider="openrouter",
        model=_f("T2_MODEL", "meta-llama/llama-3.1-405b-instruct"),
        base_url=_f("T2_BASE_URL", "https://openrouter.ai/api/v1"),
        api_key_env="OPENROUTER_API_KEY",
        max_output_tokens=_i("T2_MAX_TOKENS", 8_192),
        context_window=131_072,
        timeout_s=float(_f("T2_TIMEOUT", "180")),
        temperature=0.2,
        failover=(
            "meta-llama/llama-3.3-70b-instruct",
            "anthropic/claude-3.5-sonnet",
        ),
    )
    t3 = ModelProfile(
        tier=Tier.T3,
        provider="gemini",
        model=_f("T3_MODEL", "google/gemini-2.5-flash"),
        base_url=_f("T3_BASE_URL", "https://openrouter.ai/api/v1"),
        api_key_env="GEMINI_API_KEY",
        max_output_tokens=_i("T3_MAX_TOKENS", 8_192),
        context_window=1_000_000,
        timeout_s=float(_f("T3_TIMEOUT", "240")),
        temperature=0.2,
        supports_vision=True,
        failover=("google/gemini-2.5-pro",),
    )
    return {Tier.T1: t1, Tier.T2: t2, Tier.T3: t3}


def load_settings() -> Settings:
    return Settings(
        router=RouterConfig(
            heavy_context_tokens=_i("HEAVY_TOKENS", 100_000),
            medium_context_tokens=_i("MEDIUM_TOKENS", 8_000),
            tier1_context_tokens=_i("T1_CONTEXT_TOKENS", 64_000),
            max_agent_steps=_i("MAX_STEPS", 8),
            llm_routing_enabled=_bool("LLM_ROUTING", True),
            router_confidence_floor=float(_f("ROUTER_FLOOR", "0.55")),
        ),
        memory=MemoryConfig(
            db_path=_f("DB_PATH", "hermes_state.db"),
            compress_every_n_messages=_i("COMPRESS_EVERY", 10),
            keep_recent_messages=_i("KEEP_RECENT", 12),
            audit_retention_days=_i("AUDIT_RETENTION_DAYS", 30),
            audit_max_rows=_i("AUDIT_MAX_ROWS", 100_000),
            maintenance_interval_h=_i("MAINTENANCE_INTERVAL_H", 24),
            daily_token_budget=_i("DAILY_TOKEN_BUDGET", 0),
        ),
        executor=ExecutorConfig(
            timeout_s=float(_f("EXEC_TIMEOUT", "20")),
            allow_network=_bool("EXEC_NETWORK", False),
            workspace_dir=_f("EXEC_WORKSPACE", ".hermes_sandbox"),
        ),
        telegram=TelegramConfig(
            domain=_f("DOMAIN", ""),
            webhook_path=_f("TELEGRAM_WEBHOOK_PATH", "/webhook/telegram"),
            miniapp_url=_f("MINIAPP_URL", ""),
            miniapp_button_text=_f("MINIAPP_BUTTON_TEXT", "Open J.A.R.V.I.S."),
            max_concurrent=_i("TELEGRAM_MAX_CONCURRENT", 8),
            timeout_s=float(_f("TELEGRAM_TIMEOUT", "30")),
            typing_refresh_s=float(_f("TELEGRAM_TYPING_REFRESH", "4.0")),
            shutdown_drain_s=float(_f("TELEGRAM_SHUTDOWN_DRAIN", "12.0")),
        ),
        voice=VoiceConfig(
            stt_api_key_env=_f("STT_API_KEY_ENV", "GEMINI_API_KEY"),
            stt_tier=_f("STT_TIER", "tier3_multimodal"),
            stt_prompt=_f("STT_PROMPT", _DEFAULT_STT_PROMPT),
            stt_timeout_s=float(_f("STT_TIMEOUT", "60")),
            stt_max_bytes=_i("STT_MAX_BYTES", 20 * 1024 * 1024),
            tts_voice=_f("TTS_VOICE", "en-GB-ThomasNeural"),
            tts_rate=_f("TTS_RATE", "+0%"),
            tts_volume=_f("TTS_VOLUME", "+0%"),
            tts_pitch=_f("TTS_PITCH", "+0Hz"),
            tts_timeout_s=float(_f("TTS_TIMEOUT", "60")),
            tts_max_chars=_i("TTS_MAX_CHARS", 2_500),
            tts_reply_mode=_f("TTS_REPLY_MODE", "mirror"),
        ),
        profiles=default_profiles(),
        offline=_bool("OFFLINE", False),
    )
