"""Document ingestion for Telegram uploads.

Reads text files directly as UTF-8 and PDFs via :mod:`pypdf` (the lightest PDF
text extractor -- no native deps), so uploaded context can be routed to the
large-context Tier-3 model without a multimodal/vision API. Every path is
size-guarded and errors carry a concrete ``fallback`` per the project contract.

This module never calls Telegram itself; the caller downloads the raw bytes
(``TelegramClient.download_file``) and hands them here. That keeps extraction
pure, synchronous, and trivially testable offline.
"""

from __future__ import annotations

import io
import logging
import os

from .errors import DocumentError

log = logging.getLogger("hermes.documents")

__all__ = ["extract_document_text", "is_supported_document", "MAX_DOWNLOAD_BYTES"]

# Telegram's Bot API refuses to serve files larger than 20 MB to bots; we enforce
# the same ceiling up front so an oversize upload is rejected before download.
MAX_DOWNLOAD_BYTES = 20 * 1024 * 1024

_TEXT_EXTS = frozenset({".txt", ".py", ".json", ".log", ".md", ".csv", ".yaml", ".yml"})
_PDF_EXTS = frozenset({".pdf"})


def _ext(file_name: str) -> str:
    return os.path.splitext(file_name or "")[1].lower()


def is_supported_document(file_name: str, mime_type: str | None = None) -> bool:
    """True if the file can be turned into text (known text ext, or PDF)."""

    ext = _ext(file_name)
    if ext in _TEXT_EXTS or ext in _PDF_EXTS:
        return True
    mt = (mime_type or "").lower()
    return mt == "application/pdf" or mt.startswith("text/") or mt in {"application/json"}


def _decode_text(data: bytes, file_name: str) -> str:
    """Decode bytes as UTF-8, degrading gracefully instead of raising."""

    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        # Many real-world .log/.csv files mix encodings; keep the request alive by
        # replacing undecodable bytes rather than hard-failing on a single char.
        log.warning("documents: %s is not valid UTF-8; decoding with replacement", file_name)
        return data.decode("utf-8", errors="replace")


def _extract_pdf(data: bytes, file_name: str) -> str:
    """Extract text from PDF bytes via pypdf (lazy import keeps startup light)."""

    try:
        from pypdf import PdfReader  # noqa: PLC0415 -- optional heavy dep, import on demand
    except ImportError as exc:  # pragma: no cover - exercised only if pypdf absent
        raise DocumentError(
            f"Cannot read PDF '{file_name}': the 'pypdf' package is not installed.",
            payload={"file_name": file_name, "missing_dependency": "pypdf"},
            fallback="Install with `pip install pypdf` (or `pip install hermes-agent[pdf]`), then re-send the file.",
        ) from exc

    try:
        reader = PdfReader(io.BytesIO(data))
        pages = [(page.extract_text() or "") for page in reader.pages]
    except Exception as exc:  # noqa: BLE001 - pypdf raises many types on corrupt PDFs
        raise DocumentError(
            f"Failed to parse PDF '{file_name}': {exc}",
            payload={"file_name": file_name, "error": str(exc), "error_type": type(exc).__name__},
            fallback="The file may be corrupt or password-protected. Re-export it as a plain PDF or send a .txt version.",
        ) from exc

    text = "\n".join(pages).strip()
    if not text:
        # Scanned/image-only PDFs have no text layer; without a vision model there
        # is nothing to route, so fail loudly with an actionable next step.
        raise DocumentError(
            f"PDF '{file_name}' has no extractable text (likely a scanned image).",
            payload={"file_name": file_name, "pages": len(reader.pages)},
            fallback="Send a text-based PDF, or paste the contents as a .txt/.md message.",
        )
    return text


def extract_document_text(
    data: bytes,
    *,
    file_name: str,
    mime_type: str | None = None,
    max_bytes: int = MAX_DOWNLOAD_BYTES,
    max_chars: int = 400_000,
) -> str:
    """Turn downloaded document bytes into prompt-ready text.

    Raises:
        DocumentError: oversize, unsupported type, unreadable PDF, or empty file.
    """

    if not data:
        raise DocumentError(
            f"Downloaded file '{file_name}' is empty.",
            payload={"file_name": file_name, "size": 0},
            fallback="Re-send the file; the download returned zero bytes.",
        )

    size = len(data)
    if size > max_bytes:
        raise DocumentError(
            f"File '{file_name}' is {size / (1024 * 1024):.1f} MB, over the "
            f"{max_bytes / (1024 * 1024):.0f} MB limit.",
            payload={"file_name": file_name, "size": size, "max_bytes": max_bytes},
            fallback="Split the file or send only the relevant portion (Telegram bots cannot fetch files >20 MB).",
        )

    ext = _ext(file_name)
    if ext in _PDF_EXTS or (mime_type or "").lower() == "application/pdf":
        text = _extract_pdf(data, file_name)
    elif ext in _TEXT_EXTS or is_supported_document(file_name, mime_type):
        text = _decode_text(data, file_name)
    else:
        raise DocumentError(
            f"Unsupported file type '{ext or mime_type or file_name}'.",
            payload={"file_name": file_name, "mime_type": mime_type, "ext": ext},
            fallback="Send .txt/.py/.json/.log/.md/.csv or a text-based .pdf.",
        )

    if not text.strip():
        raise DocumentError(
            f"File '{file_name}' contained no readable text.",
            payload={"file_name": file_name, "size": size},
            fallback="Check the file isn't blank or binary; send a .txt with the content you want analysed.",
        )

    if len(text) > max_chars:
        # Truncate with an explicit marker so the model (and user) know it was cut.
        text = text[:max_chars].rstrip() + f"\n\n[… truncated {len(text) - max_chars} characters to fit context …]"
        log.warning("documents: %s truncated to %d chars", file_name, max_chars)

    return text
