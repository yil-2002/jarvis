"""Typed error surface. Every error carries an exact payload and a concrete fallback."""

from __future__ import annotations

from typing import Any


class HermesError(Exception):
    """Base class for all Hermes-Prime failures."""

    def __init__(self, message: str, *, payload: Any = None, fallback: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.payload = payload
        self.fallback = fallback

    def to_envelope(self) -> dict[str, Any]:
        return {
            "type": self.__class__.__name__,
            "message": self.message,
            "http_status": getattr(self, "status", None),
            "provider_payload": self.payload,
            "fallback": self.fallback or "see operator runbook",
        }


class LLMError(HermesError):
    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        payload: Any = None,
        retryable: bool = False,
        fallback: str | None = None,
    ) -> None:
        super().__init__(message, payload=payload, fallback=fallback)
        self.status = status
        self.retryable = retryable
        if self.fallback is None:
            self.fallback = "fail over to the next model in the tier chain, then degrade to Tier-1 answer"


class LLMTimeoutError(LLMError):
    def __init__(self, message: str, *, status: int | None = None, payload: Any = None, fallback: str | None = None):
        super().__init__(message, status=status, payload=payload, retryable=False, fallback=fallback)
        if self.fallback is None:
            self.fallback = "reduce max_tokens / split the payload, or route to Tier-3 (large-context model)"


class MissingCredentialError(HermesError):
    """Raised when a required provider API key is absent from the environment."""

    def __init__(self, env_var: str) -> None:
        super().__init__(
            f"Missing credential: environment variable {env_var!r} is not set",
            payload={"env_var": env_var},
            fallback=(
                f"set {env_var} in the environment (see .env.example), "
                "or run with --offline for a no-credential self-test"
            ),
        )
        self.env_var = env_var


class TelegramError(HermesError):
    """A Telegram Bot API call failed (non-2xx, ok=false, or transport error)."""

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        payload: Any = None,
        fallback: str | None = None,
    ) -> None:
        super().__init__(message, payload=payload, fallback=fallback)
        self.status = status
        if self.fallback is None:
            self.fallback = (
                "inspect the exact Telegram error payload above; for 429 honour retry_after, "
                "for 400 re-send without parse_mode, and never fabricate a delivery success"
            )


class DocumentError(HermesError):
    """A Telegram document could not be ingested (too large, unsupported, corrupt)."""

    def __init__(
        self,
        message: str,
        *,
        payload: Any = None,
        fallback: str | None = None,
    ) -> None:
        super().__init__(message, payload=payload, fallback=fallback)
        if self.fallback is None:
            self.fallback = (
                "send a supported file (.txt/.py/.json/.log or .pdf) under 20 MB; "
                "for other types, paste the relevant excerpt as text"
            )


class BudgetExceededError(HermesError):
    """Daily token budget is exhausted AND the request is too large for Tier-1.

    Raised *instead of* degrading an oversized request (e.g. a large document that
    was pinned to Tier-3) down to the cheap tier. Tier-1's context window is far
    smaller than Tier-3's, so degrading would only overflow it and fail with a
    confusing upstream ``context_length_exceeded``. Failing fast here returns a
    clear, actionable message and spends zero tokens.
    """

    def __init__(
        self,
        message: str,
        *,
        payload: Any = None,
        fallback: str | None = None,
    ) -> None:
        super().__init__(message, payload=payload, fallback=fallback)
        if self.fallback is None:
            self.fallback = (
                "retry after the daily budget resets at 00:00 UTC, send a smaller "
                "excerpt, or raise HERMES_DAILY_TOKEN_BUDGET"
            )


class ToolExecutionError(HermesError):
    def __init__(
        self,
        tool: str,
        message: str,
        *,
        payload: Any = None,
        fallback: str = "retry once with corrected arguments; if it fails again, continue without the tool and state the gap",
    ) -> None:
        super().__init__(message, payload=payload, fallback=fallback)
        self.tool = tool

    def to_envelope(self) -> dict[str, Any]:
        envelope = super().to_envelope()
        envelope["tool"] = self.tool
        return envelope


class SecurityViolation(ToolExecutionError):
    """Raised when a guard rejects a dangerous operation."""

    def __init__(self, tool: str, message: str, *, payload: Any = None) -> None:
        super().__init__(
            tool,
            message,
            payload=payload,
            fallback="operation is permanently denied by policy; restate the request within allowed bounds",
        )


class VoiceError(HermesError):
    """A speech-to-text (Gemini via Tier-3) or text-to-speech (edge-tts) call failed.

    Carries the exact provider payload plus a concrete fallback, like every other
    error here. STT failures are user-facing (we could not hear them); TTS
    failures are non-fatal — the text answer is already delivered, so the caller
    logs the payload and continues rather than surfacing a scary error.
    """

    def __init__(
        self,
        message: str,
        *,
        stage: str = "voice",  # "stt" | "tts" | "download"
        status: int | None = None,
        payload: Any = None,
        fallback: str | None = None,
    ) -> None:
        super().__init__(message, payload=payload, fallback=fallback)
        self.stage = stage
        self.status = status
        if self.fallback is None:
            self.fallback = (
                "check the provider key/egress and the exact payload above; "
                "the text answer is unaffected — never fabricate a transcript or audio"
            )

    def to_envelope(self) -> dict[str, Any]:
        envelope = super().to_envelope()
        envelope["stage"] = self.stage
        return envelope
