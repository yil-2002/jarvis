"""Async multi-provider LLM client: retries, circuit breaker, tier failover, JSON mode."""

from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from dataclasses import dataclass, field
from typing import Any, Protocol

import aiohttp

from .config import ModelProfile, RetryPolicy, Tier
from .errors import LLMError, LLMTimeoutError, ToolExecutionError  # noqa: F401  (re-export)
from .schemas import parse_tool_args

log = logging.getLogger("hermes.llm")

DEFAULT_HEADERS = {
    "Content-Type": "application/json",
    "User-Agent": "hermes-prime/1.0 (+https://github.com/local/hermes)",
}


class LLMTransport(Protocol):
    """Seam for dependency injection (real HTTP in prod, fake in tests)."""

    async def complete(
        self,
        profile: ModelProfile,
        model: str,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None,
        json_mode: bool,
        max_tokens: int,
        temperature: float,
        timeout_s: float,
    ) -> dict[str, Any]: ...


@dataclass(slots=True)
class LLMResult:
    text: str
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    finish_reason: str | None = None
    usage: dict[str, int] = field(default_factory=dict)
    model: str = ""
    tier: Tier = Tier.T1
    latency_ms: int = 0
    attempts: int = 1
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def wants_tools(self) -> bool:
        return bool(self.tool_calls)


class HTTPTransport:
    """OpenAI-compatible /chat/completions transport (Groq, OpenRouter, Gemini via OR)."""

    def __init__(self, session: aiohttp.ClientSession | None = None) -> None:
        self._session = session
        self._owns_session = session is None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=600, connect=10),
                connector=aiohttp.TCPConnector(limit=20, ttl_dns_cache=300),
            )
            self._owns_session = True
        return self._session

    async def close(self) -> None:
        if self._owns_session and self._session is not None and not self._session.closed:
            await self._session.close()

    async def complete(
        self,
        profile: ModelProfile,
        model: str,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None,
        json_mode: bool,
        max_tokens: int,
        temperature: float,
        timeout_s: float,
    ) -> dict[str, Any]:
        url = profile.base_url.rstrip("/") + "/chat/completions"
        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        if json_mode and profile.supports_json_mode:
            payload["response_format"] = {"type": "json_object"}

        headers = dict(DEFAULT_HEADERS)
        headers["Authorization"] = f"Bearer {profile.api_key}"
        if profile.provider == "openrouter":
            headers["HTTP-Referer"] = "https://hermes.local"
            headers["X-Title"] = "Hermes-Prime"

        session = await self._get_session()
        async with session.post(
            url,
            json=payload,
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=timeout_s),
        ) as resp:
            body = await resp.text()
            if resp.status >= 400:
                raise LLMError(
                    message=f"{profile.provider} HTTP {resp.status} for model {model}",
                    status=resp.status,
                    payload=_safe_json(body),
                    retryable=resp.status in profile.retry.retry_on_status,
                )
            return _safe_json(body, raise_on_failure=True)


def _safe_json(text: str, *, raise_on_failure: bool = False) -> dict[str, Any]:
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        if raise_on_failure:
            raise LLMError(
                message="Provider returned non-JSON body", status=None, payload=text[:2000], retryable=True
            ) from exc
        return {"raw": text[:2000]}
    return data if isinstance(data, dict) else {"raw": data}


class _CircuitBreaker:
    """Trips open after N consecutive failures; half-opens after cooldown."""

    def __init__(self, failure_threshold: int = 3, cooldown_s: float = 45.0) -> None:
        self._failures: dict[str, int] = {}
        self._opened_at: dict[str, float] = {}
        self.threshold = failure_threshold
        self.cooldown_s = cooldown_s

    def allow(self, key: str) -> bool:
        opened = self._opened_at.get(key)
        if opened is None:
            return True
        if time.monotonic() - opened >= self.cooldown_s:
            return True  # half-open: permit one probe
        return False

    def record_success(self, key: str) -> None:
        self._failures.pop(key, None)
        self._opened_at.pop(key, None)

    def record_failure(self, key: str) -> None:
        count = self._failures.get(key, 0) + 1
        self._failures[key] = count
        if count >= self.threshold:
            self._opened_at[key] = time.monotonic()


class LLMClient:
    """Tier-aware completion client with backoff retries and cross-model failover."""

    def __init__(
        self,
        profiles: dict[Tier, ModelProfile],
        transport: LLMTransport | None = None,
        breaker: _CircuitBreaker | None = None,
    ) -> None:
        self.profiles = profiles
        self.transport: LLMTransport = transport or HTTPTransport()
        self.breaker = breaker or _CircuitBreaker()

    async def close(self) -> None:
        closer = getattr(self.transport, "close", None)
        if closer is not None:
            await closer()

    async def complete(
        self,
        tier: Tier,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        json_mode: bool = False,
        max_tokens: int | None = None,
        temperature: float | None = None,
    ) -> LLMResult:
        profile = self.profiles[tier]
        candidates = (profile.model, *profile.failover)
        last_error: LLMError | None = None

        for model in candidates:
            breaker_key = f"{tier.value}:{model}"
            if not self.breaker.allow(breaker_key):
                log.warning("circuit open, skipping %s", breaker_key)
                continue
            try:
                result = await self._attempt_with_retry(
                    profile,
                    model,
                    messages,
                    tools=tools,
                    json_mode=json_mode,
                    max_tokens=max_tokens or profile.max_output_tokens,
                    temperature=profile.temperature if temperature is None else temperature,
                )
            except LLMError as exc:
                last_error = exc
                self.breaker.record_failure(breaker_key)
                log.error("tier=%s model=%s failed: %s (status=%s)", tier.value, model, exc, exc.status)
                continue
            self.breaker.record_success(breaker_key)
            result.tier = tier
            result.model = model
            return result

        raise LLMError(
            message=f"All candidates exhausted for {tier.value}",
            status=last_error.status if last_error else None,
            payload={
                "tier": tier.value,
                "tried": list(candidates),
                "last_error": str(last_error) if last_error else "unknown",
                "last_payload": last_error.payload if last_error else None,
            },
            retryable=False,
        )

    async def _attempt_with_retry(
        self,
        profile: ModelProfile,
        model: str,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None,
        json_mode: bool,
        max_tokens: int,
        temperature: float,
    ) -> LLMResult:
        policy: RetryPolicy = profile.retry
        started = time.monotonic()
        attempt = 0
        while True:
            attempt += 1
            try:
                raw = await self.transport.complete(
                    profile,
                    model,
                    messages,
                    tools=tools,
                    json_mode=json_mode,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    timeout_s=profile.timeout_s,
                )
                break
            except TimeoutError as exc:
                if attempt >= policy.attempts:
                    raise LLMTimeoutError(
                        message=f"timeout after {attempt} attempt(s) on {model}",
                        status=None,
                        payload={"timeout_s": profile.timeout_s, "model": model},
                    ) from exc
                await self._sleep(policy, attempt)
            except LLMError as exc:
                if not exc.retryable or attempt >= policy.attempts:
                    raise
                await self._sleep(policy, attempt)
            except aiohttp.ClientError as exc:
                if attempt >= policy.attempts:
                    raise LLMError(
                        message=f"transport error: {exc.__class__.__name__}: {exc}",
                        status=None,
                        payload={"model": model, "error": str(exc)},
                        retryable=False,
                    ) from exc
                await self._sleep(policy, attempt)

        return self._normalise(raw, latency_ms=int((time.monotonic() - started) * 1000), attempts=attempt)

    @staticmethod
    async def _sleep(policy: RetryPolicy, attempt: int) -> None:
        delay = min(policy.max_delay_s, policy.base_delay_s * (policy.backoff_factor ** (attempt - 1)))
        delay += random.uniform(0, policy.jitter * delay)
        await asyncio.sleep(delay)

    @staticmethod
    def _normalise(raw: dict[str, Any], *, latency_ms: int, attempts: int) -> LLMResult:
        choices = raw.get("choices") or []
        if not choices:
            raise LLMError(
                message="provider response contained no choices",
                status=None,
                payload=raw,
                retryable=True,
            )
        message = choices[0].get("message") or {}
        text = (message.get("content") or "").strip()
        tool_calls: list[dict[str, Any]] = []
        for tc in message.get("tool_calls") or []:
            fn = tc.get("function") or {}
            name = fn.get("name")
            if not name:
                continue
            try:
                args = parse_tool_args(name, fn.get("arguments"))
                arg_error = None
            except Exception as exc:  # SchemaViolation or JSON error
                args, arg_error = {}, str(exc)
            tool_calls.append(
                {
                    "id": tc.get("id") or f"call_{len(tool_calls)}",
                    "name": name,
                    "arguments": args,
                    "argument_error": arg_error,
                }
            )
        usage_raw = raw.get("usage") or {}
        usage = {
            k: int(v)
            for k, v in usage_raw.items()
            if k in {"prompt_tokens", "completion_tokens", "total_tokens"} and isinstance(v, (int, float))
        }
        return LLMResult(
            text=text,
            tool_calls=tool_calls,
            finish_reason=choices[0].get("finish_reason"),
            usage=usage,
            latency_ms=latency_ms,
            attempts=attempts,
            raw=raw,
        )


def extract_json(text: str) -> Any:
    """Tolerant JSON extraction for models that wrap output in prose/fences."""

    if not text:
        raise ValueError("empty completion")
    candidate = text.strip()
    if candidate.startswith("```"):
        candidate = candidate.strip("`")
        if candidate.lower().startswith("json"):
            candidate = candidate[4:]
        candidate = candidate.strip()
    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        pass
    for opener, closer in (("{", "}"), ("[", "]")):
        start, end = candidate.find(opener), candidate.rfind(closer)
        if start != -1 and end > start:
            try:
                return json.loads(candidate[start : end + 1])
            except json.JSONDecodeError:
                continue
    raise ValueError(f"no JSON object found in completion: {text[:300]!r}")
