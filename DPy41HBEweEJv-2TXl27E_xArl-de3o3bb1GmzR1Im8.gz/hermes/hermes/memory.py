"""Persistent memory: raw messages, compressed summaries, fact triplets (Subject -> Predicate -> Object).

Compression policy: every N messages the oldest window is folded into
  - one dense summary (<= max_summary_chars)
  - up to K fact triplets
so the VPS keeps a tiny SQLite footprint while the model keeps semantic continuity.
"""

from __future__ import annotations

import json
import logging
import re
import sqlite3
import threading
import time
import uuid
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any

from .config import MemoryConfig
from .schemas import TRIPLET_LIST_SCHEMA, validate

log = logging.getLogger("hermes.memory")

_SCHEMA: str = """
CREATE TABLE IF NOT EXISTS sessions (
    session_id  TEXT PRIMARY KEY,
    created_at  REAL NOT NULL,
    updated_at  REAL NOT NULL,
    meta        TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS messages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  TEXT NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
    role        TEXT NOT NULL CHECK (role IN ('system','user','assistant','tool')),
    content     TEXT NOT NULL DEFAULT '',
    tool_calls  TEXT,
    name        TEXT,
    tokens_est  INTEGER NOT NULL DEFAULT 0,
    created_at  REAL NOT NULL,
    compressed  INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, id);
CREATE INDEX IF NOT EXISTS idx_messages_uncompressed ON messages(session_id, compressed, id);

CREATE TABLE IF NOT EXISTS summaries (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  TEXT NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
    from_msg_id INTEGER NOT NULL,
    to_msg_id   INTEGER NOT NULL,
    summary     TEXT NOT NULL,
    open_questions TEXT NOT NULL DEFAULT '[]',
    model       TEXT,
    created_at  REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_summaries_session ON summaries(session_id, id);

CREATE TABLE IF NOT EXISTS fact_triplets (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  TEXT NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
    subject     TEXT NOT NULL,
    predicate   TEXT NOT NULL,
    object      TEXT NOT NULL,
    confidence  REAL NOT NULL DEFAULT 0.8,
    source      TEXT NOT NULL DEFAULT 'inferred',
    created_at  REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_triplets_subject ON fact_triplets(subject);
CREATE INDEX IF NOT EXISTS idx_triplets_session ON fact_triplets(session_id, id);

CREATE TABLE IF NOT EXISTS audit_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          REAL NOT NULL,
    session_id  TEXT,
    step        TEXT NOT NULL,
    tier        TEXT,
    model       TEXT,
    ok          INTEGER NOT NULL DEFAULT 1,
    latency_ms  INTEGER,
    tokens_in   INTEGER,
    tokens_out  INTEGER,
    detail      TEXT
);
CREATE INDEX IF NOT EXISTS idx_audit_session ON audit_log(session_id, id);

CREATE TABLE IF NOT EXISTS spend_ledger (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    day         TEXT NOT NULL,
    ts          REAL NOT NULL,
    session_id  TEXT,
    tier        TEXT,
    model       TEXT,
    tokens_in   INTEGER NOT NULL DEFAULT 0,
    tokens_out  INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_spend_day ON spend_ledger(day, id);
"""

_FTS_SCHEMA: str = """
CREATE VIRTUAL TABLE IF NOT EXISTS triplets_fts USING fts5(
    subject, predicate, object, content='fact_triplets', content_rowid='id', tokenize='porter unicode61'
);
CREATE TRIGGER IF NOT EXISTS triplets_ai AFTER INSERT ON fact_triplets BEGIN
    INSERT INTO triplets_fts(rowid, subject, predicate, object)
    VALUES (new.id, new.subject, new.predicate, new.object);
END;
CREATE TRIGGER IF NOT EXISTS triplets_ad AFTER DELETE ON fact_triplets BEGIN
    INSERT INTO triplets_fts(triplets_fts, rowid, subject, predicate, object)
    VALUES ('delete', old.id, old.subject, old.predicate, old.object);
END;
"""

_WORD_RE = re.compile(r"[A-Za-z0-9_À-ÿЀ-ӿ]{3,}")


@dataclass(slots=True)
class StoredMessage:
    id: int
    role: str
    content: str
    tool_calls: list[dict[str, Any]] | None
    name: str | None
    tokens_est: int


def estimate_tokens(text: str, chars_per_token: float = 3.6) -> int:
    if not text:
        return 0
    return max(1, int(len(text) / chars_per_token))


class MemoryStore:
    """SQLite store with thread-local connections.

    A single ``sqlite3.Connection`` must never be used concurrently from more
    than one thread: cursor state corrupts mid-iteration, surfacing as
    ``InterfaceError: bad parameter or other API misuse`` or ``IndexError``.
    The orchestrator writes from the event-loop thread while tools read via
    ``asyncio.to_thread`` workers, so each thread lazily opens its OWN
    connection to the same WAL file. WAL permits many concurrent readers plus
    one writer, and ``busy_timeout`` serialises any occasional write overlap.
    All writes happen on the event-loop thread (never inside ``to_thread``), so
    they are already ordered; the per-thread connections only isolate reads.
    """

    def __init__(self, cfg: MemoryConfig) -> None:
        self.cfg = cfg
        self._has_fts = False
        self._local = threading.local()
        self._all_conns: list[sqlite3.Connection] = []
        self._conns_lock = threading.Lock()
        # Primary connection: runs the schema migration once, on this thread.
        self._open_connection(initialize_schema=True)

    # -- lifecycle ---------------------------------------------------------
    @property
    def _conn(self) -> sqlite3.Connection:
        """This thread's connection, created lazily on first use."""

        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = self._open_connection(initialize_schema=False)
        return conn

    def _open_connection(self, *, initialize_schema: bool) -> sqlite3.Connection:
        conn = sqlite3.connect(self.cfg.db_path, timeout=10.0, isolation_level=None, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")    # persistent in the file; harmless to re-assert
        conn.execute("PRAGMA synchronous=NORMAL")   # per-connection
        conn.execute("PRAGMA foreign_keys=ON")      # per-connection
        conn.execute("PRAGMA busy_timeout=5000")    # per-connection
        if initialize_schema:
            conn.executescript(_SCHEMA)
            try:
                conn.executescript(_FTS_SCHEMA)
                self._has_fts = True
            except sqlite3.Error as exc:  # FTS5 missing in some builds
                log.info("FTS5 unavailable, using LIKE-based recall: %s", exc)
        with self._conns_lock:
            self._all_conns.append(conn)
        self._local.conn = conn
        return conn

    def close(self) -> None:
        with self._conns_lock:
            conns = list(self._all_conns)
            self._all_conns.clear()
        for conn in conns:
            try:
                conn.close()
            except sqlite3.Error:  # pragma: no cover
                pass
        self._local.conn = None

    # -- sessions & messages ----------------------------------------------
    def ensure_session(self, session_id: str | None = None, **meta: Any) -> str:
        sid = session_id or uuid.uuid4().hex[:16]
        now = time.time()
        self._conn.execute(
            """INSERT INTO sessions(session_id, created_at, updated_at, meta) VALUES (?,?,?,?)
               ON CONFLICT(session_id) DO UPDATE SET updated_at=excluded.updated_at""",
            (sid, now, now, json.dumps(meta, ensure_ascii=False)),
        )
        return sid

    def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        *,
        tool_calls: list[dict[str, Any]] | None = None,
        name: str | None = None,
    ) -> int:
        cur = self._conn.execute(
            """INSERT INTO messages(session_id, role, content, tool_calls, name, tokens_est, created_at)
               VALUES (?,?,?,?,?,?,?)""",
            (
                session_id,
                role,
                content or "",
                json.dumps(tool_calls, ensure_ascii=False) if tool_calls else None,
                name,
                estimate_tokens(content or ""),
                time.time(),
            ),
        )
        self._conn.execute("UPDATE sessions SET updated_at=? WHERE session_id=?", (time.time(), session_id))
        return int(cur.lastrowid or 0)

    def uncompressed_count(self, session_id: str) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) AS n FROM messages WHERE session_id=? AND compressed=0", (session_id,)
        ).fetchone()
        return int(row["n"] if row else 0)

    def recent_messages(self, session_id: str, limit: int | None = None) -> list[StoredMessage]:
        limit = limit or self.cfg.keep_recent_messages
        rows = self._conn.execute(
            """SELECT id, role, content, tool_calls, name, tokens_est FROM messages
               WHERE session_id=? AND compressed=0 ORDER BY id DESC LIMIT ?""",
            (session_id, limit),
        ).fetchall()
        out = [
            StoredMessage(
                id=r["id"],
                role=r["role"],
                content=r["content"],
                tool_calls=json.loads(r["tool_calls"]) if r["tool_calls"] else None,
                name=r["name"],
                tokens_est=r["tokens_est"],
            )
            for r in reversed(rows)
        ]
        return out

    # -- compression -------------------------------------------------------
    def pending_window(self, session_id: str) -> list[StoredMessage]:
        """Oldest uncompressed messages that fall outside the recent-keep window."""

        rows = self._conn.execute(
            """SELECT id, role, content, tool_calls, name, tokens_est FROM messages
               WHERE session_id=? AND compressed=0
               ORDER BY id DESC LIMIT -1 OFFSET ?""",
            (session_id, self.cfg.keep_recent_messages),
        ).fetchall()
        return [
            StoredMessage(
                id=r["id"],
                role=r["role"],
                content=r["content"],
                tool_calls=json.loads(r["tool_calls"]) if r["tool_calls"] else None,
                name=r["name"],
                tokens_est=r["tokens_est"],
            )
            for r in rows
        ]

    def commit_compression(
        self,
        session_id: str,
        message_ids: Iterable[int],
        payload: dict[str, Any],
        *,
        model: str | None = None,
    ) -> dict[str, int]:
        """Persist an LLM-produced (or heuristic) compression payload and mark messages folded."""

        validated = validate(TRIPLET_LIST_SCHEMA, payload, schema_name="compression")
        ids = [int(i) for i in message_ids]
        if not ids:
            return {"summaries": 0, "triplets": 0}
        now = time.time()
        summary = validated["summary"][: self.cfg.max_summary_chars]
        self._conn.execute(
            """INSERT INTO summaries(session_id, from_msg_id, to_msg_id, summary, open_questions, model, created_at)
               VALUES (?,?,?,?,?,?,?)""",
            (
                session_id,
                min(ids),
                max(ids),
                summary,
                json.dumps(validated.get("open_questions", []), ensure_ascii=False),
                model,
                now,
            ),
        )
        triplets = validated.get("triplets", [])[: self.cfg.max_triplets_per_summary]
        self._conn.executemany(
            """INSERT INTO fact_triplets(session_id, subject, predicate, object, confidence, source, created_at)
               VALUES (?,?,?,?,?,?,?)""",
            [
                (
                    session_id,
                    t["subject"].strip(),
                    t["predicate"].strip(),
                    t["object"].strip(),
                    float(t.get("confidence", 0.8)),
                    t.get("source", "inferred"),
                    now,
                )
                for t in triplets
                if t.get("subject") and t.get("predicate") and t.get("object")
            ],
        )
        self._conn.executemany(
            "UPDATE messages SET compressed=1 WHERE id=? AND session_id=?", [(i, session_id) for i in ids]
        )
        self._prune(session_id)
        return {"summaries": 1, "triplets": len(triplets)}

    def _prune(self, session_id: str) -> None:
        """Keep the DB flat: bounded history per session."""

        self._conn.execute(
            """DELETE FROM summaries WHERE session_id=? AND id NOT IN (
                 SELECT id FROM summaries WHERE session_id=? ORDER BY id DESC LIMIT 50)""",
            (session_id, session_id),
        )
        self._conn.execute(
            """DELETE FROM fact_triplets WHERE session_id=? AND id NOT IN (
                 SELECT id FROM fact_triplets WHERE session_id=? ORDER BY id DESC LIMIT 2000)""",
            (session_id, session_id),
        )

    # -- recall ------------------------------------------------------------
    def recall(
        self, query: str, *, top_k: int = 8, scope: str = "all", session_id: str | None = None
    ) -> dict[str, Any]:
        terms = _tokenize(query)
        triplets: list[dict[str, Any]] = []
        summaries: list[dict[str, Any]] = []
        if scope in {"triplets", "all"}:
            triplets = self._recall_triplets(terms, top_k=top_k, session_id=session_id)
        if scope in {"summaries", "all"}:
            summaries = self._recall_summaries(terms, top_k=max(3, top_k // 2), session_id=session_id)
        return {"query": query, "terms": terms, "triplets": triplets, "summaries": summaries}

    def _recall_triplets(self, terms: list[str], *, top_k: int, session_id: str | None) -> list[dict[str, Any]]:
        if self._has_fts and terms:
            match = " OR ".join(f'"{t}"' for t in terms[:6])
            where = ["triplets_fts MATCH ?"]
            args: list[Any] = [match]
            if session_id:
                where.append("t.session_id = ?")
                args.append(session_id)
            sql = (
                "SELECT t.id, t.subject, t.predicate, t.object, t.confidence, t.source, t.session_id, "
                "bm25(triplets_fts) AS rank "
                "FROM triplets_fts JOIN fact_triplets t ON t.id = triplets_fts.rowid "
                "WHERE " + " AND ".join(where) + " ORDER BY rank LIMIT ?"
            )
            args.append(top_k)
            try:
                return [dict(r) for r in self._conn.execute(sql, args).fetchall()]
            except sqlite3.Error as exc:  # malformed MATCH expression
                log.warning("FTS recall failed (%s); falling back to LIKE", exc)
        sql = """SELECT id, subject, predicate, object, confidence, source, session_id FROM fact_triplets"""
        args: list[Any] = []
        where: list[str] = []
        if session_id:
            where.append("session_id = ?")
            args.append(session_id)
        search_terms = terms[:6]
        if search_terms:
            where.append(
                "("
                + " OR ".join(["(subject LIKE ? OR predicate LIKE ? OR object LIKE ?)"] * len(search_terms))
                + ")"
            )
            for t in search_terms:
                args += [f"%{t}%"] * 3
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY id DESC LIMIT ?"
        args.append(top_k)
        return [dict(r) for r in self._conn.execute(sql, args).fetchall()]

    def _recall_summaries(self, terms: list[str], *, top_k: int, session_id: str | None) -> list[dict[str, Any]]:
        sql = "SELECT id, session_id, summary, open_questions, created_at FROM summaries"
        args: list[Any] = []
        if session_id:
            sql += " WHERE session_id = ?"
            args.append(session_id)
            if terms:
                sql += " AND (" + " OR ".join(["summary LIKE ?"] * len(terms[:6])) + ")"
                args += [f"%{t}%" for t in terms[:6]]
        elif terms:
            sql += " WHERE " + " OR ".join(["summary LIKE ?"] * len(terms[:6]))
            args += [f"%{t}%" for t in terms[:6]]
        sql += " ORDER BY id DESC LIMIT ?"
        args.append(top_k)
        return [dict(r) for r in self._conn.execute(sql, args).fetchall()]

    def context_block(self, session_id: str, *, top_k: int | None = None) -> str:
        """Rendered memory preamble injected into the system prompt."""

        summaries = self._conn.execute(
            "SELECT summary FROM summaries WHERE session_id=? ORDER BY id DESC LIMIT 3", (session_id,)
        ).fetchall()
        triplets = self._conn.execute(
            """SELECT subject, predicate, object FROM fact_triplets
               WHERE session_id=? ORDER BY confidence DESC, id DESC LIMIT ?""",
            (session_id, top_k or self.cfg.top_k_triplets),
        ).fetchall()
        if not summaries and not triplets:
            return ""
        parts: list[str] = ["## PERSISTENT MEMORY (compressed)"]
        for s in summaries:
            parts.append(f"### Summary\n{s['summary']}")
        if triplets:
            parts.append("### Fact triplets")
            parts.extend(f"- ({t['subject']}) -> [{t['predicate']}] -> ({t['object']})" for t in triplets)
        return "\n".join(parts)

    # -- audit -------------------------------------------------------------
    def audit(
        self,
        *,
        session_id: str | None,
        step: str,
        tier: str | None = None,
        model: str | None = None,
        ok: bool = True,
        latency_ms: int | None = None,
        tokens_in: int | None = None,
        tokens_out: int | None = None,
        detail: Any = None,
    ) -> None:
        self._conn.execute(
            """INSERT INTO audit_log(ts, session_id, step, tier, model, ok, latency_ms, tokens_in, tokens_out, detail)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (
                time.time(),
                session_id,
                step,
                tier,
                model,
                1 if ok else 0,
                latency_ms,
                tokens_in,
                tokens_out,
                json.dumps(detail, ensure_ascii=False, default=str) if detail is not None else None,
            ),
        )

    def recent_audit(self, limit: int = 50) -> list[dict[str, Any]]:
        return [dict(r) for r in self._conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,))]

    # -- spend ledger (cost guard) ----------------------------------------
    @staticmethod
    def _utc_day(ts: float | None = None) -> str:
        return time.strftime("%Y-%m-%d", time.gmtime(ts if ts is not None else time.time()))

    def record_spend(
        self,
        *,
        session_id: str | None,
        tier: str | None,
        model: str | None,
        tokens_in: int,
        tokens_out: int,
    ) -> None:
        """Append one completion's token usage to the daily spend ledger."""

        self._conn.execute(
            """INSERT INTO spend_ledger(day, ts, session_id, tier, model, tokens_in, tokens_out)
               VALUES (?,?,?,?,?,?,?)""",
            (
                self._utc_day(),
                time.time(),
                session_id,
                tier,
                model,
                max(0, int(tokens_in or 0)),
                max(0, int(tokens_out or 0)),
            ),
        )

    def daily_tokens(self, day: str | None = None) -> int:
        """Total tokens (in+out) recorded for a UTC day (default: today)."""

        row = self._conn.execute(
            "SELECT COALESCE(SUM(tokens_in + tokens_out), 0) FROM spend_ledger WHERE day = ?",
            (day or self._utc_day(),),
        ).fetchone()
        return int(row[0] or 0)

    # -- retention / maintenance ------------------------------------------
    def prune_audit(self) -> int:
        """Apply the audit_log retention policy; return the number of rows deleted.

        Two independent bounds, both opt-out via 0:
          - TTL: drop rows older than ``audit_retention_days``.
          - row cap: keep only the newest ``audit_max_rows`` regardless of age.
        The cap protects against a burst that writes faster than the TTL clears.
        """

        conn = self._conn
        deleted = 0
        days = self.cfg.audit_retention_days
        if days and days > 0:
            cutoff = time.time() - days * 86_400
            cur = conn.execute("DELETE FROM audit_log WHERE ts < ?", (cutoff,))
            deleted += cur.rowcount or 0
        cap = self.cfg.audit_max_rows
        if cap and cap > 0:
            cur = conn.execute(
                """DELETE FROM audit_log WHERE id NOT IN (
                     SELECT id FROM audit_log ORDER BY id DESC LIMIT ?)""",
                (cap,),
            )
            deleted += cur.rowcount or 0
        return deleted

    def maintenance(self) -> dict[str, Any]:
        """Periodic disk-hygiene pass for a small Hetzner volume.

        Prunes the audit log, refreshes the query planner, then truncates the WAL
        so ``-wal`` cannot grow unbounded between checkpoints. Safe to call on the
        primary connection while other threads hold their own read connections
        (WAL allows one writer + many readers; ``busy_timeout`` serialises overlap).
        """

        deleted = self.prune_audit()
        conn = self._conn
        # The spend ledger only needs the recent window for the daily budget guard;
        # keep the same TTL as the audit log so neither table grows unbounded.
        spend_deleted = 0
        days = self.cfg.audit_retention_days
        if days and days > 0:
            cutoff_day = self._utc_day(time.time() - days * 86_400)
            cur = conn.execute("DELETE FROM spend_ledger WHERE day < ?", (cutoff_day,))
            spend_deleted = cur.rowcount or 0
        conn.execute("PRAGMA optimize")  # incremental ANALYZE; cheap, planner-friendly
        # TRUNCATE resets the -wal file to zero bytes after flushing it into the DB.
        row = conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
        ckpt = tuple(row) if row is not None else ()
        log.info(
            "maintenance: pruned %d audit + %d spend row(s); wal_checkpoint(TRUNCATE)=%s",
            deleted, spend_deleted, ckpt,
        )
        return {
            "audit_rows_pruned": deleted,
            "spend_rows_pruned": spend_deleted,
            "wal_checkpoint": list(ckpt),
        }


def _tokenize(text: str) -> list[str]:
    return list(dict.fromkeys(w.lower() for w in _WORD_RE.findall(text or "")))[:8]


def heuristic_compression(messages: Iterable[StoredMessage], *, max_summary_chars: int) -> dict[str, Any]:
    """Deterministic fallback used when the Tier-1 compressor call fails.

    Keeps the pipeline honest: no invented facts, only extractive snippets.
    """

    triplets: list[dict[str, Any]] = []
    lines: list[str] = []
    for m in messages:
        snippet = re.sub(r"\s+", " ", m.content or "").strip()
        if not snippet:
            continue
        lines.append(f"{m.role}: {snippet[:240]}")
        for sentence in re.split(r"(?<=[.!?])\s+", snippet)[:4]:
            if len(sentence) < 20:
                continue
            subj, pred, obj = _split_sentence(sentence)
            if subj and pred and obj:
                triplets.append({"subject": subj, "predicate": pred, "object": obj, "confidence": 0.5, "source": "inferred"})
            if len(triplets) >= 12:
                break
    summary = "[heuristic-extractive] " + " | ".join(lines)
    return {"summary": summary[:max_summary_chars], "triplets": triplets[:12], "open_questions": []}


def _split_sentence(sentence: str) -> tuple[str, str, str]:
    for verb in (" must ", " should ", " uses ", " used ", " requires ", " is ", " are ", " will ", " has ", " have "):
        if verb in sentence.lower():
            idx = sentence.lower().index(verb)
            subj = sentence[:idx].strip(" ,;:")
            pred = verb.strip()
            obj = sentence[idx + len(verb) :].strip(" ,;:.")
            return subj[:120], pred[:120], obj[:400]
    return "", "", ""
