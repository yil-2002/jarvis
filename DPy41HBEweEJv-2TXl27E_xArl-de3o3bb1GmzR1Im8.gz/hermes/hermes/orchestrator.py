"""Hermes-Prime orchestrator: route -> tool loop -> answer -> compress memory."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from dataclasses import asdict, dataclass, field
from typing import Any

import aiohttp

from .config import Settings, Tier, load_settings
from .errors import BudgetExceededError, LLMError
from .llm import LLMClient, LLMResult, LLMTransport
from .memory import MemoryStore, estimate_tokens, heuristic_compression
from .router import RouteDecision, Router
from .schemas import SchemaViolation, openai_tools_payload
from .tools import ToolRegistry, build_registry

log = logging.getLogger("hermes.orchestrator")

DEFAULT_SYSTEM_PROMPT_PATH = "prompts/HERMES_CORE_SYSTEM.md"


@dataclass(slots=True)
class Step:
    index: int
    tier: str
    model: str
    kind: str  # "completion" | "tool"
    name: str = ""
    ok: bool = True
    latency_ms: int = 0
    tokens_in: int = 0
    tokens_out: int = 0
    detail: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class AgentResponse:
    session_id: str
    text: str
    tier: str
    model: str
    intent: str
    routing_source: str
    plan: list[str]
    tool_results: list[dict[str, Any]]
    steps: list[Step]
    usage: dict[str, int]
    total_latency_ms: int
    errors: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "answer": self.text,
            "tier": self.tier,
            "model": self.model,
            "intent": self.intent,
            "routing_source": self.routing_source,
            "plan": self.plan,
            "tool_results": self.tool_results,
            "steps": [asdict(s) for s in self.steps],
            "usage": self.usage,
            "total_latency_ms": self.total_latency_ms,
            "errors": self.errors,
        }


class HermesOrchestrator:
    def __init__(
        self,
        settings: Settings | None = None,
        *,
        transport: LLMTransport | None = None,
        session: aiohttp.ClientSession | None = None,
        system_prompt: str | None = None,
    ) -> None:
        self.settings = settings or load_settings()
        self._owns_session = session is None
        self._http: aiohttp.ClientSession | None = session
        self.llm = LLMClient(self.settings.profiles, transport=transport)
        self.router = Router(self.llm, self.settings.router)
        self.memory = MemoryStore(self.settings.memory)
        self.registry: ToolRegistry = build_registry(
            lambda: self.http_session,
            executor_cfg=self.settings.executor,
            memory_cfg=self.settings.memory,
            store=self.memory,
        )
        self.system_prompt = system_prompt if system_prompt is not None else _load_system_prompt()
        self._bg_tasks: set[asyncio.Task] = set()

    def _spawn_background(self, coro, *, name: str) -> asyncio.Task:
        """Fire-and-forget task with strong refs + exception logging (no silent deaths)."""

        task = asyncio.create_task(coro, name=name)
        self._bg_tasks.add(task)
        task.add_done_callback(self._bg_tasks.discard)
        task.add_done_callback(_log_task_failure)
        return task


    # -- plumbing ----------------------------------------------------------
    @property
    def http_session(self) -> aiohttp.ClientSession:
        """Lazily created inside the running loop (aiohttp requirement)."""

        if self._http is None or self._http.closed:
            self._http = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=120),
                connector=aiohttp.TCPConnector(limit=20, ttl_dns_cache=300),
            )
            self._owns_session = True
        return self._http

    async def aclose(self) -> None:
        # Let in-flight background compressions finish (bounded) before tearing down.
        if self._bg_tasks:
            pending = [t for t in self._bg_tasks if not t.done()]
            if pending:
                await asyncio.wait(pending, timeout=15.0)
            for t in pending:
                if not t.done():
                    t.cancel()
        await self.llm.close()
        if self._owns_session and self._http is not None and not self._http.closed:
            await self._http.close()
        self.memory.close()

    async def __aenter__(self) -> HermesOrchestrator:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    # -- main entry --------------------------------------------------------
    async def handle(
        self,
        user_text: str,
        *,
        session_id: str | None = None,
        image_urls: list[str] | None = None,
        attachments: int = 0,
        tools_override: list[str] | None = None,
        background_compress: bool = False,
        force_tier: Tier | None = None,
    ) -> AgentResponse:
        started = time.monotonic()
        sid = self.memory.ensure_session(session_id)
        self.memory.add_message(sid, "user", user_text)
        errors: list[dict[str, Any]] = []
        steps: list[Step] = []

        if force_tier is not None:
            # Document / heavy-context ingestion: skip the T1 classifier entirely so a
            # large payload is never sent to the cheap router just to be told "use T3".
            decision = RouteDecision(
                tier=force_tier,
                confidence=1.0,
                intent="document_analysis",
                requires_tools=[],
                plan=[],
                needs_memory=True,
                reasoning="forced tier for document ingestion",
                source="forced",
            )
        else:
            decision = await self.router.route(
                user_text, has_image=bool(image_urls), attachments=attachments
            )

        # Cost guard: once the daily token budget is exhausted, degrade every request
        # to the cheapest tier (T1/Groq) and pin it there -- escalation is blocked via
        # ``budget_limited`` below so a failing T1 call cannot climb back to T2/T3.
        # This overrides force_tier: cost protection is paramount.
        budget = self.settings.memory.daily_token_budget
        budget_limited = False
        if budget > 0 and self.memory.daily_tokens() >= budget:
            budget_limited = True
            # Tier-1's context window is far smaller than Tier-3's. Degrading an oversized
            # payload (e.g. a large document pinned to T3) would just overflow Tier-1 and
            # fail upstream with a confusing context_length_exceeded -- after burning a call
            # and hitting Groq's TPM limit. Fail fast instead with a clear, actionable
            # message. The estimate covers the user payload (a document body lives in
            # user_text); system+memory overhead fits in the headroom below the model cap.
            est_tokens = estimate_tokens(user_text, self.settings.router.chars_per_token)
            t1_cap = self.settings.router.tier1_context_tokens
            if est_tokens > t1_cap:
                log.warning(
                    "budget exhausted and request too large for Tier-1 (%d > %d est. tokens); refusing",
                    est_tokens, t1_cap,
                )
                raise BudgetExceededError(
                    "Kunlik token byudjeti tugaganligi sababli katta hujjatlarni tahlil qilish "
                    "vaqtincha cheklandi. Daily token budget exhausted; this request is too "
                    f"large for Tier-1 ({est_tokens} > {t1_cap} est. tokens).",
                    payload={
                        "estimated_tokens": est_tokens,
                        "tier1_context_tokens": t1_cap,
                        "daily_token_budget": budget,
                    },
                    fallback=(
                        "Byudjet 00:00 UTC da tiklanadi — keyin qayta yuboring; yoki hujjatning "
                        "kichikroq bo'lagini yuboring; yoki HERMES_DAILY_TOKEN_BUDGET ni oshiring."
                    ),
                )
            if decision.tier is not Tier.T1:
                log.warning(
                    "daily token budget exhausted (>= %d); degrading %s -> %s",
                    budget, decision.tier.value, Tier.T1.value,
                )
                decision.tier = Tier.T1
                decision.signals["budget_limited"] = True

        self.memory.audit(
            session_id=sid,
            step="route",
            tier=decision.tier.value,
            ok=True,
            detail=decision.to_dict(),
        )
        steps.append(
            Step(
                index=0,
                tier=decision.tier.value,
                model="",
                kind="route",
                name=decision.intent,
                detail={"source": decision.source, "confidence": decision.confidence, "reasoning": decision.reasoning},
            )
        )

        messages = self._build_messages(sid, user_text, decision, image_urls=image_urls)
        allowed = tools_override if tools_override is not None else decision.requires_tools
        tools = openai_tools_payload(allowed) if allowed else None

        result: LLMResult | None = None
        tool_results: list[dict[str, Any]] = []
        usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        tier_used = decision.tier

        for step_index in range(1, self.settings.router.max_agent_steps + 1):
            try:
                result = await self.llm.complete(tier_used, messages, tools=tools)
            except LLMError as exc:
                errors.append({"stage": "completion", "tier": tier_used.value, **exc.to_envelope()})
                self.memory.audit(
                    session_id=sid, step="completion_error", tier=tier_used.value, ok=False, detail=exc.to_envelope()
                )
                if tier_used is not Tier.T3 and not budget_limited:
                    tier_used = _next_tier(tier_used)
                    log.warning("escalating to %s after upstream failure", tier_used.value)
                    continue
                if budget_limited:
                    # Cost guard active: do not climb to a pricier tier on failure.
                    log.warning("budget limited; not escalating past %s", tier_used.value)
                break

            usage["prompt_tokens"] += result.usage.get("prompt_tokens", 0)
            usage["completion_tokens"] += result.usage.get("completion_tokens", 0)
            usage["total_tokens"] += result.usage.get("total_tokens", 0)
            steps.append(
                Step(
                    index=step_index,
                    tier=tier_used.value,
                    model=result.model,
                    kind="completion",
                    ok=True,
                    latency_ms=result.latency_ms,
                    tokens_in=result.usage.get("prompt_tokens", 0),
                    tokens_out=result.usage.get("completion_tokens", 0),
                    detail={"finish_reason": result.finish_reason, "tool_calls": len(result.tool_calls)},
                )
            )
            self.memory.audit(
                session_id=sid,
                step="completion",
                tier=tier_used.value,
                model=result.model,
                latency_ms=result.latency_ms,
                tokens_in=result.usage.get("prompt_tokens", 0),
                tokens_out=result.usage.get("completion_tokens", 0),
            )

            if not result.wants_tools:
                break

            messages.append(_assistant_message(result))
            executed_any = False
            for call in result.tool_calls:
                name, args = call["name"], call["arguments"]
                if call.get("argument_error"):
                    envelope = {
                        "ok": False,
                        "tool": name,
                        "data": None,
                        "error": {
                            "type": "SchemaViolation",
                            "message": call["argument_error"],
                            "http_status": None,
                            "provider_payload": None,
                            "fallback": "re-emit the tool call with arguments matching the declared JSON Schema",
                        },
                        "meta": {},
                    }
                    errors.append({"stage": "tool_args", "tool": name, "detail": call["argument_error"]})
                else:
                    envelope = await self.registry.execute(name, args)
                    executed_any = True
                tool_results.append(envelope)
                steps.append(
                    Step(
                        index=step_index,
                        tier=tier_used.value,
                        model="",
                        kind="tool",
                        name=name,
                        ok=bool(envelope.get("ok")),
                        latency_ms=int((envelope.get("meta") or {}).get("latency_ms") or 0),
                        detail={"arguments": args, "error": envelope.get("error")},
                    )
                )
                self.memory.audit(
                    session_id=sid,
                    step=f"tool:{name}",
                    tier=tier_used.value,
                    ok=bool(envelope.get("ok")),
                    latency_ms=int((envelope.get("meta") or {}).get("latency_ms") or 0),
                    detail=envelope.get("error"),
                )
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": call["id"],
                        "name": name,
                        "content": _stringify(envelope),
                    }
                )

            if not executed_any:
                messages.append(
                    {
                        "role": "user",
                        "content": "System: all tool calls in the previous turn were schema-invalid. Re-emit them correctly or answer directly.",
                    }
                )
            if step_index == self.settings.router.max_agent_steps:
                messages.append(
                    {
                        "role": "user",
                        "content": "System: tool budget exhausted. Produce the final answer now using the evidence already collected; state any remaining gaps explicitly.",
                    }
                )
                result = await self.llm.complete(tier_used, messages, tools=None)
                break

        answer = (result.text if result else "").strip()
        if not answer and errors:
            answer = _degraded_answer(errors)
        self.memory.add_message(
            sid,
            "assistant",
            answer,
            tool_calls=[{"name": c["name"], "arguments": c["arguments"]} for c in (result.tool_calls if result else [])],
        )

        # Cost ledger: record this request's total tokens against today's budget so
        # the next handle() can degrade to T1 once the daily cap is crossed. Written
        # once per request (not per step) to keep the ledger small and the sum exact.
        self.memory.record_spend(
            session_id=sid,
            tier=tier_used.value,
            model=result.model if result else "",
            tokens_in=usage["prompt_tokens"],
            tokens_out=usage["completion_tokens"],
        )

        if background_compress:
            # Server path: don't add compression latency to the response.
            self._spawn_background(self._maybe_compress(sid), name=f"compress:{sid}")
        else:
            await self._maybe_compress(sid)

        return AgentResponse(
            session_id=sid,
            text=answer,
            tier=tier_used.value,
            model=result.model if result else "",
            intent=decision.intent,
            routing_source=decision.source,
            plan=decision.plan,
            tool_results=tool_results,
            steps=steps,
            usage=usage,
            total_latency_ms=int((time.monotonic() - started) * 1000),
            errors=errors,
        )

    # -- context assembly --------------------------------------------------
    def _build_messages(
        self,
        session_id: str,
        user_text: str,
        decision: RouteDecision,
        *,
        image_urls: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        memory_block = self.memory.context_block(session_id)
        system_parts = [self.system_prompt]
        if memory_block:
            system_parts.append(memory_block)
        system_parts.append(
            "## ACTIVE ROUTING DECISION\n"
            f"- tier: {decision.tier.value}\n"
            f"- intent: {decision.intent}\n"
            f"- allowed_tools: {', '.join(decision.requires_tools) or 'none'}\n"
            f"- plan: {'; '.join(decision.plan) or 'single-shot answer'}\n"
            "Follow the plan, call tools before asserting external facts, and never simulate tool output."
        )
        messages: list[dict[str, Any]] = [{"role": "system", "content": "\n\n".join(system_parts)}]

        history = self.memory.recent_messages(session_id)
        for m in history[:-1]:  # exclude the just-inserted user turn
            if m.role == "system":
                continue
            if m.role == "tool":
                continue  # tool envelopes are not replayed across turns (stateless efficiency)
            entry: dict[str, Any] = {"role": m.role, "content": m.content}
            if m.role == "assistant" and m.tool_calls:
                entry["tool_calls"] = [
                    {
                        "id": f"hist_{i}",
                        "type": "function",
                        "function": {"name": tc.get("name", ""), "arguments": json.dumps(tc.get("arguments", {}))},
                    }
                    for i, tc in enumerate(m.tool_calls)
                ]
            messages.append(entry)

        if image_urls:
            content: list[dict[str, Any]] = [{"type": "text", "text": user_text}]
            content.extend({"type": "image_url", "image_url": {"url": u}} for u in image_urls)
            messages.append({"role": "user", "content": content})
        else:
            messages.append({"role": "user", "content": user_text})
        return messages

    # -- memory compression ------------------------------------------------
    async def _maybe_compress(self, session_id: str) -> dict[str, int] | None:
        cfg = self.settings.memory
        if self.memory.uncompressed_count(session_id) < cfg.compress_every_n_messages:
            return None
        window = self.memory.pending_window(session_id)
        if len(window) < max(4, cfg.compress_every_n_messages - cfg.keep_recent_messages):
            return None
        dialogue = [{"role": m.role, "content": m.content} for m in window]
        model = "tier1_llm"
        try:
            payload = await self.router.compress(dialogue, max_triplets=cfg.max_triplets_per_summary)
        except (SchemaViolation, ValueError, LLMError) as exc:
            log.warning("LLM compression failed (%s); using extractive fallback", exc)
            # heuristic_compression expects StoredMessage objects (attribute access),
            # NOT the dict form built for the LLM compressor above.
            payload = heuristic_compression(window, max_summary_chars=cfg.max_summary_chars)
            model = "heuristic"
        stats = self.memory.commit_compression(
            session_id, [m.id for m in window], payload, model=model
        )
        self.memory.audit(session_id=session_id, step="compress", ok=True, detail={"model": model, **stats})
        return stats


def _log_task_failure(task: asyncio.Task) -> None:
    """Done-callback that surfaces background-task exceptions instead of swallowing them."""

    if task.cancelled():
        return
    exc = task.exception()
    if exc is not None:
        log.error("background task %s failed: %r", task.get_name(), exc)


def _next_tier(tier: Tier) -> Tier:
    return {Tier.T1: Tier.T2, Tier.T2: Tier.T3, Tier.T3: Tier.T3}[tier]


def _assistant_message(result: LLMResult) -> dict[str, Any]:
    return {
        "role": "assistant",
        "content": result.text or None,
        "tool_calls": [
            {
                "id": c["id"],
                "type": "function",
                "function": {"name": c["name"], "arguments": json.dumps(c["arguments"], ensure_ascii=False)},
            }
            for c in result.tool_calls
        ],
    }


def _stringify(envelope: dict[str, Any]) -> str:
    try:
        return json.dumps(envelope, ensure_ascii=False, default=str)
    except (TypeError, ValueError):  # pragma: no cover - defensive
        return json.dumps({"ok": False, "tool": envelope.get("tool"), "data": None, "error": {"type": "SerializationError", "message": "unserialisable tool output", "http_status": None, "provider_payload": None, "fallback": "ask the tool for a smaller payload"}})


def _degraded_answer(errors: list[dict[str, Any]]) -> str:
    lines = ["**Degraded response — upstream failure.**", ""]
    for err in errors[-3:]:
        message = err.get("message") or (err.get("error") or {}).get("message") or str(err)
        fallback = err.get("fallback") or (err.get("error") or {}).get("fallback") or "n/a"
        lines.append(f"- error: {message}\n  fallback: {fallback}")
    return "\n".join(lines)


def _load_system_prompt(path: str | None = None) -> str:
    candidate = path or os.environ.get("HERMES_SYSTEM_PROMPT_PATH", DEFAULT_SYSTEM_PROMPT_PATH)
    for base in (candidate, os.path.join(os.path.dirname(__file__), "..", candidate)):
        try:
            with open(base, encoding="utf-8") as fh:
                return fh.read().strip()
        except OSError:
            continue
    log.warning("system prompt file %s not found; using built-in minimal prompt", candidate)
    return (
        "You are Hermes-Prime, a precise software-architecture agent. "
        "Call tools before asserting external facts. Never simulate tool output. "
        "Answer in production-grade form with no conversational filler."
    )
