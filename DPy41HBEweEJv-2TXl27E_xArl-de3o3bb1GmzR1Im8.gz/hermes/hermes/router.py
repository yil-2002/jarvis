"""MoE Router: deterministic heuristics (free, ~0 CPU) + Tier-1 LLM classifier (cheap, fast).

Decision order:
  1. Hard rules that must never be mis-routed (vision payload, >100k token context).
  2. Lexical / structural heuristics producing a candidate tier + confidence.
  3. Optional Tier-1 structured-output classifier; its verdict wins only when
     confidence >= floor, otherwise the heuristic verdict is kept.
Cost control: routing itself never touches Tier-2/Tier-3.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

from .config import RouterConfig, Tier
from .llm import LLMClient, extract_json
from .memory import estimate_tokens
from .schemas import ROUTER_DECISION_SCHEMA, TOOL_INDEX, SchemaViolation, validate

log = logging.getLogger("hermes.router")

INTENTS = (
    "chat",
    "code_generation",
    "code_review",
    "debugging",
    "architecture",
    "math_reasoning",
    "research",
    "document_analysis",
    "vision",
    "data_extraction",
    "automation",
    "unknown",
)

_DEEP_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("algorithm", re.compile(r"\b(algorithm|dynamic programming|dp\b|complexity|big[- ]?o|np-hard|recursion|graph|dijkstra|backtrack)\b", re.I)),
    ("architecture", re.compile(r"\b(architect|microservice|monorepo|scalab|sharding|consensus|raft|paxos|event[- ]driven|cqrs|domain[- ]driven|ddd|schema design|system design)\b", re.I)),
    ("debugging", re.compile(r"\b(race condition|deadlock|memory leak|segfault|stack ?trace|traceback|heisenbug|intermittent|core dump|undefined behavior)\b", re.I)),
    ("math", re.compile(r"\b(prove|theorem|derivation|integral|differential equation|linear algebra|eigenvalue|probability|combinator|modular arithmetic|cryptograph)\b", re.I)),
    ("review", re.compile(r"\b(review|refactor|audit|security flaw|vulnerab|cve\b|injection|code smell)\b", re.I)),
    ("multi_step", re.compile(r"\b(step[- ]by[- ]step|design and implement|end[- ]to[- ]end|production[- ]ready|migrat)\b", re.I)),
)

_LIGHT_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("greeting", re.compile(r"^\s*(hi|hey|hello|salom|assalomu|привет|thanks|thank you|rahmat|ok|okay|yes|no)\b", re.I)),
    ("lookup", re.compile(r"\b(what is|who is|define|meaning of|when was|how much|price|news|latest)\b", re.I)),
    ("translate", re.compile(r"\b(translate|tarjima|переведи)\b", re.I)),
    ("smalltalk", re.compile(r"\b(how are you|what can you do|help me understand)\b", re.I)),
)

_RESEARCH_PATTERNS = re.compile(r"\b(search|google|find (?:me )?(?:the )?(?:latest|recent|docs)|up[- ]to[- ]date|current version|release notes|documentation|changelog)\b", re.I)
_DOC_PATTERNS = re.compile(r"\b(summari[sz]e|tl;?dr|extract|parse this|pdf|csv|json file|log file|attached|document|contract|report)\b", re.I)

_ROUTER_SYSTEM = """You are the Hermes-Prime router (Tier-1). Classify the user request and emit ONLY a JSON object.
Tiers:
- tier1_planning: greetings, short factual answers, translation, simple rewrites, tool-call validation, planning.
- tier2_deep: algorithms, system/architecture design, non-trivial code synthesis, debugging, proofs, multi-step builds.
- tier3_multimodal: images/vision, documents or codebases > 100k tokens, bulk log analysis, cross-document digestion.
Rules: pick the CHEAPEST tier that can fully satisfy the request. requires_tools may only contain: {tools}.
Never fabricate facts. plan must be atomic steps (empty array for trivial chat).""".replace(
    "{tools}", ", ".join(sorted(TOOL_INDEX))
)


@dataclass(slots=True)
class RouteDecision:
    tier: Tier
    confidence: float
    intent: str
    requires_tools: list[str]
    plan: list[str]
    needs_memory: bool
    reasoning: str
    source: str = "heuristic"  # heuristic | llm | hard_rule | fallback
    signals: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "tier": self.tier.value,
            "confidence": round(self.confidence, 3),
            "intent": self.intent,
            "requires_tools": self.requires_tools,
            "plan": self.plan,
            "needs_memory": self.needs_memory,
            "reasoning": self.reasoning,
            "source": self.source,
            "signals": self.signals,
        }


@dataclass(slots=True)
class HeuristicVerdict:
    tier: Tier
    confidence: float
    intent: str
    requires_tools: list[str]
    needs_memory: bool
    reasoning: str
    signals: dict[str, Any]


def heuristic_route(text: str, *, has_image: bool, attachments: int, cfg: RouterConfig) -> HeuristicVerdict:
    """Zero-cost routing based on structure and lexicon."""

    tokens = estimate_tokens(text)
    signals: dict[str, Any] = {
        "tokens_est": tokens,
        "chars": len(text),
        "has_image": has_image,
        "attachments": attachments,
        "deep_hits": [],
        "light_hits": [],
    }

    # --- hard rules -------------------------------------------------------
    if has_image or attachments > 2:
        return HeuristicVerdict(
            Tier.T3, 0.98, "vision", ["web_search"], False, "vision payload or multi-attachment request", signals
        )
    if tokens >= cfg.heavy_context_tokens:
        signals["hard_rule"] = "heavy_context"
        return HeuristicVerdict(
            Tier.T3, 0.97, "document_analysis", ["memory_recall"], True, "payload exceeds heavy-context threshold", signals
        )

    deep_hits = [name for name, rx in _DEEP_PATTERNS if rx.search(text)]
    light_hits = [name for name, rx in _LIGHT_PATTERNS if rx.search(text)]
    signals["deep_hits"], signals["light_hits"] = deep_hits, light_hits

    research = bool(_RESEARCH_PATTERNS.search(text))
    doc = bool(_DOC_PATTERNS.search(text))
    code_block = "```" in text
    long_prompt = tokens >= cfg.medium_context_tokens
    words = len(text.split())

    tools: list[str] = []
    if research:
        tools.append("web_search")
    if doc or attachments:
        tools.append("web_fetch")
    needs_memory = bool(re.search(r"\b(earlier|previous|before|remember|last time|oldin|avval|yuqorida)\b", text, re.I))
    if needs_memory:
        tools.append("memory_recall")

    # --- scoring ----------------------------------------------------------
    if deep_hits:
        intent = {
            "algorithm": "math_reasoning",
            "architecture": "architecture",
            "debugging": "debugging",
            "math": "math_reasoning",
            "review": "code_review",
            "multi_step": "code_generation",
        }.get(deep_hits[0], "code_generation")
        confidence = min(0.95, 0.6 + 0.12 * len(deep_hits))
        return HeuristicVerdict(Tier.T2, confidence, intent, tools, needs_memory, f"deep signals: {deep_hits}", signals)

    if code_block or words > 400 or long_prompt:
        return HeuristicVerdict(
            Tier.T2, 0.66, "code_generation", tools, needs_memory, "large or code-bearing prompt", signals
        )

    if doc and tokens > 2_500:
        return HeuristicVerdict(Tier.T3, 0.7, "document_analysis", tools, needs_memory, "long document digestion", signals)

    if research:
        return HeuristicVerdict(Tier.T1, 0.8, "research", tools or ["web_search"], needs_memory, "real-time lookup", signals)

    if light_hits and words < 40:
        return HeuristicVerdict(Tier.T1, 0.9, "chat", tools, needs_memory, f"light signals: {light_hits}", signals)

    return HeuristicVerdict(Tier.T1, 0.55, "chat", tools, needs_memory, "default low-complexity route", signals)


class Router:
    def __init__(self, llm: LLMClient, cfg: RouterConfig) -> None:
        self.llm = llm
        self.cfg = cfg

    async def route(self, text: str, *, has_image: bool = False, attachments: int = 0) -> RouteDecision:
        verdict = heuristic_route(text, has_image=has_image, attachments=attachments, cfg=self.cfg)
        base = RouteDecision(
            tier=verdict.tier,
            confidence=verdict.confidence,
            intent=verdict.intent,
            requires_tools=verdict.requires_tools,
            plan=[],
            needs_memory=verdict.needs_memory,
            reasoning=verdict.reasoning,
            source="hard_rule" if verdict.signals.get("hard_rule") or has_image else "heuristic",
            signals=verdict.signals,
        )

        # Hard rules and ultra-cheap cases skip the LLM classifier entirely.
        if base.source == "hard_rule" or not self.cfg.llm_routing_enabled:
            return base
        if verdict.tier is Tier.T1 and verdict.confidence >= 0.9 and not verdict.requires_tools:
            return base

        try:
            refined = await self._classify(text)
        except (SchemaViolation, ValueError, KeyError) as exc:
            log.warning("LLM routing failed (%s); keeping heuristic tier=%s", exc, base.tier.value)
            base.reasoning = f"{base.reasoning} | router_llm_error={exc}"
            base.source = "fallback"
            return base
        except Exception as exc:  # noqa: BLE001 - never let routing kill the request
            log.error("router crashed: %s", exc)
            base.source = "fallback"
            return base

        if refined["confidence"] < self.cfg.router_confidence_floor:
            base.reasoning = f"{base.reasoning} | llm_low_confidence={refined['confidence']:.2f}"
            return base

        tier = Tier(refined["tier"])
        # Never downgrade below a hard heuristic requirement for heavy payloads.
        if verdict.tier is Tier.T3 and tier is not Tier.T3 and verdict.signals.get("hard_rule"):
            tier = Tier.T3
        return RouteDecision(
            tier=tier,
            confidence=float(refined["confidence"]),
            intent=refined["intent"],
            requires_tools=_merge_tools(refined["requires_tools"], base.requires_tools),
            plan=refined["plan"],
            needs_memory=bool(refined["needs_memory"]) or base.needs_memory,
            reasoning=refined["reasoning"],
            source="llm",
            signals=verdict.signals,
        )

    async def _classify(self, text: str) -> dict[str, Any]:
        clipped = text if len(text) <= 6_000 else text[:3_000] + "\n…[clipped]…\n" + text[-1_500:]
        messages = [
            {"role": "system", "content": _ROUTER_SYSTEM},
            {
                "role": "user",
                "content": (
                    f"Request:\n\"\"\"\n{clipped}\n\"\"\"\n"
                    "Respond with the JSON object only (keys: tier, confidence, intent, requires_tools, plan, needs_memory, reasoning)."
                ),
            },
        ]
        result = await self.llm.complete(Tier.T1, messages, json_mode=True, max_tokens=700, temperature=0.0)
        payload = extract_json(result.text or "{}")
        return validate(ROUTER_DECISION_SCHEMA, payload, schema_name="router_decision")

    async def compress(
        self, dialogue: list[dict[str, str]], *, max_triplets: int
    ) -> dict[str, Any]:
        """Tier-1 context compressor -> {summary, triplets, open_questions}."""

        from .schemas import TRIPLET_LIST_SCHEMA  # local import keeps module graph flat

        rendered = "\n".join(f"{m['role'].upper()}: {m['content'][:1_200]}" for m in dialogue)[-24_000:]
        messages = [
            {
                "role": "system",
                "content": (
                    "You compress dialogue history for long-term memory. Emit ONLY JSON with keys: "
                    "summary (dense, <=1800 chars: decisions, constraints, artifacts, open items), "
                    f"triplets (<= {max_triplets} objects with subject/predicate/object/confidence/source; "
                    "source in user|assistant|tool|inferred), open_questions (<=8 strings). "
                    "Extract only what is stated; never invent facts."
                ),
            },
            {"role": "user", "content": f"Dialogue to compress:\n{rendered}"},
        ]
        result = await self.llm.complete(Tier.T1, messages, json_mode=True, max_tokens=1_500, temperature=0.0)
        payload = extract_json(result.text or "{}")
        payload.setdefault("open_questions", [])
        return validate(TRIPLET_LIST_SCHEMA, payload, schema_name="compression")


def _merge_tools(primary: list[str], secondary: list[str]) -> list[str]:
    merged: list[str] = []
    for name in (*primary, *secondary):
        if name in TOOL_INDEX and name not in merged:
            merged.append(name)
    return merged[:5]
