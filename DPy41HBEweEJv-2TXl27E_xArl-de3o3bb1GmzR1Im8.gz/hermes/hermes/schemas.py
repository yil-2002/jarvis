"""JSON Schemas: tool contracts, router decision contract, memory triplet contract.

All schemas are OpenAI / OpenRouter / Groq `tools` compatible (function calling).
Validation is performed on BOTH boundaries:
  - model -> runtime : tool_call arguments must satisfy the tool schema
  - runtime -> model : tool results are wrapped in a fixed envelope
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Final

from jsonschema import Draft202012Validator

# --------------------------------------------------------------------------
# Tool schemas (function-calling format)
# --------------------------------------------------------------------------

WEB_SEARCH_TOOL: Final[dict[str, Any]] = {
    "type": "function",
    "function": {
        "name": "web_search",
        "description": (
            "Search the public web in real time for facts, news, docs, prices or "
            "library/API references. Use BEFORE answering whenever the request "
            "depends on information that may have changed after your training "
            "cut-off. Returns ranked results with url, title, snippet, score."
        ),
        "parameters": {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "minLength": 3,
                    "maxLength": 400,
                    "description": "Search engine query string. Be specific; include version numbers/dates.",
                },
                "max_results": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 10,
                    "default": 5,
                    "description": "Number of results to return.",
                },
                "search_depth": {
                    "type": "string",
                    "enum": ["basic", "advanced"],
                    "default": "basic",
                    "description": "'advanced' costs more credits but returns richer content.",
                },
                "topic": {
                    "type": "string",
                    "enum": ["general", "news", "finance"],
                    "default": "general",
                },
                "time_range": {
                    "type": ["string", "null"],
                    "enum": ["day", "week", "month", "year", None],
                    "description": "Restrict results to a recency window.",
                },
                "include_domains": {
                    "type": "array",
                    "items": {"type": "string", "format": "hostname"},
                    "maxItems": 10,
                    "description": "Optional allow-list of domains.",
                },
            },
            "required": ["query"],
            "additionalProperties": False,
        },
    },
}

WEB_FETCH_TOOL: Final[dict[str, Any]] = {
    "type": "function",
    "function": {
        "name": "web_fetch",
        "description": (
            "Fetch a single URL and return cleaned markdown/text content. "
            "Use after web_search to read the most promising result. "
            "Never fabricate page content: if the fetch fails, report the error envelope."
        ),
        "parameters": {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "format": "uri",
                    "pattern": r"^https?://",
                    "maxLength": 2048,
                    "description": "Absolute http(s) URL. Other schemes are rejected.",
                },
                "max_chars": {
                    "type": "integer",
                    "minimum": 500,
                    "maximum": 200_000,
                    "default": 20_000,
                },
                "extract_mode": {
                    "type": "string",
                    "enum": ["markdown", "text", "html"],
                    "default": "markdown",
                },
            },
            "required": ["url"],
            "additionalProperties": False,
        },
    },
}

PYTHON_EXEC_TOOL: Final[dict[str, Any]] = {
    "type": "function",
    "function": {
        "name": "python_exec",
        "description": (
            "Execute Python 3 source code in an isolated subprocess sandbox "
            "(no network by default, CPU/memory/time limited). Use it to verify "
            "arithmetic, test algorithms, parse data or validate a hypothesis "
            "instead of guessing. Returns stdout, stderr, exit_code and runtime."
        ),
        "parameters": {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 200_000,
                    "description": "Complete, runnable Python source. Use print() to emit results.",
                },
                "timeout_s": {
                    "type": "number",
                    "exclusiveMinimum": 0,
                    "maximum": 60,
                    "default": 20,
                },
                "files": {
                    "type": "array",
                    "description": "Optional files to materialise in the sandbox cwd before running.",
                    "maxItems": 8,
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {
                                "type": "string",
                                "minLength": 1,
                                "maxLength": 255,
                                "pattern": r"^[A-Za-z0-9._/-]+$",
                                "description": "Relative path; '..' and absolute paths are rejected.",
                            },
                            "content": {"type": "string", "maxLength": 5_000_000},
                        },
                        "required": ["path", "content"],
                        "additionalProperties": False,
                    },
                },
                "stdin": {"type": ["string", "null"], "maxLength": 100_000},
            },
            "required": ["code"],
            "additionalProperties": False,
        },
    },
}

SQL_QUERY_TOOL: Final[dict[str, Any]] = {
    "type": "function",
    "function": {
        "name": "sql_query",
        "description": (
            "Run a READ-ONLY SQL statement against the agent's SQLite database "
            "(sessions, messages, fact_triplets, summaries, audit_log). "
            "Only a single SELECT or WITH ... SELECT is permitted; all writes are "
            "rejected at the guard layer."
        ),
        "parameters": {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "properties": {
                "sql": {
                    "type": "string",
                    "minLength": 7,
                    "maxLength": 8_000,
                    "description": "One read-only statement. No semicolon-separated batches.",
                },
                "params": {
                    "type": "array",
                    "items": {"type": ["string", "number", "boolean", "null"]},
                    "maxItems": 20,
                    "description": "Bind parameters for '?' placeholders (prevents injection).",
                },
                "max_rows": {"type": "integer", "minimum": 1, "maximum": 500, "default": 50},
            },
            "required": ["sql"],
            "additionalProperties": False,
        },
    },
}

MEM_RECALL_TOOL: Final[dict[str, Any]] = {
    "type": "function",
    "function": {
        "name": "memory_recall",
        "description": (
            "Recall compressed long-term memory: fact triplets (subject -> predicate -> "
            "object) and previous session summaries ranked by keyword relevance. "
            "Call this at the start of any task that references earlier conversation "
            "content which is no longer in the raw context window."
        ),
        "parameters": {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "minLength": 2,
                    "maxLength": 300,
                    "description": "Free-text relevance query over stored facts/summaries.",
                },
                "top_k": {"type": "integer", "minimum": 1, "maximum": 50, "default": 8},
                "scope": {
                    "type": "string",
                    "enum": ["triplets", "summaries", "all"],
                    "default": "all",
                },
                "session_id": {
                    "type": ["string", "null"],
                    "maxLength": 64,
                    "description": "Restrict to one session; null = cross-session recall.",
                },
            },
            "required": ["query"],
            "additionalProperties": False,
        },
    },
}

TOOL_SCHEMAS: Final[tuple[dict[str, Any], ...]] = (
    WEB_SEARCH_TOOL,
    WEB_FETCH_TOOL,
    PYTHON_EXEC_TOOL,
    SQL_QUERY_TOOL,
    MEM_RECALL_TOOL,
)

TOOL_INDEX: Final[dict[str, dict[str, Any]]] = {
    t["function"]["name"]: t for t in TOOL_SCHEMAS
}


# --------------------------------------------------------------------------
# Router decision contract (Tier-1 structured output)
# --------------------------------------------------------------------------

ROUTER_DECISION_SCHEMA: Final[dict[str, Any]] = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
        "tier": {
            "type": "string",
            "enum": ["tier1_planning", "tier2_deep", "tier3_multimodal"],
            "description": "Which inference tier must answer the user request.",
        },
        "confidence": {
            "type": "number",
            "minimum": 0.0,
            "maximum": 1.0,
            "description": "Self-assessed routing confidence.",
        },
        "intent": {
            "type": "string",
            "enum": [
                "chat",
                "code_generation",
                "code_review",
                "debugging",
                "architecture",
                "math_reasoning",
                "research",
                "document_analysis",
                "vision",
                "data_extraction",
                "automation",
                "unknown",
            ],
        },
        "requires_tools": {
            "type": "array",
            "items": {"type": "string", "enum": list(TOOL_INDEX)},
            "uniqueItems": True,
            "maxItems": 5,
            "description": "Tools the chosen tier is allowed to call for this request.",
        },
        "plan": {
            "type": "array",
            "items": {"type": "string", "minLength": 3, "maxLength": 300},
            "maxItems": 6,
            "description": "Atomic execution steps. Empty for trivial chat.",
        },
        "needs_memory": {
            "type": "boolean",
            "description": "True if prior conversation state is required to answer.",
        },
        "reasoning": {
            "type": "string",
            "maxLength": 500,
            "description": "One or two sentences justifying the tier choice.",
        },
    },
    "required": ["tier", "confidence", "intent", "requires_tools", "plan", "needs_memory", "reasoning"],
    "additionalProperties": False,
}


# --------------------------------------------------------------------------
# Memory contracts: fact triplets + compression payload
# --------------------------------------------------------------------------

FACT_TRIPLET_SCHEMA: Final[dict[str, Any]] = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
        "subject": {"type": "string", "minLength": 1, "maxLength": 120},
        "predicate": {"type": "string", "minLength": 1, "maxLength": 120},
        "object": {"type": "string", "minLength": 1, "maxLength": 400},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0, "default": 0.8},
        "source": {"type": "string", "enum": ["user", "assistant", "tool", "inferred"], "default": "inferred"},
    },
    "required": ["subject", "predicate", "object"],
    "additionalProperties": False,
}

TRIPLET_LIST_SCHEMA: Final[dict[str, Any]] = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
        "summary": {
            "type": "string",
            "maxLength": 2_000,
            "description": "Dense compression of the dialogue window: decisions, constraints, open items.",
        },
        "triplets": {
            "type": "array",
            "maxItems": 40,
            "items": FACT_TRIPLET_SCHEMA,
        },
        "open_questions": {
            "type": "array",
            "items": {"type": "string", "maxLength": 300},
            "maxItems": 8,
        },
    },
    "required": ["summary", "triplets"],
    "additionalProperties": False,
}

# --------------------------------------------------------------------------
# Tool result envelope (runtime -> model). Fixed shape, no exceptions leak raw.
# --------------------------------------------------------------------------

TOOL_RESULT_ENVELOPE: Final[dict[str, Any]] = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
        "ok": {"type": "boolean"},
        "tool": {"type": "string"},
        "data": {"type": ["object", "array", "string", "null"]},
        "error": {
            "type": ["object", "null"],
            "properties": {
                "type": {"type": "string"},
                "message": {"type": "string"},
                "http_status": {"type": ["integer", "null"]},
                "provider_payload": {"type": ["object", "string", "null"]},
                "fallback": {"type": "string"},
            },
            "required": ["type", "message", "fallback"],
            "additionalProperties": False,
        },
        "meta": {
            "type": "object",
            "properties": {
                "latency_ms": {"type": ["integer", "null"]},
                "provider": {"type": ["string", "null"]},
                "truncated": {"type": "boolean"},
            },
            "additionalProperties": True,
        },
    },
    "required": ["ok", "tool", "data", "error"],
    "additionalProperties": False,
}


# --------------------------------------------------------------------------
# Validators
# --------------------------------------------------------------------------

_VALIDATORS: Final[dict[str, Draft202012Validator]] = {}


class SchemaViolation(ValueError):
    """Raised when a payload does not satisfy its JSON Schema."""

    def __init__(self, schema_name: str, errors: list[str], payload: Any) -> None:
        joined = "; ".join(errors)
        super().__init__(f"Schema violation [{schema_name}]: {joined}")
        self.schema_name = schema_name
        self.errors = errors
        self.payload = payload


def _validator(schema: dict[str, Any]) -> Draft202012Validator:
    # Key on a full-content hash: schemas share a long common "$schema" prefix,
    # so any truncated/id-based key would collide across distinct contracts.
    key = hashlib.sha256(json.dumps(schema, sort_keys=True).encode()).hexdigest()
    cached = _VALIDATORS.get(key)
    if cached is None:
        Draft202012Validator.check_schema(schema)
        cached = Draft202012Validator(schema)
        _VALIDATORS[key] = cached
    return cached


def validate(schema: dict[str, Any], payload: Any, *, schema_name: str = "payload") -> Any:
    """Validate and return the payload; raise SchemaViolation listing every defect."""

    errors = [
        f"{'/'.join(str(p) for p in e.absolute_path) or '<root>'}: {e.message}"
        for e in _validator(schema).iter_errors(payload)
    ]
    if errors:
        raise SchemaViolation(schema_name, errors, payload)
    return payload


def validate_tool_args(name: str, args: dict[str, Any]) -> dict[str, Any]:
    tool = TOOL_INDEX.get(name)
    if tool is None:
        raise SchemaViolation("tool", [f"unknown tool '{name}'"], args)
    return validate(tool["function"]["parameters"], args, schema_name=f"tool:{name}")


def parse_tool_args(name: str, raw_arguments: str | dict[str, Any] | None) -> dict[str, Any]:
    """Models emit arguments as a JSON *string*; tolerate both forms and empty input."""

    if raw_arguments is None or raw_arguments == "":
        raw_arguments = {}
    if isinstance(raw_arguments, str):
        try:
            parsed = json.loads(raw_arguments)
        except json.JSONDecodeError as exc:
            raise SchemaViolation(f"tool:{name}", [f"arguments are not valid JSON: {exc}"], raw_arguments) from exc
    else:
        parsed = raw_arguments
    if not isinstance(parsed, dict):
        raise SchemaViolation(f"tool:{name}", ["arguments must be a JSON object"], parsed)
    return validate_tool_args(name, parsed)


def openai_tools_payload(allowed: tuple[str, ...] | list[str] | None = None) -> list[dict[str, Any]]:
    """Return the `tools` array for a chat completion request."""

    if allowed is None:
        return list(TOOL_SCHEMAS)
    unknown = [n for n in allowed if n not in TOOL_INDEX]
    if unknown:
        raise SchemaViolation("tools", [f"unknown tool(s): {', '.join(unknown)}"], allowed)
    return [TOOL_INDEX[n] for n in allowed]
