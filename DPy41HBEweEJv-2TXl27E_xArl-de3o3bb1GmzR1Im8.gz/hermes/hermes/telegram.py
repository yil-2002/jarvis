"""Telegram Bot API client.

Design mirrors the LLM layer: a small ``TelegramTransport`` Protocol seam keeps
the high-level :class:`TelegramClient` testable without real network access, and
every failure surfaces as a :class:`~hermes.errors.TelegramError` carrying the
exact provider payload plus a concrete fallback (never a fabricated success).

Production rules implemented here
---------------------------------
* one shared ``aiohttp.ClientSession`` (created lazily inside the running loop)
* outgoing messages split at Telegram's 4096-char hard limit on UTF-8-safe,
  paragraph/line/word boundaries
* ``parse_mode`` is best-effort: a 400 "can't parse entities" is retried once
  as plain text so the user always receives the answer
* HTTP 429 honours ``parameters.retry_after`` (bounded single retry)
* non-2xx / ``ok=false`` / transport errors raise ``TelegramError`` with the raw
  Telegram body attached
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
from typing import Any, Protocol, runtime_checkable

import aiohttp

from .config import TelegramConfig
from .errors import TelegramError

log = logging.getLogger("hermes.telegram")

__all__ = [
    "TelegramClient",
    "TelegramTransport",
    "HttpTelegramTransport",
    "split_message",
]


# --------------------------------------------------------------------------
# transport seam
# --------------------------------------------------------------------------
@runtime_checkable
class TelegramTransport(Protocol):
    """One Bot API method call -> parsed JSON response dict."""

    async def call(self, method: str, payload: dict[str, Any]) -> dict[str, Any]: ...

    async def download(self, file_path: str, max_bytes: int) -> bytes: ...

    async def upload(
        self,
        method: str,
        fields: dict[str, Any],
        *,
        file_field: str,
        file_bytes: bytes,
        filename: str,
        content_type: str,
    ) -> dict[str, Any]: ...

    async def close(self) -> None: ...


class HttpTelegramTransport:
    """Real Bot API transport over a shared aiohttp session."""

    def __init__(self, bot_token: str, *, api_base: str = "https://api.telegram.org", timeout_s: float = 30.0) -> None:
        if not bot_token:
            raise TelegramError(
                "Telegram bot token is empty",
                payload={"api_base": api_base},
                fallback="set TELEGRAM_BOT_TOKEN (see .env.example) before enabling the webhook",
            )
        self._token = bot_token
        self._base = api_base.rstrip("/")
        self._timeout = aiohttp.ClientTimeout(total=timeout_s)
        self._session: aiohttp.ClientSession | None = None

    @property
    def session(self) -> aiohttp.ClientSession:
        # aiohttp requires the session to be created inside a running loop.
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=self._timeout,
                connector=aiohttp.TCPConnector(limit=10, ttl_dns_cache=300),
            )
        return self._session

    async def call(self, method: str, payload: dict[str, Any]) -> dict[str, Any]:
        url = f"{self._base}/bot{self._token}/{method}"
        try:
            async with self.session.post(url, json=payload) as resp:
                status = resp.status
                # Telegram always answers JSON, but guard against a proxy/HTML error page.
                text = await resp.text()
        except TimeoutError as exc:
            raise TelegramError(
                f"Telegram {method} timed out after {self._timeout.total}s",
                payload={"method": method},
                fallback="increase HERMES_TELEGRAM_TIMEOUT or retry; do not assume the message was delivered",
            ) from exc
        except aiohttp.ClientError as exc:
            raise TelegramError(
                f"Telegram {method} transport error: {exc.__class__.__name__}",
                payload={"method": method, "error": str(exc)},
                fallback="check egress to api.telegram.org (DNS/firewall); the message was NOT delivered",
            ) from exc

        try:
            body = json.loads(text)
        except ValueError:
            body = {"ok": False, "description": f"non-JSON response (HTTP {status}): {text[:300]}"}

        if status == 429:
            retry_after = int(((body.get("parameters") or {}).get("retry_after")) or 1)
            raise TelegramError(
                f"Telegram {method} rate limited (429); retry_after={retry_after}s",
                status=429,
                payload=body,
                fallback=f"sleep {retry_after}s then retry once; never fabricate a send success",
            )
        if status >= 400 or not body.get("ok", False):
            raise TelegramError(
                f"Telegram {method} failed: {body.get('description', f'HTTP {status}')}",
                status=status,
                payload=body,
            )
        return body

    async def download(self, file_path: str, max_bytes: int) -> bytes:
        """Fetch a file body from ``/file/bot<token>/<file_path>`` as raw bytes.

        Telegram serves bot files from a separate path than the Bot API methods and
        returns the bytes directly (no JSON envelope), so this cannot reuse ``call``.
        The download is streamed and hard-capped at ``max_bytes`` to protect the VPS
        from an oversized upload even if the metadata lied about ``file_size``.
        """

        url = f"{self._base}/file/bot{self._token}/{file_path}"
        chunks: list[bytes] = []
        total = 0
        try:
            async with self.session.get(url) as resp:
                status = resp.status
                if status >= 400:
                    detail = (await resp.text())[:300]
                    raise TelegramError(
                        f"Telegram file download failed: HTTP {status}",
                        status=status,
                        payload={"file_path": file_path, "body": detail},
                        fallback="the file may be >20 MB or expired; ask the user to re-send it",
                    )
                async for chunk in resp.content.iter_chunked(64 * 1024):
                    total += len(chunk)
                    if total > max_bytes:
                        raise TelegramError(
                            f"Telegram file exceeds {max_bytes} bytes during download",
                            payload={"file_path": file_path, "received": total},
                            fallback="the file is too large for bot download (>20 MB); send a smaller one",
                        )
                    chunks.append(chunk)
        except TelegramError:
            raise
        except TimeoutError as exc:
            raise TelegramError(
                f"Telegram file download timed out after {self._timeout.total}s",
                payload={"file_path": file_path},
                fallback="retry once; if it persists the file server may be slow",
            ) from exc
        except aiohttp.ClientError as exc:
            raise TelegramError(
                f"Telegram file download transport error: {exc.__class__.__name__}",
                payload={"file_path": file_path, "error": str(exc)},
                fallback="check egress to api.telegram.org; the file was NOT retrieved",
            ) from exc
        return b"".join(chunks)

    async def upload(
        self,
        method: str,
        fields: dict[str, Any],
        *,
        file_field: str,
        file_bytes: bytes,
        filename: str,
        content_type: str,
    ) -> dict[str, Any]:
        """Multipart upload for Bot API methods that take a file (sendAudio, …).

        ``fields`` are the non-file form parts (chat_id, caption, duration…).
        Shares ``call``'s response handling: 429 honours ``retry_after``, non-2xx /
        ``ok=false`` raise ``TelegramError`` with the raw body attached.
        """

        url = f"{self._base}/bot{self._token}/{method}"
        form = aiohttp.FormData()
        for key, value in fields.items():
            form.add_field(key, str(value))
        form.add_field(file_field, file_bytes, filename=filename, content_type=content_type or "application/octet-stream")
        try:
            async with self.session.post(url, data=form) as resp:
                status = resp.status
                text = await resp.text()
        except TimeoutError as exc:
            raise TelegramError(
                f"Telegram {method} upload timed out after {self._timeout.total}s",
                payload={"method": method, "bytes": len(file_bytes)},
                fallback="increase HERMES_TELEGRAM_TIMEOUT or send a smaller file; do not assume delivery",
            ) from exc
        except aiohttp.ClientError as exc:
            raise TelegramError(
                f"Telegram {method} upload transport error: {exc.__class__.__name__}",
                payload={"method": method, "error": str(exc)},
                fallback="check egress to api.telegram.org; the file was NOT delivered",
            ) from exc

        try:
            body = json.loads(text)
        except ValueError:
            body = {"ok": False, "description": f"non-JSON response (HTTP {status}): {text[:300]}"}

        if status == 429:
            retry_after = int(((body.get("parameters") or {}).get("retry_after")) or 1)
            raise TelegramError(
                f"Telegram {method} rate limited (429); retry_after={retry_after}s",
                status=429,
                payload=body,
                fallback=f"sleep {retry_after}s then retry once; never fabricate a send success",
            )
        if status >= 400 or not body.get("ok", False):
            raise TelegramError(
                f"Telegram {method} upload failed: {body.get('description', f'HTTP {status}')}",
                status=status,
                payload=body,
            )
        return body

    async def close(self) -> None:
        if self._session is not None and not self._session.closed:
            await self._session.close()
            self._session = None


# --------------------------------------------------------------------------
# message splitting
# --------------------------------------------------------------------------
def split_message(text: str, limit: int = 4_096) -> list[str]:
    """Split ``text`` into <=``limit`` chunks, preferring natural break points.

    Telegram counts UTF-16 code units, but Python ``len`` counts code points; for
    the BMP-heavy traffic of a tech bot the two coincide, and we leave a small
    safety margin by breaking on paragraph -> line -> word -> hard cut.
    """

    if not text:
        return [""]
    if len(text) <= limit:
        return [text]

    chunks: list[str] = []
    remaining = text
    while len(remaining) > limit:
        window = remaining[:limit]
        # Try the most natural break inside the window, searching backwards.
        cut = -1
        for sep in ("\n\n", "\n", " "):
            idx = window.rfind(sep)
            if idx > limit // 2:  # only accept a break in the latter half
                cut = idx + len(sep)
                break
        if cut <= 0:
            cut = limit  # no good break: hard cut
        chunks.append(remaining[:cut].rstrip())
        remaining = remaining[cut:].lstrip()
    if remaining:
        chunks.append(remaining)
    return chunks


# --------------------------------------------------------------------------
# high-level client
# --------------------------------------------------------------------------
class TelegramClient:
    """Typed convenience wrapper over the Bot API transport."""

    def __init__(self, transport: TelegramTransport, *, config: TelegramConfig | None = None) -> None:
        self._t = transport
        self.cfg = config or TelegramConfig()

    @classmethod
    def from_config(cls, config: TelegramConfig) -> TelegramClient:
        return cls(
            HttpTelegramTransport(config.bot_token, api_base=config.api_base, timeout_s=config.timeout_s),
            config=config,
        )

    async def aclose(self) -> None:
        await self._t.close()

    # -- send ------------------------------------------------------------
    async def send_message(
        self,
        chat_id: int | str,
        text: str,
        *,
        parse_mode: str | None = "Markdown",
        disable_preview: bool = True,
        reply_markup: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Send ``text``, chunked at the 4096 limit, with a plain-text fallback.

        ``reply_markup`` (an inline keyboard / Web App button) is attached to the
        final chunk only, so a split message never repeats the keyboard.

        Returns the list of Telegram ``result`` objects (one per chunk). Raises
        ``TelegramError`` only if a chunk cannot be delivered even as plain text.
        """

        results: list[dict[str, Any]] = []
        chunks = split_message(text, self.cfg.max_message_chars)
        last = len(chunks) - 1
        for idx, chunk in enumerate(chunks):
            payload: dict[str, Any] = {
                "chat_id": chat_id,
                "text": chunk,
                "disable_web_page_preview": disable_preview,
            }
            if parse_mode:
                payload["parse_mode"] = parse_mode
            if reply_markup is not None and idx == last:
                payload["reply_markup"] = reply_markup
            try:
                body = await self._t.call("sendMessage", payload)
            except TelegramError as exc:
                # A 400 here is almost always an unbalanced Markdown entity in
                # model output. Retry once as plain text so the user still gets
                # the answer; surface anything else.
                if parse_mode and exc.status == 400:
                    log.warning(
                        "sendMessage parse failed (%s); retrying as plain text. payload=%s",
                        exc.message,
                        exc.payload,
                    )
                    payload.pop("parse_mode", None)
                    body = await self._t.call("sendMessage", payload)
                else:
                    raise
            results.append(body.get("result", body))
        return results

    async def set_chat_menu_button(
        self,
        *,
        url: str,
        text: str,
        chat_id: int | None = None,
    ) -> dict[str, Any]:
        """Point the chat's menu button at the JARVIS Mini App (Web App).

        With ``chat_id`` omitted this sets the bot's *default* menu button (shown
        in every private chat) via ``setChatMenuButton``. Telegram requires an
        HTTPS ``url``; a plain-HTTP value is rejected with a 400.
        """

        payload: dict[str, Any] = {
            "menu_button": {
                "type": "web_app",
                "text": text,
                "web_app": {"url": url},
            }
        }
        if chat_id is not None:
            payload["chat_id"] = chat_id
        body = await self._t.call("setChatMenuButton", payload)
        return body.get("result", body)

    async def send_chat_action(self, chat_id: int | str, action: str = "typing") -> None:
        # Best-effort UX signal; a failure here must not abort the answer.
        try:
            await self._t.call("sendChatAction", {"chat_id": chat_id, "action": action})
        except TelegramError as exc:
            log.warning("sendChatAction(%s) failed: %s payload=%s", action, exc.message, exc.payload)

    async def send_audio(
        self,
        chat_id: int | str,
        audio: bytes,
        *,
        filename: str = "jarvis.mp3",
        title: str | None = None,
        performer: str | None = None,
        caption: str | None = None,
        content_type: str = "audio/mpeg",
    ) -> dict[str, Any]:
        """Upload an audio file (edge-tts MP3) via ``sendAudio``.

        Used for TTS replies. ``sendAudio`` (not ``sendVoice``) is deliberate:
        Telegram renders ``sendVoice`` as a voice bubble only for OGG/Opus, and
        transcoding MP3->Opus would need ffmpeg on the VPS. ``sendAudio`` plays
        MP3 inline with no server-side compute. Raises ``TelegramError`` with the
        exact payload on failure; the caller treats TTS delivery as non-fatal
        (the text answer is already sent).
        """

        fields: dict[str, Any] = {"chat_id": chat_id}
        if title:
            fields["title"] = title
        if performer:
            fields["performer"] = performer
        if caption:
            fields["caption"] = caption
        body = await self._t.upload(
            "sendAudio",
            fields,
            file_field="audio",
            file_bytes=audio,
            filename=filename,
            content_type=content_type,
        )
        return body.get("result", body)

    # -- file download (document ingestion) -----------------------------
    async def get_file(self, file_id: str) -> dict[str, Any]:
        """Resolve a ``file_id`` to its metadata (incl. ``file_path``) via getFile."""

        body = await self._t.call("getFile", {"file_id": file_id})
        return body.get("result", body)

    async def download_file(self, file_id: str, *, max_bytes: int) -> tuple[dict[str, Any], bytes]:
        """getFile then download the body; returns ``(file_info, raw_bytes)``.

        Telegram serves the actual bytes from a different path than the Bot API, so
        this is a two-step call. ``max_bytes`` is enforced twice: once against the
        advertised ``file_size`` (cheap reject before any transfer) and again while
        streaming, so a lying/misreported size can never exhaust the VPS.
        """

        info = await self.get_file(file_id)
        file_path = info.get("file_path")
        if not file_path:
            raise TelegramError(
                "getFile returned no file_path",
                payload=info,
                fallback="the file may be too large (>20 MB) or expired; ask the user to re-send it",
            )
        advertised = int(info.get("file_size") or 0)
        if advertised and advertised > max_bytes:
            raise TelegramError(
                f"file is {advertised} bytes, over the {max_bytes}-byte limit",
                payload={"file_path": file_path, "file_size": advertised, "max_bytes": max_bytes},
                fallback="Telegram bots cannot download files >20 MB; send a smaller file",
            )
        data = await self._t.download(file_path, max_bytes)
        return info, data

    # -- webhook management ---------------------------------------------
    async def set_webhook(self, url: str, *, secret_token: str, allowed_updates: tuple[str, ...]) -> dict[str, Any]:
        if not url.startswith("https://"):
            raise TelegramError(
                "Telegram requires an HTTPS webhook URL",
                payload={"url": url},
                fallback="terminate TLS at nginx (Let's Encrypt) and pass the public https:// URL",
            )
        if not secret_token:
            raise TelegramError(
                "refusing to set a webhook without a secret_token",
                payload={"url": url},
                fallback="set TELEGRAM_WEBHOOK_SECRET so incoming updates can be authenticated",
            )
        body = await self._t.call(
            "setWebhook",
            {"url": url, "secret_token": secret_token, "allowed_updates": list(allowed_updates), "drop_pending_updates": True},
        )
        return body.get("result", body)

    async def get_webhook_info(self) -> dict[str, Any]:
        body = await self._t.call("getWebhookInfo", {})
        return body.get("result", body)

    async def delete_webhook(self, *, drop_pending: bool = False) -> dict[str, Any]:
        body = await self._t.call("deleteWebhook", {"drop_pending_updates": drop_pending})
        return body.get("result", body)


# --------------------------------------------------------------------------
# webhook management CLI
# --------------------------------------------------------------------------
def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="hermes-telegram", description="Manage the Hermes Telegram webhook")
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("set-webhook", help="register HERMES_DOMAIN+path with Telegram (requires secret)")
    sub.add_parser("get-info", help="print Telegram's current webhook info")
    sub.add_parser("delete-webhook", help="remove the webhook")
    sub.add_parser(
        "set-menu-button",
        help="point the chat menu button at the JARVIS Mini App (HERMES_MINIAPP_URL or HERMES_DOMAIN root)",
    )
    return p


async def _amain(argv: list[str] | None) -> int:
    from .config import load_settings

    args = _build_arg_parser().parse_args(argv)
    cfg = load_settings().telegram
    if not cfg.enabled:
        raise SystemExit(
            "TELEGRAM_BOT_TOKEN is not set. Add it to the environment (see .env.example) and retry."
        )
    client = TelegramClient.from_config(cfg)
    try:
        if args.command == "set-webhook":
            if not cfg.webhook_url:
                raise SystemExit(
                    "HERMES_DOMAIN is not set, so the public webhook URL is unknown. "
                    "Set HERMES_DOMAIN=https://agent.example.uz and retry."
                )
            if not cfg.webhook_secret:
                raise SystemExit(
                    "TELEGRAM_WEBHOOK_SECRET is not set. Refusing to register an unauthenticated "
                    "webhook — generate one with: openssl rand -hex 32"
                )
            result = await client.set_webhook(
                cfg.webhook_url, secret_token=cfg.webhook_secret, allowed_updates=cfg.allowed_updates
            )
            print(f"setWebhook -> {cfg.webhook_url}: {result}")
        elif args.command == "get-info":
            print(json.dumps(await client.get_webhook_info(), indent=2, ensure_ascii=False))
        elif args.command == "delete-webhook":
            print(f"deleteWebhook: {await client.delete_webhook(drop_pending=True)}")
        elif args.command == "set-menu-button":
            if not cfg.miniapp_enabled:
                raise SystemExit(
                    "No HTTPS Mini App URL is configured. Set HERMES_DOMAIN=https://your.ngrok.domain "
                    "(the JARVIS console is served at its root) or HERMES_MINIAPP_URL explicitly, and retry. "
                    "Telegram rejects plain-HTTP Web App URLs."
                )
            result = await client.set_chat_menu_button(
                url=cfg.resolved_miniapp_url, text=cfg.miniapp_button_text
            )
            print(f"setChatMenuButton -> {cfg.resolved_miniapp_url} ({cfg.miniapp_button_text}): {result}")
        return 0
    finally:
        await client.aclose()


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-7s %(name)s | %(message)s")
    try:
        return asyncio.run(_amain(argv))
    except TelegramError as exc:
        print(f"ERROR: {exc.message}", file=sys.stderr)
        if exc.payload:
            print(f"  payload : {exc.payload}", file=sys.stderr)
        print(f"  fallback: {exc.fallback}", file=sys.stderr)
        return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
