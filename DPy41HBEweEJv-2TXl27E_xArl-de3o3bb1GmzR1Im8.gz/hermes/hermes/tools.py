"""Tool implementations: web search (Tavily -> Serper failover), fetch, sandboxed exec, SQL, memory."""

from __future__ import annotations

import ast
import asyncio
import json
import logging
import os
import re
import shutil
import sqlite3
import tempfile
import time
import urllib.parse
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, Protocol

import aiohttp

from .config import ExecutorConfig, MemoryConfig
from .errors import SecurityViolation, ToolExecutionError

log = logging.getLogger("hermes.tools")

Envelope = dict[str, Any]
SessionGetter = Callable[[], aiohttp.ClientSession]


def ok_envelope(tool: str, data: Any, **meta: Any) -> Envelope:
    return {"ok": True, "tool": tool, "data": data, "error": None, "meta": meta}


def err_envelope(tool: str, error: Exception, **meta: Any) -> Envelope:
    if isinstance(error, ToolExecutionError):
        err = error.to_envelope()
    else:
        err = {
            "type": error.__class__.__name__,
            "message": str(error) or error.__class__.__name__,
            "http_status": getattr(error, "status", None),
            "provider_payload": getattr(error, "payload", None),
            "fallback": "retry once with corrected arguments; otherwise continue without the tool and state the gap",
        }
    return {"ok": False, "tool": tool, "data": None, "error": err, "meta": meta}


class _Tool(Protocol):
    name: str

    async def __call__(self, **kwargs: Any) -> Any: ...


@dataclass(slots=True)
class RegisteredTool:
    name: str
    handler: Callable[..., Awaitable[Any]]
    timeout_s: float = 45.0


class ToolRegistry:
    """Executes tools with timeout, validation-error surfacing and uniform envelopes."""

    def __init__(self) -> None:
        self._tools: dict[str, RegisteredTool] = {}

    def register(self, name: str, handler: Callable[..., Awaitable[Any]], *, timeout_s: float = 45.0) -> None:
        self._tools[name] = RegisteredTool(name=name, handler=handler, timeout_s=timeout_s)

    @property
    def names(self) -> list[str]:
        return sorted(self._tools)

    async def execute(self, name: str, arguments: dict[str, Any]) -> Envelope:
        tool = self._tools.get(name)
        if tool is None:
            return err_envelope(
                name,
                ToolExecutionError(
                    name,
                    f"unknown tool '{name}'",
                    payload={"available": self.names},
                    fallback=f"call one of: {', '.join(self.names)}",
                ),
            )
        started = time.monotonic()
        try:
            data = await asyncio.wait_for(tool.handler(**arguments), timeout=tool.timeout_s)
        except TimeoutError:
            return err_envelope(
                name,
                ToolExecutionError(
                    name,
                    f"tool timed out after {tool.timeout_s}s",
                    payload={"timeout_s": tool.timeout_s, "arguments": arguments},
                    fallback="reduce the scope of the request (fewer results / shorter code / smaller max_chars) and retry",
                ),
                latency_ms=int((time.monotonic() - started) * 1000),
            )
        except SecurityViolation as exc:
            log.warning("security guard blocked %s: %s", name, exc.message)
            return err_envelope(name, exc, latency_ms=int((time.monotonic() - started) * 1000))
        except ToolExecutionError as exc:
            # Expected control flow (missing creds, provider 4xx/5xx, bad scope).
            log.warning("tool %s failed: %s", name, exc.message)
            return err_envelope(name, exc, latency_ms=int((time.monotonic() - started) * 1000))
        except TypeError as exc:  # unexpected kwargs from a malformed tool call
            return err_envelope(
                name,
                ToolExecutionError(
                    name,
                    f"argument mismatch: {exc}",
                    payload={"arguments": arguments},
                    fallback="re-emit the tool call using only the documented parameters",
                ),
                latency_ms=int((time.monotonic() - started) * 1000),
            )
        except Exception as exc:  # noqa: BLE001 - envelope must never leak a traceback to the model
            log.exception("tool %s crashed unexpectedly", name)
            return err_envelope(name, exc, latency_ms=int((time.monotonic() - started) * 1000))
        return ok_envelope(name, data, latency_ms=int((time.monotonic() - started) * 1000))


# --------------------------------------------------------------------------
# web_search: Tavily primary, Serper fallback
# --------------------------------------------------------------------------

TAVILY_URL = "https://api.tavily.com/search"
SERPER_URL = "https://google.serper.dev/search"


async def _tavily(session: aiohttp.ClientSession, args: dict[str, Any]) -> list[dict[str, Any]]:
    key = os.environ.get("TAVILY_API_KEY", "").strip()
    if not key:
        raise ToolExecutionError(
            "web_search",
            "TAVILY_API_KEY is not set",
            payload={"provider": "tavily"},
            fallback="falling back to Serper (requires SERPER_API_KEY)",
        )
    payload = {
        "api_key": key,
        "query": args["query"],
        "max_results": args.get("max_results", 5),
        "search_depth": args.get("search_depth", "basic"),
        "topic": args.get("topic", "general"),
        "include_answer": False,
    }
    if args.get("include_domains"):
        payload["include_domains"] = args["include_domains"]
    if args.get("time_range"):
        payload["time_range"] = args["time_range"]
    async with session.post(TAVILY_URL, json=payload) as resp:
        body = await resp.text()
        if resp.status >= 400:
            raise ToolExecutionError(
                "web_search",
                f"tavily HTTP {resp.status}",
                payload=_clip(body),
                fallback="falling back to Serper",
            )
        data = json.loads(body)
    return [
        {
            "title": r.get("title"),
            "url": r.get("url"),
            "snippet": r.get("content") or r.get("snippet"),
            "score": r.get("score"),
            "published": r.get("published_date"),
        }
        for r in data.get("results", [])
    ]


async def _serper(session: aiohttp.ClientSession, args: dict[str, Any]) -> list[dict[str, Any]]:
    key = os.environ.get("SERPER_API_KEY", "").strip()
    if not key:
        raise ToolExecutionError(
            "web_search",
            "SERPER_API_KEY is not set",
            payload={"provider": "serper"},
            fallback="no search provider available; answer from internal knowledge and explicitly flag the gap",
        )
    payload: dict[str, Any] = {"q": args["query"], "num": min(int(args.get("max_results", 5)), 10)}
    if args.get("time_range"):
        payload["tbs"] = {"day": "qdr:d", "week": "qdr:w", "month": "qdr:m", "year": "qdr:y"}[args["time_range"]]
    if args.get("topic") == "news":
        payload["type"] = "news"
    headers = {"X-API-KEY": key, "Content-Type": "application/json"}
    async with session.post(SERPER_URL, json=payload, headers=headers) as resp:
        body = await resp.text()
        if resp.status >= 400:
            raise ToolExecutionError("web_search", f"serper HTTP {resp.status}", payload=_clip(body), fallback="report failure to the caller")
        data = json.loads(body)
    return [
        {
            "title": r.get("title"),
            "url": r.get("link"),
            "snippet": r.get("snippet"),
            "score": None,
            "published": r.get("date"),
        }
        for r in (data.get("organic") or data.get("news") or [])
    ]


def make_web_search(session: SessionGetter) -> Callable[..., Awaitable[Any]]:
    async def web_search(**args: Any) -> Any:
        errors: list[str] = []
        http = session()
        for provider in (_tavily, _serper):
            try:
                results = await provider(http, args)
                return {
                    "provider": provider.__name__.lstrip("_"),
                    "query": args["query"],
                    "count": len(results),
                    "results": results,
                }
            except ToolExecutionError as exc:
                errors.append(f"{exc.payload.get('provider') if isinstance(exc.payload, dict) else '?'}: {exc.message}")
                log.warning("search provider failed: %s", exc.message)
        raise ToolExecutionError("web_search", "all search providers failed", payload={"errors": errors})

    return web_search


# --------------------------------------------------------------------------
# web_fetch
# --------------------------------------------------------------------------

_TAG_RE = re.compile(rb"<(script|style|noscript|svg|head)\b.*?</\1>", re.S | re.I)
_ANY_TAG_RE = re.compile(rb"<[^>]+>")
_WS_RE = re.compile(rb"\n{3,}")


async def web_fetch(session: aiohttp.ClientSession, *, url: str, max_chars: int = 20_000, extract_mode: str = "markdown") -> Any:
    if not url.lower().startswith(("http://", "https://")):
        raise SecurityViolation("web_fetch", f"scheme not allowed: {url}")
    host = urllib.parse.urlparse(url).hostname or ""
    if _is_private_host(host):
        raise SecurityViolation("web_fetch", f"SSRF blocked: private/reserved host '{host}'", payload={"url": url})

    async with session.get(
        url,
        headers={"User-Agent": "Mozilla/5.0 (compatible; HermesPrimeBot/1.0)"},
        allow_redirects=True,
        max_redirects=5,
        timeout=aiohttp.ClientTimeout(total=30),
    ) as resp:
        ctype = resp.headers.get("Content-Type", "")
        raw = await resp.content.read(4_000_000)
        if resp.status >= 400:
            raise ToolExecutionError(
                "web_fetch",
                f"HTTP {resp.status} for {url}",
                payload={"status": resp.status, "content_type": ctype},
                fallback="pick another search result or narrow the query",
            )

    truncated = False
    if "html" in ctype or raw.lstrip()[:1] == b"<":
        text = _html_to_text(raw)
    else:
        text = raw.decode("utf-8", errors="replace")
    if extract_mode == "text" or "html" not in ctype:
        text = re.sub(r"\n{3,}", "\n\n", text)
    if len(text) > max_chars:
        text, truncated = text[:max_chars], True
    return {"url": url, "content_type": ctype, "chars": len(text), "truncated": truncated, "content": text}


def _is_private_host(host: str) -> bool:
    h = host.lower().strip("[]")
    if h in {"localhost", "metadata.google.internal"}:
        return True
    if h.endswith(".local") or h.endswith(".internal"):
        return True
    try:
        import ipaddress

        ip = ipaddress.ip_address(h)
    except ValueError:
        return False
    return ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast


def _html_to_text(raw: bytes) -> str:
    cleaned = _TAG_RE.sub(b" ", raw)
    cleaned = re.sub(rb"(?i)<br\s*/?>|</p>|</div>|</li>|</h[1-6]>", b"\n", cleaned)
    cleaned = re.sub(rb"(?i)<li[^>]*>", b"- ", cleaned)
    cleaned = _ANY_TAG_RE.sub(b" ", cleaned)
    text = _WS_RE.sub(b"\n\n", cleaned).decode("utf-8", errors="replace")
    text = re.sub(r"[ \t]{2,}", " ", text)
    return text.strip()


def _clip(body: str, limit: int = 1_500) -> str:
    return body if len(body) <= limit else body[:limit] + "…[truncated]"


# --------------------------------------------------------------------------
# python_exec: AST-guarded subprocess sandbox
# --------------------------------------------------------------------------

BLOCKED_MODULES = frozenset(
    {
        "ctypes",
        "socket",
        "subprocess",
        "multiprocessing",
        "pty",
        "resource",
        "signal",
        "shutil",
        "pathlib",
        "http",
        "urllib",
        "requests",
        "aiohttp",
        "ftplib",
        "smtplib",
        "telnetlib",
        "pickle",
        "shelve",
        "importlib",
    }
)
BLOCKED_CALLS = frozenset({"eval", "exec", "compile", "__import__", "breakpoint", "openpty"})
BLOCKED_ATTRS = frozenset({"__subclasses__", "__globals__", "__bases__", "__mro__", "__class__", "__loader__"})


def audit_python_source(code: str) -> None:
    """Static guard: reject network/process/FFI escape attempts before execution."""

    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        raise ToolExecutionError(
            "python_exec",
            f"SyntaxError: {exc.msg} (line {exc.lineno})",
            payload={"line": exc.lineno, "offset": exc.offset},
            fallback="fix the syntax and re-emit the code",
        ) from exc

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split(".")[0]
                if root in BLOCKED_MODULES:
                    raise SecurityViolation("python_exec", f"import of blocked module '{alias.name}'", payload={"line": node.lineno})
        elif isinstance(node, ast.ImportFrom):
            root = (node.module or "").split(".")[0]
            if root in BLOCKED_MODULES:
                raise SecurityViolation("python_exec", f"import from blocked module '{node.module}'", payload={"line": node.lineno})
        elif isinstance(node, ast.Call):
            fn = node.func
            if isinstance(fn, ast.Name) and fn.id in BLOCKED_CALLS:
                raise SecurityViolation("python_exec", f"call to blocked builtin '{fn.id}()'", payload={"line": node.lineno})
            if isinstance(fn, ast.Attribute) and fn.attr in BLOCKED_ATTRS:
                raise SecurityViolation("python_exec", f"access to blocked attribute '{fn.attr}'", payload={"line": node.lineno})
        elif isinstance(node, ast.Attribute) and node.attr in BLOCKED_ATTRS:
            raise SecurityViolation("python_exec", f"access to blocked attribute '{node.attr}'", payload={"line": node.lineno})


def _preexec_limits(max_memory_mb: int) -> Callable[[], None] | None:
    if os.name != "posix":
        return None

    def _apply() -> None:  # pragma: no cover - runs in child
        import resource as _res

        soft_cpu = 30
        _res.setrlimit(_res.RLIMIT_CPU, (soft_cpu, soft_cpu + 5))
        mem = max_memory_mb * 1024 * 1024
        _res.setrlimit(_res.RLIMIT_AS, (mem, mem))
        _res.setrlimit(_res.RLIMIT_FSIZE, (64 * 1024 * 1024,) * 2)
        _res.setrlimit(_res.RLIMIT_NPROC, (256, 256))
        _res.setrlimit(_res.RLIMIT_CORE, (0, 0))
        try:
            os.setsid()
        except OSError:
            pass

    return _apply


def _prepare_sandbox(cfg: ExecutorConfig, code: str, files: list[dict[str, str]] | None) -> tuple[str, str, dict[str, str]]:
    """Blocking FS setup: create workdir, materialise files, write the entry script, build env.

    Runs in a worker thread (via asyncio.to_thread) so the event loop never blocks.
    Returns (workdir, script_path, env).
    """

    os.makedirs(cfg.workspace_dir, exist_ok=True)
    workdir = tempfile.mkdtemp(prefix="run_", dir=cfg.workspace_dir)
    for entry in files or []:
        _write_sandbox_file(workdir, entry["path"], entry["content"])
    script = os.path.join(workdir, "__hermes_main.py")
    with open(script, "w", encoding="utf-8") as fh:
        fh.write(code)

    env = {k: v for k, v in os.environ.items() if not _is_secret_env(k)}
    env.update(
        {
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONUNBUFFERED": "1",
            "HOME": workdir,
            "TMPDIR": workdir,
        }
    )
    if not cfg.allow_network:
        env["http_proxy"] = env["https_proxy"] = env["HTTP_PROXY"] = env["HTTPS_PROXY"] = "http://127.0.0.1:9"
    return workdir, script, env


def _collect_outputs(workdir: str) -> list[str]:
    """Blocking FS walk listing files the sandboxed program produced."""

    return [
        os.path.relpath(os.path.join(root, f), workdir)
        for root, _, found in os.walk(workdir)
        for f in found
        if f != "__hermes_main.py"
    ][:50]


def make_python_exec(cfg: ExecutorConfig) -> Callable[..., Awaitable[Any]]:
    async def python_exec(*, code: str, timeout_s: float | None = None, files: list[dict[str, str]] | None = None, stdin: str | None = None) -> Any:
        audit_python_source(code)
        timeout = min(float(timeout_s or cfg.timeout_s), 60.0)

        # Off-loop: all blocking filesystem setup happens in a worker thread.
        workdir, script, env = await asyncio.to_thread(_prepare_sandbox, cfg, code, files)
        try:
            started = time.monotonic()
            proc = await asyncio.create_subprocess_exec(
                "python3",
                "-I",  # isolated: ignores env PYTHON* and user site-packages
                "-B",
                script,
                cwd=workdir,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
                preexec_fn=_preexec_limits(cfg.max_memory_mb),
            )
            try:
                stdout_b, stderr_b = await asyncio.wait_for(
                    proc.communicate((stdin or "").encode()), timeout=timeout
                )
            except TimeoutError:
                _kill_tree(proc)
                raise ToolExecutionError(
                    "python_exec",
                    f"execution exceeded {timeout}s and was killed",
                    payload={"timeout_s": timeout},
                    fallback="reduce algorithmic complexity or process the data in chunks",
                ) from None

            runtime_ms = int((time.monotonic() - started) * 1000)
            stdout = stdout_b.decode("utf-8", errors="replace")
            stderr = stderr_b.decode("utf-8", errors="replace")
            truncated = False
            if len(stdout) > cfg.max_output_chars:
                stdout, truncated = stdout[: cfg.max_output_chars], True
            if len(stderr) > cfg.max_output_chars:
                stderr, truncated = stderr[: cfg.max_output_chars], True
            produced = await asyncio.to_thread(_collect_outputs, workdir)
            return {
                "exit_code": proc.returncode,
                "stdout": stdout,
                "stderr": stderr,
                "runtime_ms": runtime_ms,
                "truncated": truncated,
                "files_written": produced,
            }
        finally:
            await asyncio.to_thread(shutil.rmtree, workdir, True)

    return python_exec


_SECRET_ENV_RE = re.compile(r"(?i)(KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|AUTH)")


def _is_secret_env(name: str) -> bool:
    return bool(_SECRET_ENV_RE.search(name))


def _write_sandbox_file(workdir: str, rel_path: str, content: str) -> None:
    if rel_path.startswith("/") or ".." in rel_path.replace("\\", "/").split("/"):
        raise SecurityViolation("python_exec", f"path traversal blocked: {rel_path!r}")
    target = os.path.normpath(os.path.join(workdir, rel_path))
    if not target.startswith(os.path.normpath(workdir) + os.sep):
        raise SecurityViolation("python_exec", f"path escape blocked: {rel_path!r}")
    os.makedirs(os.path.dirname(target), exist_ok=True)
    with open(target, "w", encoding="utf-8") as fh:
        fh.write(content)


def _kill_tree(proc: asyncio.subprocess.Process) -> None:
    try:
        os.killpg(os.getpgid(proc.pid), 9)
    except (OSError, ProcessLookupError):  # pragma: no cover
        try:
            proc.kill()
        except ProcessLookupError:
            pass


# --------------------------------------------------------------------------
# sql_query: read-only guard
# --------------------------------------------------------------------------

_WRITE_RE = re.compile(
    r"(?is)\b(insert|update|delete|drop|alter|create|replace|truncate|attach|detach|pragma|vacuum|reindex|grant|revoke|savepoint|rollback|commit|begin)\b"
)
_COMMENT_RE = re.compile(r"(--.*?$|/\*.*?\*/)", re.S | re.M)


async def sql_query(*, sql: str, params: list[Any] | None = None, max_rows: int = 50, _db_path: str = "hermes_state.db") -> Any:
    statement = _COMMENT_RE.sub(" ", sql).strip().rstrip(";").strip()
    if not statement:
        raise ToolExecutionError("sql_query", "empty statement", payload={"sql": sql})
    if ";" in statement:
        raise SecurityViolation("sql_query", "statement batching is not allowed (single statement only)")
    if not statement[:6].lower().startswith(("select", "with ")):
        raise SecurityViolation("sql_query", "only SELECT / WITH ... SELECT statements are allowed", payload={"sql": statement[:200]})
    match = _WRITE_RE.search(statement)
    if match:
        raise SecurityViolation("sql_query", f"write keyword '{match.group(0)}' is not allowed", payload={"sql": statement[:200]})

    def _run() -> Any:
        conn = sqlite3.connect(f"file:{_db_path}?mode=ro", uri=True, timeout=5.0)
        try:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(statement, tuple(params or ()))
            rows = [dict(r) for r in cursor.fetchmany(int(max_rows))]
            return {"columns": [d[0] for d in cursor.description] if cursor.description else [], "rows": rows, "row_count": len(rows)}
        finally:
            conn.close()

    try:
        return await asyncio.to_thread(_run)
    except sqlite3.Error as exc:
        raise ToolExecutionError(
            "sql_query",
            f"SQLite error: {exc}",
            payload={"sql": statement[:500], "sqlite_error_code": getattr(exc, "sqlite_errorcode", None)},
            fallback="inspect the schema with: SELECT name FROM sqlite_master WHERE type='table'",
        ) from exc


# --------------------------------------------------------------------------
# memory_recall
# --------------------------------------------------------------------------


class MemoryLike(Protocol):
    def recall(self, query: str, *, top_k: int, scope: str, session_id: str | None) -> dict[str, Any]: ...


def make_memory_recall(store: MemoryLike) -> Callable[..., Awaitable[Any]]:
    async def memory_recall(*, query: str, top_k: int = 8, scope: str = "all", session_id: str | None = None) -> Any:
        return await asyncio.to_thread(store.recall, query, top_k=int(top_k), scope=scope, session_id=session_id)

    return memory_recall


# --------------------------------------------------------------------------
# Registry factory
# --------------------------------------------------------------------------


def build_registry(
    session: SessionGetter,
    *,
    executor_cfg: ExecutorConfig,
    memory_cfg: MemoryConfig,
    store: MemoryLike,
) -> ToolRegistry:
    """`session` is a zero-arg callable returning an aiohttp session (lazy loop-safe binding)."""

    registry = ToolRegistry()
    registry.register("web_search", make_web_search(session), timeout_s=30.0)
    registry.register("web_fetch", lambda **kw: web_fetch(session(), **kw), timeout_s=45.0)
    registry.register("python_exec", make_python_exec(executor_cfg), timeout_s=executor_cfg.timeout_s + 10)
    registry.register(
        "sql_query",
        lambda **kw: sql_query(_db_path=memory_cfg.db_path, **kw),
        timeout_s=15.0,
    )
    registry.register("memory_recall", make_memory_recall(store), timeout_s=10.0)
    return registry
