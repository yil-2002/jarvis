"""Voice I/O: speech-to-text (Gemini via Omni Router) + text-to-speech (edge-tts).

Why this design
---------------
The original build used OpenAI Whisper (STT) and ElevenLabs (TTS). Both need a
dedicated, paid, region-restricted API key. This module removes **both** and runs
the entire voice loop on infrastructure the agent already has:

* **STT** rides the Tier-3 multimodal model (Gemini through OpenRouter / "Omni
  Router"). Telegram's ``.ogg``/Opus voice note is base64-encoded into an
  ``input_audio`` chat part and Gemini transcribes it verbatim. No extra key
  (it reuses ``GEMINI_API_KEY``), no extra provider, and it inherits the retry /
  circuit-breaker / failover stack in :class:`~hermes.llm.LLMClient`. The bytes
  are forwarded as-is — Gemini accepts OGG natively, so the VPS does **zero**
  audio transcoding (no ffmpeg).
* **TTS** uses Microsoft's ``edge-tts`` (the free Edge "read aloud" neural
  voices). It needs **no API key at all** and streams MP3, delivered to Telegram
  via ``sendAudio`` (plays inline). A true ``sendVoice`` bubble would need
  OGG/Opus i.e. an ffmpeg transcode — deliberately avoided.

Every failure surfaces as a :class:`~hermes.errors.VoiceError` carrying the exact
provider payload plus a concrete fallback (never a fabricated transcript or a
silent success). A small :class:`VoiceTransport` Protocol seam keeps the
high-level :class:`VoiceClient` testable without network access.
"""

from __future__ import annotations

import asyncio
import base64
import logging
from typing import Any, Protocol, runtime_checkable

from .config import Tier, VoiceConfig
from .errors import LLMError, VoiceError
from .llm import LLMClient

log = logging.getLogger("hermes.voice")

__all__ = ["VoiceClient", "VoiceTransport", "GeminiEdgeVoiceTransport", "truncate_for_speech"]


# Map a Telegram audio mime_type to the short ``format`` token the OpenRouter /
# Gemini ``input_audio`` part expects. Telegram voice notes are audio/ogg (Opus).
_MIME_TO_FORMAT = {
    "audio/ogg": "ogg",
    "audio/opus": "ogg",
    "audio/mpeg": "mp3",
    "audio/mp3": "mp3",
    "audio/wav": "wav",
    "audio/x-wav": "wav",
    "audio/aac": "aac",
    "audio/mp4": "m4a",
    "audio/m4a": "m4a",
    "audio/webm": "webm",
    "audio/flac": "flac",
}


def _audio_format(mime_type: str) -> str:
    """Best-effort mime_type -> input_audio ``format`` token (defaults to ogg)."""

    return _MIME_TO_FORMAT.get((mime_type or "").split(";")[0].strip().lower(), "ogg")


# --------------------------------------------------------------------------
# transport seam
# --------------------------------------------------------------------------
@runtime_checkable
class VoiceTransport(Protocol):
    """STT + TTS provider calls. Real (Gemini + edge-tts) in prod, fake in tests."""

    async def transcribe(
        self,
        audio: bytes,
        *,
        mime_type: str,
        prompt: str,
        tier: Tier,
        timeout_s: float,
    ) -> str: ...

    async def synthesize(
        self,
        text: str,
        *,
        voice: str,
        rate: str,
        volume: str,
        pitch: str,
        timeout_s: float,
    ) -> bytes: ...

    async def close(self) -> None: ...


class GeminiEdgeVoiceTransport:
    """Production transport: STT via the shared :class:`LLMClient` (Tier-3 Gemini),
    TTS via the keyless ``edge-tts`` package.

    The ``LLMClient`` is owned by the orchestrator, so ``close()`` intentionally
    does **not** shut it down (that would tear down the agent's model access);
    edge-tts opens no persistent session, so there is nothing to release here.
    """

    def __init__(self, llm: LLMClient, *, tier: Tier = Tier.T3) -> None:
        self._llm = llm
        self._default_tier = tier

    async def transcribe(
        self,
        audio: bytes,
        *,
        mime_type: str,
        prompt: str,
        tier: Tier,
        timeout_s: float,
    ) -> str:
        """Gemini STT: base64 audio -> transcript text.

        Builds an ``input_audio`` multimodal message and routes it through the
        existing LLM client (retries + circuit breaker + failover). Temperature 0
        for faithful, deterministic transcription. An empty transcript (silence) is
        valid and returned as ``""`` — the caller decides how to phrase that.
        Raises :class:`VoiceError` (stage="stt") on any failure with the exact
        provider payload attached.
        """

        if not audio:
            raise VoiceError(
                "Cannot transcribe empty audio",
                stage="stt",
                payload={"bytes": 0, "mime_type": mime_type},
                fallback="the downloaded voice note was empty; ask the user to re-send it",
            )
        b64 = base64.b64encode(audio).decode("ascii")
        messages: list[dict[str, Any]] = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "input_audio",
                        "input_audio": {"data": b64, "format": _audio_format(mime_type)},
                    },
                ],
            }
        ]
        try:
            # Hard outer bound so a stuck provider cannot exceed the STT timeout even
            # though the tier profile's own timeout (and retries) may be larger.
            result = await asyncio.wait_for(
                self._llm.complete(tier or self._default_tier, messages, temperature=0.0),
                timeout=timeout_s,
            )
        except TimeoutError as exc:
            raise VoiceError(
                f"Audio transcription timed out after {timeout_s}s",
                stage="stt",
                payload={"tier": (tier or self._default_tier).value, "bytes": len(audio)},
                fallback="increase HERMES_STT_TIMEOUT or ask the user to send a shorter clip",
            ) from exc
        except LLMError as exc:
            raise VoiceError(
                f"Audio transcription failed: {exc.message}",
                stage="stt",
                status=exc.status,
                payload=exc.payload,
                fallback=(
                    f"verify {VoiceConfig.stt_api_key_env} is set and the Tier-3 model accepts "
                    "audio input; the exact provider error is in the payload above"
                ),
            ) from exc
        return (result.text or "").strip()

    async def synthesize(
        self,
        text: str,
        *,
        voice: str,
        rate: str,
        volume: str,
        pitch: str,
        timeout_s: float,
    ) -> bytes:
        """edge-tts: text -> MP3 audio bytes (streamed fully in memory).

        Raises :class:`VoiceError` (stage="tts") on any failure. TTS is non-fatal to
        the conversation (the text answer is already sent), so the caller logs and
        continues rather than surfacing this to the user.
        """

        try:
            import edge_tts  # lazy: optional dependency, imported only when speaking
        except ImportError as exc:  # pragma: no cover - guarded by VoiceConfig.tts_enabled
            raise VoiceError(
                "edge-tts is not installed",
                stage="tts",
                payload={"error": str(exc)},
                fallback='install it with: pip install "hermes-prime[voice]"  (or: pip install edge-tts)',
            ) from exc

        async def _stream() -> bytes:
            communicate = edge_tts.Communicate(text, voice, rate=rate, volume=volume, pitch=pitch)
            chunks: list[bytes] = []
            async for chunk in communicate.stream():
                if chunk.get("type") == "audio" and chunk.get("data"):
                    chunks.append(chunk["data"])
            return b"".join(chunks)

        try:
            audio = await asyncio.wait_for(_stream(), timeout=timeout_s)
        except TimeoutError as exc:
            raise VoiceError(
                f"edge-tts timed out after {timeout_s}s",
                stage="tts",
                payload={"voice": voice, "chars": len(text)},
                fallback="increase HERMES_TTS_TIMEOUT or shorten the reply; text answer is unaffected",
            ) from exc
        except Exception as exc:  # noqa: BLE001 - edge-tts raises assorted network/audio errors
            raise VoiceError(
                f"edge-tts synthesis failed: {exc.__class__.__name__}",
                stage="tts",
                payload={"voice": voice, "chars": len(text), "error": str(exc)},
                fallback=(
                    "check egress to speech.platform.bing.com (edge-tts is keyless but online); "
                    "the text answer was already delivered, so this is non-fatal"
                ),
            ) from exc

        if not audio:
            raise VoiceError(
                "edge-tts returned empty audio",
                stage="tts",
                payload={"voice": voice, "chars": len(text)},
                fallback="the voice name may be invalid; run `edge-tts --list-voices` to verify",
            )
        return audio

    async def close(self) -> None:
        # The LLMClient is owned/closed by the orchestrator; edge-tts keeps no
        # persistent session. Nothing to release here.
        return None


def truncate_for_speech(text: str, max_chars: int) -> str:
    """Trim ``text`` to <=``max_chars`` at a word boundary for TTS input.

    Long answers are capped so a single synthesis cannot stall the reply or run
    overly long. The full text is delivered separately as a normal message, so
    nothing is lost to the user — only the spoken rendition is shortened. Strips
    Markdown fences/inline code markers that read badly aloud.
    """

    if not text:
        return ""
    # Drop code fences and inline backticks; speech engines read them literally.
    cleaned = text.replace("```", " ").replace("`", " ")
    cleaned = " ".join(cleaned.split())  # collapse whitespace/newlines
    if max_chars <= 0 or len(cleaned) <= max_chars:
        return cleaned
    window = cleaned[:max_chars]
    cut = window.rfind(" ")
    if cut > max_chars // 2:  # only accept a break in the latter half
        window = window[:cut]
    return window.rstrip() + " …"


# --------------------------------------------------------------------------
# high-level client
# --------------------------------------------------------------------------
class VoiceClient:
    """Typed convenience wrapper over the voice transport, config-driven."""

    def __init__(self, transport: VoiceTransport, *, config: VoiceConfig | None = None) -> None:
        self._t = transport
        self.cfg = config or VoiceConfig()

    async def aclose(self) -> None:
        await self._t.close()

    def _stt_tier(self) -> Tier:
        """Resolve ``VoiceConfig.stt_tier`` to a :class:`Tier` (defaults to T3)."""

        try:
            return Tier(self.cfg.stt_tier)
        except ValueError:
            log.warning("unknown HERMES_STT_TIER=%r; falling back to Tier-3", self.cfg.stt_tier)
            return Tier.T3

    async def transcribe(
        self, audio: bytes, *, filename: str = "voice.ogg", mime_type: str = "audio/ogg"
    ) -> str:
        """STT: audio bytes -> transcript. Requires ``stt_enabled`` (GEMINI_API_KEY).

        ``filename`` is accepted for call-site compatibility but unused: the bytes
        are base64-encoded inline, so no multipart filename is sent anywhere.
        """

        if not self.cfg.stt_enabled:
            raise VoiceError(
                "Speech-to-text is not configured",
                stage="stt",
                payload={"env_var": self.cfg.stt_api_key_env},
                fallback=(
                    f"set {self.cfg.stt_api_key_env} (the Tier-3 key) to enable Gemini "
                    "transcription of voice notes"
                ),
            )
        return await self._t.transcribe(
            audio,
            mime_type=mime_type,
            prompt=self.cfg.stt_prompt,
            tier=self._stt_tier(),
            timeout_s=self.cfg.stt_timeout_s,
        )

    async def synthesize(self, text: str) -> bytes:
        """TTS: text -> MP3 bytes (truncated to ``tts_max_chars``). Requires ``tts_enabled``."""

        if not self.cfg.tts_enabled:
            raise VoiceError(
                "Text-to-speech is not available",
                stage="tts",
                payload={"reply_mode": self.cfg.tts_reply_mode},
                fallback=(
                    'install edge-tts (pip install "hermes-prime[voice]") and ensure '
                    "HERMES_TTS_REPLY_MODE is not 'off'"
                ),
            )
        spoken = truncate_for_speech(text, self.cfg.tts_max_chars)
        if not spoken:
            raise VoiceError(
                "Nothing to synthesize (empty answer)",
                stage="tts",
                payload={"chars": len(text)},
                fallback="the text answer was empty; skipping audio is correct here",
            )
        return await self._t.synthesize(
            spoken,
            voice=self.cfg.tts_voice,
            rate=self.cfg.tts_rate,
            volume=self.cfg.tts_volume,
            pitch=self.cfg.tts_pitch,
            timeout_s=self.cfg.tts_timeout_s,
        )
