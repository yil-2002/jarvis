"""Hermes-Prime CLI / single-shot runner.

Usage:
  export GROQ_API_KEY=... OPENROUTER_API_KEY=... GEMINI_API_KEY=...
  python -m main "Design a rate-limiter for a multi-tenant API gateway."
  python -m main --offline "hello"     # self-test without credentials
"""

from __future__ import annotations

import argparse
import asyncio
import dataclasses
import json
import logging
import os
import sys
from typing import Any

# Allow `python main.py`, `python -m main`, and the installed `hermes` console script.
if __package__ in (None, ""):  # pragma: no cover
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from hermes import HermesOrchestrator, load_settings  # type: ignore
    from hermes.errors import HermesError, MissingCredentialError  # type: ignore
else:  # pragma: no cover
    from .hermes import HermesOrchestrator, load_settings
    from .hermes.errors import HermesError, MissingCredentialError

# NOTE: tests.fake_transport is imported lazily inside _load_offline_transport().
# It is a test-only module and is NOT part of the installed wheel, so importing it
# at module load would crash the `hermes` console script on every invocation.


def _load_offline_transport() -> Any:
    """Import the test-only scripted transport, only when --offline is requested."""

    try:
        if __package__ in (None, ""):  # pragma: no cover
            from tests.fake_transport import scripted_transport  # type: ignore
        else:  # pragma: no cover
            from .tests.fake_transport import scripted_transport
    except ModuleNotFoundError as exc:  # pragma: no cover - installed-wheel path
        raise SystemExit(
            "--offline requires the tests package, which is not bundled with the installed "
            "wheel. Run offline mode from a source checkout, or drop --offline and set API keys."
        ) from exc
    return scripted_transport()


def _configure_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s | %(message)s",
        datefmt="%H:%M:%S",
    )


async def _run(prompt: str, *, offline: bool, session_id: str | None, show_trace: bool) -> int:
    settings = load_settings()
    transport: Any = None
    if offline or settings.offline:
        transport = _load_offline_transport()

    async with HermesOrchestrator(settings, transport=transport) as agent:
        response = await agent.handle(prompt, session_id=session_id)

    print("\n" + "=" * 72)
    print(f"TIER   : {response.tier}   (source={response.routing_source})")
    print(f"MODEL  : {response.model or 'n/a'}")
    print(f"INTENT : {response.intent}")
    if response.plan:
        print("PLAN   :")
        for i, step in enumerate(response.plan, 1):
            print(f"         {i}. {step}")
    print(f"USAGE  : {response.usage}")
    print(f"TIME   : {response.total_latency_ms} ms across {len(response.steps)} step(s)")
    if response.tool_results:
        print(f"TOOLS  : {', '.join(sorted({t['tool'] for t in response.tool_results}))}")
    if response.errors:
        print(f"ERRORS : {len(response.errors)} (see --trace)")
    print("=" * 72)
    print(response.text or "[empty response]")

    if show_trace:
        print("\n--- TRACE ---")
        print(json.dumps([dataclasses.asdict(s) for s in response.steps], indent=2, default=str))
        if response.errors:
            print("--- ERRORS ---")
            print(json.dumps(response.errors, indent=2, default=str))
    return 0 if response.text else 2


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="hermes", description="Hermes-Prime MoE router agent")
    parser.add_argument("prompt", nargs="*", help="User request (or pass --stdin)")
    parser.add_argument("--offline", action="store_true", help="use scripted transport (no credentials)")
    parser.add_argument("--session", default=None, help="session id for memory continuity")
    parser.add_argument("--trace", action="store_true", help="print step-by-step audit trace")
    parser.add_argument("--stdin", action="store_true", help="read the prompt from stdin")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    _configure_logging(args.verbose)

    if args.stdin:
        prompt = sys.stdin.read().strip()
    else:
        prompt = " ".join(args.prompt).strip()
    if not prompt:
        parser.error("a prompt is required (positional or --stdin)")

    try:
        return asyncio.run(_run(prompt, offline=args.offline, session_id=args.session, show_trace=args.trace))
    except KeyboardInterrupt:  # pragma: no cover
        return 130
    except HermesError as exc:
        # Clean, actionable failure instead of a raw traceback (spec: always
        # surface the exact error + a concrete fallback).
        print(f"\nERROR: {exc.message}", file=sys.stderr)
        if getattr(exc, "payload", None):
            print(f"  payload : {exc.payload}", file=sys.stderr)
        if exc.fallback:
            print(f"  fallback: {exc.fallback}", file=sys.stderr)
        if isinstance(exc, MissingCredentialError):
            print(
                "  hint    : copy .env.example to .env, add your keys, then "
                "`set -a; source .env; set +a` — or run with --offline for a no-key self-test.",
                file=sys.stderr,
            )
        return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
