"""Hermes-Prime HTTP service (aiohttp).

Endpoints
---------
  GET  /healthz          liveness (no upstream calls)
  GET  /readyz           readiness: DB reachable + at least one tier key present
  GET  /metrics          Prometheus-ish counters derived from the audit log
  GET  /v1/models        the configured tier -> model map
  POST /v1/chat          {message, session_id?, image_urls?, attachments?, tools?} -> AgentResponse
  POST /v1/route         dry-run the router only (no answer): useful for cost tracing

Run:
  python server.py --host 0.0.0.0 --port 8081
The service is stateless per request; all persistence goes through SQLite (WAL).
"""

from __future__ import annotations

import argparse
import asyncio
import hmac
import json
import logging
import os
import time
from collections import OrderedDict
from contextlib import suppress
from typing import Any

from aiohttp import web

from hermes import HermesOrchestrator, load_settings
from hermes.config import Settings, TelegramConfig, Tier, VoiceConfig
from hermes.documents import extract_document_text
from hermes.errors import BudgetExceededError, DocumentError, HermesError, TelegramError, VoiceError
from hermes.llm import LLMTransport
from hermes.telegram import TelegramClient, TelegramTransport
from hermes.voice import VoiceClient, VoiceTransport

log = logging.getLogger("hermes.server")

_MAX_BODY_BYTES = 8 * 1024 * 1024  # 8 MiB request cap
_ALLOWED_ORIGINS_DEFAULT = "*"

# Typed application keys (aiohttp >=3.9 recommends these over raw strings).
_AGENT_KEY: web.AppKey[HermesOrchestrator] = web.AppKey("agent", HermesOrchestrator)
_SETTINGS_KEY: web.AppKey[Settings] = web.AppKey("settings", Settings)
_CORS_KEY: web.AppKey[str] = web.AppKey("cors_origin", str)
_TRANSPORT_KEY: web.AppKey[LLMTransport] = web.AppKey("transport", LLMTransport)
_TELEGRAM_KEY: web.AppKey[TelegramClient] = web.AppKey("telegram", TelegramClient)
_TELEGRAM_TRANSPORT_KEY: web.AppKey[TelegramTransport] = web.AppKey("telegram_transport", TelegramTransport)
_VOICE_KEY: web.AppKey[VoiceClient] = web.AppKey("voice", VoiceClient)
_VOICE_TRANSPORT_KEY: web.AppKey[VoiceTransport] = web.AppKey("voice_transport", VoiceTransport)
_TELEGRAM_SEM_KEY: web.AppKey[asyncio.Semaphore] = web.AppKey("telegram_sem", asyncio.Semaphore)
_TELEGRAM_DEDUP_KEY: web.AppKey[OrderedDict] = web.AppKey("telegram_dedup", OrderedDict)
_TELEGRAM_TASKS_KEY: web.AppKey[set] = web.AppKey("telegram_tasks", set)
_MAINT_TASK_KEY: web.AppKey[asyncio.Task] = web.AppKey("maintenance_task", asyncio.Task)


def _json(data: Any, status: int = 200) -> web.Response:
    return web.json_response(data, status=status, dumps=lambda o: json.dumps(o, ensure_ascii=False, default=str))


def _error(status: int, code: str, message: str, **extra: Any) -> web.Response:
    return _json({"ok": False, "error": {"code": code, "message": message, **extra}}, status=status)


# --------------------------------------------------------------------------
# handlers
# --------------------------------------------------------------------------
_INDEX_HTML = """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>JARVIS — Just A Rather Very Intelligent System</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
  :root { color-scheme: dark; --jarvis:#53e0ff; --jarvis-dim:#2aa9c4; --gold:#f0b429;
          --bg:#04070d; --panel:#0b1622; --line:#16323f; }
  * { box-sizing: border-box; }
  body { margin:0; font-family: ui-sans-serif, system-ui, Segoe UI, Roboto, Arial; color:#dff3fa;
         background:
           radial-gradient(1100px 620px at 50% -8%, rgba(83,224,255,.16), transparent 60%),
           radial-gradient(760px 520px at 92% 4%, rgba(240,180,41,.10), transparent 60%),
           var(--bg); }
  .wrap { max-width: 920px; margin: 0 auto; padding: 28px 20px 60px; }
  h1 { font-size: 24px; margin: 0 0 4px; letter-spacing:.14em; font-weight:700;
       color:#eafcff; text-shadow:0 0 16px rgba(83,224,255,.55); }
  .sub { color:#8fb6c4; margin:0 0 24px; font-size:14px; }
  .grid { display:grid; grid-template-columns: repeat(auto-fit,minmax(230px,1fr)); gap:12px; margin-bottom:26px; }
  .card { background:var(--panel); border:1px solid var(--line); border-radius:10px; padding:14px 16px; }
  .card h3 { margin:0 0 6px; font-size:13px; color:#9fd8e8; letter-spacing:.03em; text-transform:uppercase; }
  .tier { font-size:15px; font-weight:600; }
  .t1 { color:#4ade80; } .t2 { color:var(--jarvis); } .t3 { color:var(--gold); }
  .model { font-size:12px; color:#7fa6b4; margin-top:2px; word-break:break-all; }
  table { width:100%; border-collapse:collapse; font-size:13.5px; margin-bottom:26px; }
  code, .m { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
  td, th { text-align:left; padding:8px 10px; border-bottom:1px solid var(--line); }
  th { color:#7fa6b4; font-weight:600; font-size:12px; text-transform:uppercase; letter-spacing:.04em; }
  .get { color:#4ade80; } .post { color:var(--gold); }
  .tester { background:var(--panel); border:1px solid var(--line); border-radius:12px; padding:18px; }
  label { font-size:12px; color:#7fa6b4; display:block; margin:0 0 6px; }
  textarea { width:100%; min-height:74px; background:#060d15; color:#dff3fa; border:1px solid var(--line);
             border-radius:8px; padding:10px; font-family:inherit; font-size:14px; resize:vertical; }
  .row { display:flex; gap:10px; margin-top:12px; flex-wrap:wrap; }
  button { background:linear-gradient(180deg,var(--jarvis),var(--jarvis-dim)); color:#04121a; border:0; border-radius:8px;
           padding:10px 16px; font-size:14px; font-weight:700; cursor:pointer; box-shadow:0 0 14px rgba(83,224,255,.35); }
  button.secondary { background:#12242f; color:#bfe9f5; box-shadow:none; border:1px solid var(--line); }
  button:disabled { opacity:.5; cursor:not-allowed; }
  pre { background:#060d15; border:1px solid var(--line); border-radius:8px; padding:12px; overflow:auto;
        font-size:12.5px; margin:14px 0 0; max-height:340px; white-space:pre-wrap; word-break:break-word; color:#cdeef8; }
  .pill { display:inline-block; font-size:11px; padding:2px 8px; border-radius:999px; background:rgba(240,180,41,.16); color:var(--gold); margin-left:8px; border:1px solid rgba(240,180,41,.3); }
  .answer { margin:14px 0 0; padding:14px 16px; background:linear-gradient(180deg,rgba(83,224,255,.08),rgba(83,224,255,.02));
            border:1px solid var(--line); border-left:3px solid var(--jarvis); border-radius:10px;
            font-size:14.5px; line-height:1.6; color:#eafcff; white-space:pre-wrap; word-break:break-word; }
  .answer .who { display:block; font-size:11px; letter-spacing:.12em; text-transform:uppercase; color:var(--jarvis); margin-bottom:8px; }
</style></head>
<body><div class="wrap">
  <h1>J.A.R.V.I.S. <span class="pill" id="mode">MoE router</span></h1>
  <p class="sub" id="greeting">At your service, Sir. Route by difficulty &middot; verify with tools &middot; compress memory &middot; never simulate an API.</p>
  <div class="grid" id="tiers"></div>
  <table><thead><tr><th>Method</th><th>Path</th><th>Purpose</th></tr></thead><tbody>
    <tr><td class="m get">GET</td><td class="m">/healthz</td><td>liveness</td></tr>
    <tr><td class="m get">GET</td><td class="m">/readyz</td><td>readiness + tier key presence</td></tr>
    <tr><td class="m get">GET</td><td class="m">/metrics</td><td>Prometheus counters from the audit log</td></tr>
    <tr><td class="m get">GET</td><td class="m">/v1/models</td><td>tier &rarr; model map, failover, tools</td></tr>
    <tr><td class="m post">POST</td><td class="m">/v1/route</td><td>dry-run the router (no answer, cheapest)</td></tr>
    <tr><td class="m post">POST</td><td class="m">/v1/chat</td><td>full agent run &rarr; AgentResponse</td></tr>
  </tbody></table>
  <div class="tester">
    <label for="msg">Talk to J.A.R.V.I.S.</label>
    <textarea id="msg">Design a sharded, event-driven architecture with consensus for a multi-tenant gateway</textarea>
    <div class="row">
      <button id="chat">Ask J.A.R.V.I.S.</button>
      <button id="route" class="secondary">Route only</button>
      <span id="status" class="model" style="align-self:center"></span>
    </div>
    <div id="answer" class="answer" hidden></div>
    <pre id="out">Response will appear here.</pre>
  </div>
</div>
<script>
  // --- Telegram Mini App bootstrap -------------------------------------
  const tg = window.Telegram && window.Telegram.WebApp;
  if (tg) {
    tg.ready();
    tg.expand();
    // Match the native header/background to the JARVIS arc-reactor palette.
    try { tg.setHeaderColor('#04070d'); tg.setBackgroundColor('#04070d'); } catch (e) {}
    try { tg.enableClosingConfirmation(); } catch (e) {}
    // Personalise the greeting with the Telegram user's first name (Stark-style).
    const u = (tg.initDataUnsafe && tg.initDataUnsafe.user) || {};
    if (u.first_name) {
      const g = document.getElementById('greeting');
      if (g) g.textContent = 'Good to see you, ' + u.first_name + '. Systems online, Sir. What are we building today?';
    }
  }
  function haptic(kind){ try { if (tg && tg.HapticFeedback) tg.HapticFeedback.impactOccurred(kind||'light'); } catch(e){} }

  const tiersEl = document.getElementById('tiers');
  const out = document.getElementById('out');
  const status = document.getElementById('status');
  const tierClass = { tier1_planning:'t1', tier2_deep:'t2', tier3_multimodal:'t3' };
  fetch('/v1/models').then(r=>r.json()).then(d=>{
    document.getElementById('mode').textContent = d.tools.length + ' tools wired';
    tiersEl.innerHTML = d.tiers.map(t=>`
      <div class="card"><h3>${t.tier}</h3>
      <div class="tier ${tierClass[t.tier]||''}">${t.provider}</div>
      <div class="model">${t.model}</div>
      <div class="model">ctx ${(t.context_window/1000)|0}k &middot; vision ${t.supports_vision?'yes':'no'} &middot; key ${t.key_present?'set':'missing'}</div>
      </div>`).join('');
  }).catch(e=>{ tiersEl.textContent = 'models load failed: '+e; });
  const answerEl = document.getElementById('answer');
  async function call(path){
    const msg = document.getElementById('msg').value;
    haptic('light');
    out.textContent = '...calling '+path; status.textContent='';
    answerEl.hidden = true; answerEl.textContent = '';
    const t0 = performance.now();
    try{
      // ngrok-skip-browser-warning keeps the free-ngrok interstitial off in-page
      // API calls (harmless on any other host).
      const r = await fetch(path,{
        method:'POST',
        headers:{'Content-Type':'application/json','ngrok-skip-browser-warning':'true'},
        body:JSON.stringify({message:msg,session_id:'web-miniapp'})
      });
      const d = await r.json();
      const ms = Math.round(performance.now()-t0);
      status.textContent = r.status+' in '+ms+'ms';
      // Show the model's answer chat-style up top; keep the raw JSON below.
      if (d.ok && d.answer) {
        answerEl.hidden = false;
        answerEl.innerHTML = '';
        const who = document.createElement('span');
        who.className = 'who';
        who.textContent = 'J.A.R.V.I.S. · ' + (d.tier||'') + (d.model? ' · '+d.model : '');
        answerEl.appendChild(who);
        answerEl.appendChild(document.createTextNode(d.answer));
        haptic('medium');
      }
      let view = d;
      if (d.ok && d.decision) view = d.decision;
      else if (d.ok) view = { tier:d.tier, model:d.model, intent:d.intent, routing_source:d.routing_source, plan:d.plan, usage:d.usage, total_latency_ms:d.total_latency_ms, answer:d.answer, errors:d.errors };
      out.textContent = JSON.stringify(view, null, 2);
    }catch(e){ out.textContent = 'request failed: '+e; haptic('heavy'); }
  }
  document.getElementById('chat').onclick  = ()=>call('/v1/chat');
  document.getElementById('route').onclick = ()=>call('/v1/route');
</script>
</body></html>"""


async def index(_request: web.Request) -> web.Response:
    return web.Response(text=_INDEX_HTML, content_type="text/html")


async def healthz(_request: web.Request) -> web.Response:
    return _json({"ok": True, "service": "hermes-prime", "ts": time.time()})



async def readyz(request: web.Request) -> web.Response:
    agent = request.app[_AGENT_KEY]
    checks: dict[str, Any] = {}
    ready = True
    try:
        agent.memory._conn.execute("SELECT 1").fetchone()
        checks["db"] = "ok"
    except Exception as exc:  # noqa: BLE001
        checks["db"] = f"error: {exc}"
        ready = False
    for tier, profile in agent.settings.profiles.items():
        checks[f"key:{tier.value}"] = "set" if os.environ.get(profile.api_key_env) else "missing"
    # Not fatal: a missing key just means that tier will fail over / degrade.
    return _json({"ok": ready, "checks": checks}, status=200 if ready else 503)


async def metrics(request: web.Request) -> web.Response:
    agent = request.app[_AGENT_KEY]
    rows = agent.memory.recent_audit(limit=2000)
    by_tier: dict[str, int] = {}
    by_step: dict[str, int] = {}
    failures = 0
    lat_sum = 0
    lat_n = 0
    for r in rows:
        if r.get("tier"):
            by_tier[r["tier"]] = by_tier.get(r["tier"], 0) + 1
        by_step[r["step"]] = by_step.get(r["step"], 0) + 1
        if not r.get("ok"):
            failures += 1
        if r.get("latency_ms"):
            lat_sum += r["latency_ms"]
            lat_n += 1
    lines = [
        "# HELP hermes_audit_events_total Audit events in the recent window",
        "# TYPE hermes_audit_events_total counter",
        f"hermes_audit_events_total {len(rows)}",
        "# HELP hermes_audit_failures_total Failed audit events",
        "# TYPE hermes_audit_failures_total counter",
        f"hermes_audit_failures_total {failures}",
        "# HELP hermes_latency_ms_avg Average step latency (ms)",
        "# TYPE hermes_latency_ms_avg gauge",
        f"hermes_latency_ms_avg {round(lat_sum / lat_n, 2) if lat_n else 0}",
    ]
    for tier, n in sorted(by_tier.items()):
        lines.append(f'hermes_tier_events{{tier="{tier}"}} {n}')
    for step, n in sorted(by_step.items()):
        lines.append(f'hermes_step_events{{step="{step}"}} {n}')
    return web.Response(text="\n".join(lines) + "\n", content_type="text/plain")


async def models(request: web.Request) -> web.Response:
    agent = request.app[_AGENT_KEY]
    return _json(
        {
            "ok": True,
            "tiers": [
                {
                    "tier": t.value,
                    "provider": p.provider,
                    "model": p.model,
                    "context_window": p.context_window,
                    "supports_vision": p.supports_vision,
                    "failover": list(p.failover),
                    "key_present": bool(os.environ.get(p.api_key_env)),
                }
                for t, p in agent.settings.profiles.items()
            ],
            "tools": agent.registry.names,
        }
    )


async def chat(request: web.Request) -> web.Response:
    agent = request.app[_AGENT_KEY]
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _error(400, "invalid_json", "request body must be a JSON object")
    if not isinstance(body, dict):
        return _error(400, "invalid_body", "request body must be a JSON object")

    message = body.get("message")
    if not isinstance(message, str) or not message.strip():
        return _error(422, "missing_message", "'message' must be a non-empty string")
    if len(message) > 2_000_000:
        return _error(413, "message_too_large", "message exceeds 2,000,000 characters")

    session_id = body.get("session_id")
    if session_id is not None and not isinstance(session_id, str):
        return _error(422, "bad_session_id", "'session_id' must be a string")

    image_urls = body.get("image_urls") or []
    if not isinstance(image_urls, list) or not all(isinstance(u, str) for u in image_urls):
        return _error(422, "bad_image_urls", "'image_urls' must be a list of strings")

    tools = body.get("tools")
    if tools is not None and (not isinstance(tools, list) or not all(isinstance(t, str) for t in tools)):
        return _error(422, "bad_tools", "'tools' must be a list of tool-name strings")

    try:
        response = await agent.handle(
            message,
            session_id=session_id,
            image_urls=image_urls or None,
            attachments=int(body.get("attachments", len(image_urls))),
            tools_override=tools,
            background_compress=True,  # never add compression latency to the HTTP response
        )
    except BudgetExceededError as exc:
        # Deliberate local quota refusal: NO upstream model was called, so a 502
        # ("upstream_error") would falsely signal that Groq/Gemini failed. 429 is the
        # honest status for a budget cap, and keeps the exact payload + fallback.
        log.warning("chat refused (daily budget exhausted): %s", exc.message)
        return _error(429, "budget_exceeded", exc.message, **{"fallback": exc.fallback, "payload": exc.payload})
    except HermesError as exc:
        log.warning("chat failed: %s", exc.message)
        return _error(502, "upstream_error", exc.message, **{"fallback": exc.fallback, "payload": exc.payload})
    except Exception as exc:  # noqa: BLE001
        log.exception("unhandled error in /v1/chat")
        return _error(500, "internal_error", exc.__class__.__name__)

    return _json({"ok": True, **response.to_dict()})


async def route_only(request: web.Request) -> web.Response:
    """Dry-run the router. Cheap way to inspect tier selection without paying for an answer."""

    agent = request.app[_AGENT_KEY]
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _error(400, "invalid_json", "request body must be a JSON object")
    message = body.get("message")
    if not isinstance(message, str) or not message.strip():
        return _error(422, "missing_message", "'message' must be a non-empty string")
    decision = await agent.router.route(
        message, has_image=bool(body.get("image_urls")), attachments=int(body.get("attachments", 0))
    )
    return _json({"ok": True, "decision": decision.to_dict()})


# --------------------------------------------------------------------------
# Telegram webhook
# --------------------------------------------------------------------------
def _log_task_failure(task: asyncio.Task[Any]) -> None:
    """Done-callback: surface background-task exceptions instead of swallowing them."""

    if task.cancelled():
        return
    exc = task.exception()
    if exc is not None:
        log.error("telegram background task %s failed: %r", task.get_name(), exc)


async def _keep_typing(tg: TelegramClient, chat_id: int, stop: asyncio.Event, interval: float) -> None:
    """Re-send the 'typing' action until ``stop`` is set (Telegram expires it after ~5s)."""

    while not stop.is_set():
        await tg.send_chat_action(chat_id, "typing")
        try:
            await asyncio.wait_for(stop.wait(), timeout=interval)
        except TimeoutError:
            continue


async def _ingest_document(
    tg: TelegramClient, tg_cfg: TelegramConfig, document: dict[str, Any]
) -> str:
    """Download a Telegram document and extract its text for Tier-3 analysis.

    Text files (.txt/.py/.json/.log/...) are decoded as UTF-8; PDFs go through
    pypdf. Raises :class:`DocumentError` (a ``HermesError``) for oversize,
    unsupported, or unreadable files so the caller's existing error handler
    surfaces the exact payload + a concrete fallback. The 20 MB ceiling is
    enforced both here (advertised size) and while streaming the download.
    """

    file_id = document.get("file_id")
    file_name = document.get("file_name") or "document"
    if not file_id:
        raise DocumentError(
            "Document update has no file_id.",
            payload={"document": document},
            fallback="Re-send the file; Telegram did not include a downloadable file_id.",
        )
    _info, data = await tg.download_file(file_id, max_bytes=tg_cfg.max_document_bytes)
    return extract_document_text(
        data,
        file_name=file_name,
        mime_type=document.get("mime_type"),
        max_bytes=tg_cfg.max_document_bytes,
        max_chars=tg_cfg.document_max_chars,
    )


async def _transcribe_voice(
    tg: TelegramClient, voice_client: VoiceClient, voice_cfg: VoiceConfig, voice: dict[str, Any]
) -> str:
    """Download a Telegram voice note and transcribe it (Gemini STT via Tier-3).

    Telegram voice arrives as ``.ogg``/Opus, which Gemini accepts directly, so the
    bytes are base64-encoded and forwarded as-is (no server-side transcoding).
    Raises :class:`VoiceError` (a ``HermesError``) for a missing file_id or any
    download/STT failure, so the caller's existing handler surfaces the exact
    payload + fallback. An empty transcript (silence) returns ``""``.
    """

    file_id = voice.get("file_id")
    if not file_id:
        raise VoiceError(
            "Voice update has no file_id.",
            stage="download",
            payload={"voice": voice},
            fallback="Re-send the voice note; Telegram did not include a downloadable file_id.",
        )
    mime = voice.get("mime_type") or "audio/ogg"
    _info, data = await tg.download_file(file_id, max_bytes=voice_cfg.stt_max_bytes)
    return await voice_client.transcribe(data, filename="voice.ogg", mime_type=mime)


async def _speak_reply(
    tg: TelegramClient, voice_client: VoiceClient, chat_id: int, text: str
) -> None:
    """Synthesize ``text`` (edge-tts) and send it as an inline audio reply.

    Strictly non-fatal: the text answer is already delivered, so any synth or
    send failure is logged with its exact payload and swallowed rather than
    alarming the user with a second, scary error message.
    """

    try:
        audio = await voice_client.synthesize(text)
    except VoiceError as exc:
        log.warning("TTS synth failed (non-fatal): %s | payload=%s", exc.message, exc.payload)
        return
    try:
        await tg.send_audio(chat_id, audio, title="J.A.R.V.I.S.", performer="J.A.R.V.I.S.")
    except TelegramError as exc:
        log.warning("TTS send_audio failed (non-fatal): %s | payload=%s", exc.message, exc.payload)


def _start_reply_markup(tg_cfg: TelegramConfig) -> dict[str, Any] | None:
    """Inline keyboard carrying the JARVIS Mini App (Web App) button.

    Returns ``None`` when no HTTPS Mini App URL is configured, so the greeting
    degrades gracefully to plain text (Telegram rejects non-HTTPS web_app URLs).
    """

    if not tg_cfg.miniapp_enabled:
        return None
    return {
        "inline_keyboard": [
            [{"text": tg_cfg.miniapp_button_text, "web_app": {"url": tg_cfg.resolved_miniapp_url}}]
        ]
    }


def _start_greeting_text(first_name: str | None) -> str:
    """In-character J.A.R.V.I.S. welcome for ``/start`` and ``/menu``.

    Static (no LLM spend): the house-butler voice with a touch of Stark's
    bravado, addressing the user as ``Sir``. Mirrors the persona in
    ``prompts/HERMES_CORE_SYSTEM.md``.
    """

    who = f", {first_name}" if first_name else ""
    return (
        f"Systems online{who}, Sir. J.A.R.V.I.S. at your service — routing by "
        "difficulty, verifying before I speak, compressing what we learn, and "
        "never once faking an answer.\n\n"
        "The full console is a tap away below. Or simply tell me what we're "
        "building — I do so hate an idle afternoon."
    )


async def _process_telegram_update(app: web.Application, update: dict[str, Any]) -> None:
    """Background worker: run the agent for one update and deliver the reply.

    Runs off the request path so the webhook can fast-ack 200 (Telegram retries
    updates whose webhook does not answer within a few seconds, which would
    otherwise duplicate every long Tier-2/Tier-3 answer).
    """

    settings = app[_SETTINGS_KEY]
    tg_cfg = settings.telegram
    voice_cfg = settings.voice
    tg = app[_TELEGRAM_KEY]
    voice_client = app[_VOICE_KEY]
    agent = app[_AGENT_KEY]
    sem = app[_TELEGRAM_SEM_KEY]

    message = update.get("message") or update.get("edited_message") or {}
    chat = message.get("chat") or {}
    chat_id = chat.get("id")
    if chat_id is None:
        return

    # --- Access control (whitelist) -------------------------------------
    # Enforced BEFORE the semaphore and before any router/LLM spend, so an
    # unauthorized sender costs zero compute and zero concurrency slot. An empty
    # allowlist disables the gate (single-user/dev default), preserving existing
    # behaviour and the current test-suite.
    allowed = tg_cfg.allowed_users
    if allowed:
        sender_id = (message.get("from") or {}).get("id")
        if sender_id not in allowed:
            log.warning(
                "telegram: rejecting unauthorized sender_id=%s chat_id=%s", sender_id, chat_id
            )
            with suppress(TelegramError):
                await tg.send_message(chat_id, "403: Ruxsat berilmagan foydalanuvchi", parse_mode=None)
            return

    text = (message.get("text") or "").strip()
    document = message.get("document")
    voice = message.get("voice")
    if not text and not document and not voice:
        return  # non-text, non-document, non-voice update (photo/sticker/etc.): nothing to route

    # --- Bot commands: /start, /menu (no LLM, no semaphore slot) --------
    # Handled before the concurrency gate on purpose: a menu open costs zero
    # compute. Accepts the @botname suffix Telegram appends in groups
    # (e.g. "/start@jarvis_bot"). Replies with the in-character JARVIS greeting
    # plus an inline Mini App button when an HTTPS Web App URL is configured.
    if not document and not voice and text.startswith("/"):
        cmd = text.split()[0].split("@")[0].lower()
        if cmd in {"/start", "/menu"}:
            first_name = (message.get("from") or {}).get("first_name")
            with suppress(TelegramError):
                await tg.send_message(
                    chat_id,
                    _start_greeting_text(first_name),
                    reply_markup=_start_reply_markup(tg_cfg),
                )
            return

    # Bound concurrent agent runs so a burst of messages cannot exhaust the VPS.
    async with sem:
        stop_typing = asyncio.Event()
        typing_task = asyncio.create_task(_keep_typing(tg, chat_id, stop_typing, tg_cfg.typing_refresh_s))
        try:
            force_tier: Tier | None = None
            prompt = text
            incoming_was_voice = voice is not None
            if voice is not None:
                # Speech-to-text: transcribe the voice note (Gemini via Tier-3) and
                # treat the transcript as the user's message. A VoiceError propagates
                # to the handler below, which surfaces the exact payload + a fallback.
                if not voice_cfg.stt_enabled:
                    raise VoiceError(
                        "I can hear you, Sir, but speech-to-text is not configured.",
                        stage="stt",
                        payload={"env_var": voice_cfg.stt_api_key_env},
                        fallback=(
                            f"set {voice_cfg.stt_api_key_env} (the Tier-3 key) to enable Gemini "
                            "transcription, or send your request as text"
                        ),
                    )
                prompt = await _transcribe_voice(tg, voice_client, voice_cfg, voice)
                if not prompt:
                    # Silence / unintelligible: reply in character, spend no LLM call.
                    with suppress(TelegramError):
                        await tg.send_message(
                            chat_id,
                            "I caught only silence, Sir. Perhaps try that once more?",
                            parse_mode=None,
                        )
                    return
            elif document is not None:
                # Document ingestion: extract the file text and pin the request to the
                # large-context Tier-3 model (Gemini). The caption/text is the user's
                # instruction about the document; the body is appended verbatim.
                doc_text = await _ingest_document(tg, tg_cfg, document)
                caption = (message.get("caption") or text or "").strip()
                file_name = document.get("file_name") or "document"
                instruction = caption or "Analyze the attached document."
                prompt = (
                    f"{instruction}\n\n"
                    f"--- BEGIN DOCUMENT '{file_name}' ---\n{doc_text}\n--- END DOCUMENT ---"
                )
                force_tier = Tier.T3

            response = await agent.handle(
                prompt,
                session_id=f"tg_{chat_id}",
                background_compress=True,
                force_tier=force_tier,
            )
            answer = response.text or "[empty response]"
            footer = f"\n\n`[{response.tier} · {response.model or 'n/a'}]`"
            await tg.send_message(chat_id, answer + footer)

            # Text-to-speech: optionally speak the answer back. Non-fatal — the text
            # answer is already delivered, so any synth/send failure is logged and
            # swallowed inside _speak_reply rather than alarming the user.
            if voice_cfg.should_speak(incoming_was_voice=incoming_was_voice):
                await _speak_reply(tg, voice_client, chat_id, answer)
        except HermesError as exc:
            # Spec: log the exact error payload + a concrete fallback; never simulate success.
            log.warning("telegram agent run failed: %s | payload=%s", exc.message, exc.payload)
            with suppress(TelegramError):
                await tg.send_message(chat_id, f"⚠️ {exc.message}\n\nFallback: {exc.fallback}", parse_mode=None)
        except Exception:  # noqa: BLE001
            log.exception("unhandled error processing telegram update_id=%s", update.get("update_id"))
            with suppress(TelegramError):
                await tg.send_message(
                    chat_id, "⚠️ Internal error processing your request. Please retry.", parse_mode=None
                )
        finally:
            stop_typing.set()
            typing_task.cancel()
            with suppress(asyncio.CancelledError):
                await typing_task


async def telegram_webhook(request: web.Request) -> web.Response:
    """Authenticated Telegram webhook: verify -> dedup -> fast-ack -> background."""

    settings = request.app[_SETTINGS_KEY]
    tg_cfg = settings.telegram
    if not tg_cfg.enabled:
        return _error(503, "telegram_disabled", "TELEGRAM_BOT_TOKEN is not configured")

    # 1. Authenticate the caller. Telegram echoes secret_token in this header on
    #    every update; constant-time compare prevents an attacker who finds the
    #    URL from burning LLM credits.
    secret = tg_cfg.webhook_secret
    provided = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
    if not secret or not hmac.compare_digest(provided, secret):
        log.warning("telegram webhook auth failure from %s", request.remote)
        return _error(403, "forbidden", "invalid or missing X-Telegram-Bot-Api-Secret-Token")

    # 2. Parse the update.
    try:
        update = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _error(400, "invalid_json", "telegram update must be a JSON object")
    if not isinstance(update, dict):
        return _error(400, "invalid_update", "telegram update must be a JSON object")

    # 3. Dedup by update_id (Telegram retries on non-200 / timeout).
    update_id = update.get("update_id")
    dedup = request.app[_TELEGRAM_DEDUP_KEY]
    if isinstance(update_id, int):
        if update_id in dedup:
            return _json({"ok": True, "duplicate": True})
        dedup[update_id] = True
        while len(dedup) > tg_cfg.dedupe_window:
            dedup.popitem(last=False)

    # 4. Fast-ack: schedule the work and answer 200 immediately.
    task = asyncio.create_task(
        _process_telegram_update(request.app, update), name=f"tg:{update_id}"
    )
    tasks = request.app[_TELEGRAM_TASKS_KEY]
    tasks.add(task)
    task.add_done_callback(tasks.discard)
    task.add_done_callback(_log_task_failure)
    return _json({"ok": True})


# --------------------------------------------------------------------------
# app wiring
# --------------------------------------------------------------------------
@web.middleware
async def _cors_and_errors(request: web.Request, handler: Any) -> web.StreamResponse:
    if request.method == "OPTIONS":
        return web.Response(
            status=204,
            headers={
                "Access-Control-Allow-Origin": request.app[_CORS_KEY],
                "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type,Authorization",
            },
        )
    try:
        response = await handler(request)
    except web.HTTPException:
        raise
    except Exception:  # noqa: BLE001
        log.exception("unhandled error in %s", request.path)
        response = _error(500, "internal_error", "unhandled server error")
    response.headers["Access-Control-Allow-Origin"] = request.app[_CORS_KEY]
    return response


async def _maintenance_loop(agent: HermesOrchestrator, interval_h: int) -> None:
    """Periodic disk hygiene: prune ``audit_log`` + checkpoint/truncate the WAL.

    Runs the blocking SQLite pass directly on the event loop on purpose: it is a
    write, and ``MemoryStore`` keeps all writes on this thread for ordering (see
    its docstring). On a small Hetzner database the pass is sub-second. Fires once
    at boot (cleaning up after the previous process), then every ``interval_h``
    hours; ``interval_h <= 0`` means startup-only. Cancelled cleanly at shutdown.
    """

    while True:
        try:
            agent.memory.maintenance()
        except Exception:  # noqa: BLE001
            log.exception("maintenance pass failed; will retry next interval")
        if interval_h <= 0:
            return
        await asyncio.sleep(interval_h * 3600)


async def _on_startup(app: web.Application) -> None:
    settings = app[_SETTINGS_KEY]
    transport = app.get(_TRANSPORT_KEY)
    app[_AGENT_KEY] = HermesOrchestrator(settings, transport=transport)
    log.info(
        "agent ready; tiers=%s tools=%s",
        {t.value: p.model for t, p in settings.profiles.items()},
        app[_AGENT_KEY].registry.names,
    )

    # Telegram integration: shared client + concurrency/dedup state. Created only
    # when a bot token is present, so the HTTP API runs standalone otherwise.
    tg_cfg = settings.telegram
    app[_TELEGRAM_SEM_KEY] = asyncio.Semaphore(tg_cfg.max_concurrent)
    app[_TELEGRAM_DEDUP_KEY] = OrderedDict()
    app[_TELEGRAM_TASKS_KEY] = set()
    if tg_cfg.enabled:
        tg_transport = app.get(_TELEGRAM_TRANSPORT_KEY)
        if tg_transport is None:
            from hermes.telegram import HttpTelegramTransport

            tg_transport = HttpTelegramTransport(
                tg_cfg.bot_token, api_base=tg_cfg.api_base, timeout_s=tg_cfg.timeout_s
            )
        app[_TELEGRAM_KEY] = TelegramClient(tg_transport, config=tg_cfg)
        log.info("telegram webhook enabled at %s", tg_cfg.webhook_path)
    else:
        log.info("telegram disabled (set TELEGRAM_BOT_TOKEN to enable the webhook)")

    # Voice integration: STT rides the Tier-3 Gemini model (via the agent's own
    # LLMClient, so it reuses GEMINI_API_KEY + the retry/breaker/failover stack);
    # TTS uses the keyless edge-tts package. Both are opt-in: the client is always
    # constructed (cheap) but only does work when the relevant *_enabled property
    # is true. Used only on the Telegram path.
    voice_cfg = settings.voice
    voice_transport = app.get(_VOICE_TRANSPORT_KEY)
    if voice_transport is None:
        from hermes.voice import GeminiEdgeVoiceTransport

        # Reuse the orchestrator's LLMClient (created above) for transcription.
        voice_transport = GeminiEdgeVoiceTransport(app[_AGENT_KEY].llm)
    app[_VOICE_KEY] = VoiceClient(voice_transport, config=voice_cfg)
    log.info(
        "voice: stt=%s (%s) tts=%s (edge-tts %s, mode=%s)",
        "on" if voice_cfg.stt_enabled else "off",
        voice_cfg.stt_tier,
        "on" if voice_cfg.tts_enabled else "off",
        voice_cfg.tts_voice,
        voice_cfg.tts_reply_mode,
    )

    # Disk-hygiene timer: prune audit_log + truncate the WAL so a small Hetzner
    # volume does not bloat over months. Runs once at boot, then every N hours.
    app[_MAINT_TASK_KEY] = asyncio.create_task(
        _maintenance_loop(app[_AGENT_KEY], settings.memory.maintenance_interval_h),
        name="hermes-maintenance",
    )


async def _on_cleanup(app: web.Application) -> None:
    # 1. Stop the maintenance timer first so it cannot fire mid-teardown.
    maint = app.get(_MAINT_TASK_KEY)
    if maint is not None:
        maint.cancel()
        with suppress(asyncio.CancelledError):
            await maint

    # 2. Graceful drain: give in-flight webhook tasks a bounded window to finish
    #    and deliver their reply before we tear down. Without this, `systemctl
    #    restart` cancels a 15-40s Tier-2/3 run mid-flight and the user gets
    #    nothing. Budget: this drain (shutdown_drain_s) + agent.aclose()'s own
    #    15s compression drain must stay under systemd TimeoutStopSec, else
    #    SIGKILL defeats the point. Only stragglers past the deadline are cut.
    tasks = app.get(_TELEGRAM_TASKS_KEY)
    if tasks:
        drain_s = app[_SETTINGS_KEY].telegram.shutdown_drain_s
        pending = {t for t in tasks if not t.done()}
        if pending:
            log.info("draining %d in-flight telegram task(s) for up to %.1fs", len(pending), drain_s)
            _done, still_pending = await asyncio.wait(pending, timeout=drain_s)
            for t in still_pending:
                t.cancel()
            if still_pending:
                await asyncio.gather(*still_pending, return_exceptions=True)

    # 3. Close clients.
    tg = app.get(_TELEGRAM_KEY)
    if tg is not None:
        await tg.aclose()
    voice = app.get(_VOICE_KEY)
    if voice is not None:
        await voice.aclose()
    agent = app.get(_AGENT_KEY)
    if agent is not None:
        await agent.aclose()


def create_app(
    *,
    transport: Any = None,
    telegram_transport: Any = None,
    voice_transport: Any = None,
    cors_origin: str | None = None,
) -> web.Application:
    settings = load_settings()
    app = web.Application(middlewares=[_cors_and_errors], client_max_size=_MAX_BODY_BYTES)
    app[_SETTINGS_KEY] = settings
    app[_CORS_KEY] = cors_origin or os.environ.get("HERMES_CORS_ORIGIN", _ALLOWED_ORIGINS_DEFAULT)
    if transport is not None:
        app[_TRANSPORT_KEY] = transport
    if telegram_transport is not None:
        app[_TELEGRAM_TRANSPORT_KEY] = telegram_transport
    if voice_transport is not None:
        app[_VOICE_TRANSPORT_KEY] = voice_transport
    app.on_startup.append(_on_startup)
    app.on_cleanup.append(_on_cleanup)
    app.router.add_get("/", index)
    app.router.add_get("/healthz", healthz)
    app.router.add_get("/readyz", readyz)
    app.router.add_get("/metrics", metrics)
    app.router.add_get("/v1/models", models)
    app.router.add_post("/v1/chat", chat)
    app.router.add_post("/v1/route", route_only)
    # Webhook path is configurable; register it even when disabled so the route
    # answers a clean 503 (telegram_disabled) rather than a confusing 404.
    app.router.add_post(settings.telegram.webhook_path, telegram_webhook)
    return app


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Hermes-Prime HTTP service")
    parser.add_argument("--host", default=os.environ.get("HERMES_HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("HERMES_PORT", "8081")))
    parser.add_argument("--cors-origin", default=None)
    parser.add_argument("--offline", action="store_true", help="use scripted transport (self-test, no credentials)")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s | %(message)s",
        datefmt="%H:%M:%S",
    )

    transport = None
    telegram_transport = None
    voice_transport = None
    if args.offline:
        from tests.fake_transport import (  # local import: test-only path
            scripted_telegram_transport,
            scripted_transport,
            scripted_voice_transport,
        )

        transport = scripted_transport()
        telegram_transport = scripted_telegram_transport()
        voice_transport = scripted_voice_transport()
        # Enable the webhook for the offline demo with clearly-fake credentials so
        # the full flow is exercisable without a real bot token or network. Real
        # values, if already present, are never clobbered (setdefault).
        os.environ.setdefault("TELEGRAM_BOT_TOKEN", "offline-demo-token")
        os.environ.setdefault("TELEGRAM_WEBHOOK_SECRET", "offline-demo-secret")
        # STT rides Tier-3, so a fake GEMINI_API_KEY flips VoiceConfig.stt_enabled on;
        # TTS (edge-tts) is keyless and enabled by default. Together they exercise the
        # whole voice path (STT->agent->TTS) against the scripted transports.
        os.environ.setdefault("GEMINI_API_KEY", "offline-demo-gemini")

    app = create_app(
        transport=transport,
        telegram_transport=telegram_transport,
        voice_transport=voice_transport,
        cors_origin=args.cors_origin,
    )
    log.info("listening on http://%s:%d", args.host, args.port)
    web.run_app(app, host=args.host, port=args.port, print=None)


if __name__ == "__main__":  # pragma: no cover
    main()
