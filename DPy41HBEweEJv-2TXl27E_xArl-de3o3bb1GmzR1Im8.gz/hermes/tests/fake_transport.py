"""Test-only scripted transport.

This is NOT a production code path: it exists so the orchestrator loop can be
exercised deterministically without credentials or network. Real deployments use
hermes.llm.HTTPTransport. The transport inspects the request to decide whether it
is being asked to (a) route, (b) compress memory, or (c) answer, and replays a
canned-but-valid response for each.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from hermes.config import ModelProfile
from hermes.errors import TelegramError


def _chat(content: str | None = None, *, tool_calls: list[dict[str, Any]] | None = None, model: str = "fake") -> dict[str, Any]:
    message: dict[str, Any] = {"role": "assistant", "content": content}
    if tool_calls:
        message["tool_calls"] = tool_calls
        message["content"] = content or ""
    return {
        "id": "chatcmpl-fake",
        "model": model,
        "choices": [{"index": 0, "message": message, "finish_reason": "tool_calls" if tool_calls else "stop"}],
        "usage": {"prompt_tokens": 120, "completion_tokens": 40, "total_tokens": 160},
    }


class FakeTransport:
    """Replays a queue of raw provider responses; last one repeats."""

    def __init__(self, responses: list[dict[str, Any]]) -> None:
        self._responses = list(responses)
        self.calls: list[dict[str, Any]] = []

    async def complete(
        self,
        profile: ModelProfile,
        model: str,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None,
        json_mode: bool,
        max_tokens: int,
        temperature: float,
        timeout_s: float,
    ) -> dict[str, Any]:
        self.calls.append(
            {
                "tier": profile.tier.value,
                "model": model,
                "json_mode": json_mode,
                "tools": [t["function"]["name"] for t in (tools or [])],
                "last_user": _last_user_text(messages),
            }
        )
        idx = min(len(self.calls) - 1, len(self._responses) - 1)
        resp = self._responses[idx]
        if callable(resp):
            resp = resp(profile, messages, tools)
        return resp


def _last_user_text(messages: list[dict[str, Any]]) -> str:
    for m in reversed(messages):
        if m.get("role") == "user":
            content = m.get("content")
            if isinstance(content, str):
                return content
            if isinstance(content, list):  # vision message parts
                return " ".join(p.get("text", "") for p in content if isinstance(p, dict))
    return ""


def _system_text(messages: list[dict[str, Any]]) -> str:
    for m in messages:
        if m.get("role") == "system":
            return m.get("content") or ""
    return ""


def scripted_transport() -> FakeTransport:
    """A context-aware fake that produces a valid route/compress/answer per call."""

    def responder(profile: ModelProfile, messages: list[dict[str, Any]], tools: list[dict[str, Any]] | None) -> dict[str, Any]:
        system = _system_text(messages)
        if "router" in system.lower() and "classify" in system.lower():
            return _chat(
                json.dumps(
                    {
                        "tier": "tier2_deep",
                        "confidence": 0.88,
                        "intent": "architecture",
                        "requires_tools": [],
                        "plan": ["Identify constraints", "Select data structure", "Justify complexity"],
                        "needs_memory": False,
                        "reasoning": "System-design request requiring deep synthesis.",
                    }
                )
            )
        if "compress dialogue history" in system.lower():
            return _chat(
                json.dumps(
                    {
                        "summary": "User is building Hermes-Prime, an MoE multi-model router on a Hetzner VPS.",
                        "triplets": [
                            {"subject": "Hermes-Prime", "predicate": "is", "object": "an MoE router agent", "confidence": 0.9, "source": "user"},
                            {"subject": "router", "predicate": "delegates_t1_to", "object": "Groq 120B", "confidence": 0.9, "source": "user"},
                            {"subject": "router", "predicate": "delegates_t2_to", "object": "Llama 3.1 405B", "confidence": 0.9, "source": "user"},
                        ],
                        "open_questions": ["Attach JSON tool-calling schemas?"],
                    }
                )
            )
        # Main answer turn. If tools are offered and the user asked for facts, call one.
        if tools and any(t["function"]["name"] == "web_search" for t in tools) and "latest" in _last_user_text(messages).lower():
            return _chat(
                "",
                tool_calls=[
                    {
                        "id": "call_1",
                        "type": "function",
                        "function": {
                            "name": "web_search",
                            "arguments": json.dumps({"query": "current stable version", "max_results": 3}),
                        },
                    }
                ],
            )
        return _chat(
            "Production answer: a token-bucket rate limiter per tenant, backed by Redis with Lua for atomicity, "
            "sharded by tenant id, degrading to a local in-memory bucket on Redis outage. "
            "Complexity O(1) per request.",
            model=profile.model,
        )

    return FakeTransport([responder])


class FakeTelegramTransport:
    """Offline stand-in for the Telegram Bot API transport.

    Captures every outgoing call and logs sendMessage text so the webhook flow
    is visible in the server log without any network access. Implements the same
    TelegramTransport Protocol as hermes.telegram.HttpTelegramTransport.
    """

    def __init__(self, *, files: dict[str, bytes] | None = None) -> None:
        self.calls: list[dict[str, Any]] = []
        self.closed = False
        self._log = logging.getLogger("hermes.telegram.fake")
        # file_id -> raw bytes served by download(); getFile echoes a file_path.
        self._files: dict[str, bytes] = dict(files or {})

    def set_file(self, file_id: str, data: bytes) -> None:
        self._files[file_id] = data

    async def call(self, method: str, payload: dict[str, Any]) -> dict[str, Any]:
        self.calls.append({"method": method, "payload": dict(payload)})
        if method == "sendMessage":
            text = payload.get("text", "")
            self._log.info(
                "[offline] sendMessage -> chat_id=%s len=%d: %s",
                payload.get("chat_id"),
                len(text),
                text[:160].replace("\n", " "),
            )
            return {"ok": True, "result": {"message_id": len(self.calls), "text": text}}
        if method == "sendChatAction":
            return {"ok": True, "result": True}
        if method == "getWebhookInfo":
            return {"ok": True, "result": {"url": "offline://demo", "pending_update_count": 0}}
        if method == "getFile":
            file_id = payload.get("file_id", "")
            data = self._files.get(file_id, b"")
            return {
                "ok": True,
                "result": {
                    "file_id": file_id,
                    "file_path": f"documents/{file_id}.bin",
                    "file_size": len(data),
                },
            }
        return {"ok": True, "result": True}

    async def download(self, file_path: str, max_bytes: int) -> bytes:
        self.calls.append({"method": "download", "payload": {"file_path": file_path}})
        # file_path is "documents/<file_id>.bin"; recover the id to look up bytes.
        file_id = file_path.rsplit("/", 1)[-1].removesuffix(".bin")
        data = self._files.get(file_id, b"")
        if len(data) > max_bytes:
            raise TelegramError(
                f"file exceeds {max_bytes} bytes", payload={"file_path": file_path, "size": len(data)}
            )
        return data

    async def upload(
        self,
        method: str,
        fields: dict[str, Any],
        *,
        file_field: str,
        file_bytes: bytes,
        filename: str,
        content_type: str,
    ) -> dict[str, Any]:
        self.calls.append(
            {
                "method": method,
                "payload": dict(fields),
                "file_field": file_field,
                "file_bytes": len(file_bytes),
                "filename": filename,
                "content_type": content_type,
            }
        )
        if method == "sendAudio":
            self._log.info(
                "[offline] sendAudio -> chat_id=%s bytes=%d title=%s",
                fields.get("chat_id"),
                len(file_bytes),
                fields.get("title", ""),
            )
            return {"ok": True, "result": {"message_id": len(self.calls), "audio": {"file_id": "offline-audio"}}}
        return {"ok": True, "result": True}

    async def close(self) -> None:
        self.closed = True

    def sends(self) -> list[dict[str, Any]]:
        return [c for c in self.calls if c["method"] == "sendMessage"]

    def uploads(self) -> list[dict[str, Any]]:
        return [c for c in self.calls if c["method"] == "sendAudio"]


def scripted_telegram_transport() -> FakeTelegramTransport:
    return FakeTelegramTransport()


class FakeVoiceTransport:
    """Offline stand-in for the Gemini-STT + edge-tts voice transport.

    Implements the same :class:`~hermes.voice.VoiceTransport` Protocol as
    ``GeminiEdgeVoiceTransport``. ``transcribe`` replays a queued transcript (or a
    default) and records the audio it was handed; ``synthesize`` returns
    deterministic fake MP3 bytes and records the text. Lets the full voice path
    (STT -> agent -> TTS) be exercised with zero network or credentials.
    """

    def __init__(self, *, transcripts: list[str] | None = None, audio: bytes | None = None) -> None:
        self.calls: list[dict[str, Any]] = []
        self.closed = False
        self._log = logging.getLogger("hermes.voice.fake")
        self._transcripts = list(transcripts or [])
        # A minimal valid-ish MP3 frame header so downstream length checks pass.
        self._audio = audio if audio is not None else b"\xff\xfb\x90\x00" + b"\x00" * 64

    async def transcribe(
        self,
        audio: bytes,
        *,
        mime_type: str,
        prompt: str,
        tier: Any,
        timeout_s: float,
    ) -> str:
        self.calls.append(
            {
                "op": "stt",
                "bytes": len(audio),
                "mime_type": mime_type,
                "prompt": prompt,
                "tier": getattr(tier, "value", tier),
            }
        )
        idx = min(len([c for c in self.calls if c["op"] == "stt"]) - 1, len(self._transcripts) - 1)
        if self._transcripts:
            transcript = self._transcripts[idx]
        else:
            transcript = "What is our current architecture?"
        self._log.info("[offline] STT -> %d bytes => %r", len(audio), transcript[:80])
        return transcript

    async def synthesize(
        self,
        text: str,
        *,
        voice: str,
        rate: str,
        volume: str,
        pitch: str,
        timeout_s: float,
    ) -> bytes:
        self.calls.append({"op": "tts", "chars": len(text), "voice": voice})
        self._log.info("[offline] TTS -> %d chars => %d bytes mp3", len(text), len(self._audio))
        return self._audio

    async def close(self) -> None:
        self.closed = True

    def stt_calls(self) -> list[dict[str, Any]]:
        return [c for c in self.calls if c["op"] == "stt"]

    def tts_calls(self) -> list[dict[str, Any]]:
        return [c for c in self.calls if c["op"] == "tts"]


def scripted_voice_transport(*, transcripts: list[str] | None = None) -> FakeVoiceTransport:
    return FakeVoiceTransport(transcripts=transcripts)


__all__ = [
    "FakeTransport",
    "scripted_transport",
    "FakeTelegramTransport",
    "scripted_telegram_transport",
    "FakeVoiceTransport",
    "scripted_voice_transport",
]
