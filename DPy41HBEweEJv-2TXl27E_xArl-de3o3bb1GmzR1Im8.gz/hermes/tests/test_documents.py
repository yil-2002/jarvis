"""Document ingestion unit tests: text + PDF extraction and the size/type guards.

Run: python -m pytest -q tests/test_documents.py  (or)  python -m tests.test_documents
"""

from __future__ import annotations

import io
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hermes.documents import MAX_DOWNLOAD_BYTES, extract_document_text, is_supported_document  # noqa: E402
from hermes.errors import DocumentError  # noqa: E402

PASSED, FAILED = [], []


def check(name, fn):
    try:
        fn()
        PASSED.append(name)
        print(f"  PASS  {name}")
    except AssertionError as e:
        FAILED.append((name, str(e)))
        print(f"  FAIL  {name}: {e}")
    except Exception as e:  # noqa: BLE001
        FAILED.append((name, f"{type(e).__name__}: {e}"))
        print(f"  ERROR {name}: {type(e).__name__}: {e}")


def _build_pdf(text: str) -> bytes:
    """Minimal single-page PDF with a real text layer (pypdf-extractable).

    Hand-built with correct xref byte offsets so pypdf parses it without needing
    a heavyweight generator dependency in the test environment.
    """

    objs = [
        b"<</Type/Catalog/Pages 2 0 R>>",
        b"<</Type/Pages/Kids[3 0 R]/Count 1>>",
        b"<</Type/Page/Parent 2 0 R/MediaBox[0 0 300 144]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>",
    ]
    stream = f"BT /F1 12 Tf 20 100 Td ({text}) Tj ET".encode()
    objs.append(b"<</Length " + str(len(stream)).encode() + b">>stream\n" + stream + b"\nendstream")
    objs.append(b"<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>")
    out = io.BytesIO()
    out.write(b"%PDF-1.4\n")
    offs: list[int] = []
    for i, body in enumerate(objs, 1):
        offs.append(out.tell())
        out.write(f"{i} 0 obj\n".encode() + body + b"\nendobj\n")
    x = out.tell()
    out.write(f"xref\n0 {len(objs) + 1}\n".encode())
    out.write(b"0000000000 65535 f \n")
    for o in offs:
        out.write(f"{o:010d} 00000 n \n".encode())
    out.write(f"trailer\n<</Size {len(objs) + 1}/Root 1 0 R>>\nstartxref\n{x}\n%%EOF".encode())
    return out.getvalue()


# --------------------------------------------------------------------------
# text extraction
# --------------------------------------------------------------------------
def t_extract_text_utf8():
    out = extract_document_text(b"def main():\n    print('hi')", file_name="app.py")
    assert "def main()" in out


def t_extract_text_log():
    out = extract_document_text(b"2026-01-01 ERROR boom\n2026-01-02 INFO ok", file_name="srv.log")
    assert "ERROR boom" in out


def t_extract_json():
    out = extract_document_text(b'{"a": 1}', file_name="cfg.json")
    assert '"a"' in out


def t_extract_bad_utf8_replaced_not_raised():
    # A stray non-UTF-8 byte must degrade to a replacement char, never hard-fail.
    out = extract_document_text(b"valid \xff\xfe tail", file_name="x.log")
    assert "valid" in out and "tail" in out


# --------------------------------------------------------------------------
# PDF extraction
# --------------------------------------------------------------------------
def t_extract_pdf():
    out = extract_document_text(_build_pdf("quarterly revenue leak"), file_name="report.pdf")
    assert "quarterly revenue leak" in out


def t_pdf_by_mime_without_ext():
    out = extract_document_text(_build_pdf("mime routed pdf"), file_name="noext", mime_type="application/pdf")
    assert "mime routed pdf" in out


# --------------------------------------------------------------------------
# guards
# --------------------------------------------------------------------------
def t_max_download_bytes_is_20mb():
    assert MAX_DOWNLOAD_BYTES == 20 * 1024 * 1024


def t_oversize_rejected():
    try:
        extract_document_text(b"a" * 100, file_name="big.txt", max_bytes=10)
        raise AssertionError("expected DocumentError for oversize")
    except DocumentError as exc:
        assert exc.payload["size"] == 100
        assert exc.fallback, "must carry a concrete fallback"


def t_unsupported_type_rejected():
    try:
        extract_document_text(b"\x89PNG\r\n\x1a\n", file_name="img.png", mime_type="image/png")
        raise AssertionError("expected DocumentError for unsupported type")
    except DocumentError as exc:
        assert "unsupported" in exc.message.lower()
        assert exc.fallback


def t_empty_rejected():
    try:
        extract_document_text(b"", file_name="empty.txt")
        raise AssertionError("expected DocumentError for empty file")
    except DocumentError:
        pass


def t_blank_text_rejected():
    try:
        extract_document_text(b"   \n\t  ", file_name="blank.txt")
        raise AssertionError("expected DocumentError for blank content")
    except DocumentError:
        pass


def t_truncated_to_max_chars():
    out = extract_document_text(b"z" * 500, file_name="t.txt", max_chars=100)
    assert "truncated" in out
    assert len(out) < 500


def t_is_supported_document():
    assert is_supported_document("a.py")
    assert is_supported_document("r.pdf")
    assert is_supported_document("notes.txt")
    assert is_supported_document("data.csv")
    assert not is_supported_document("img.png", "image/png")
    assert not is_supported_document("archive.zip")


def t_extraction_never_writes_to_disk():
    """Read-only-Docker guard: extraction must run purely in RAM (io.BytesIO).

    The container ships ``--read-only`` with only ``/tmp`` as tmpfs, so any spill
    of an uploaded document to a temp file would raise ``PermissionError:
    [Errno 30] Read-only file system``. This test patches every disk-write vector
    (``tempfile.*`` and write-mode ``open``) to blow up, then confirms both the
    text and the pypdf paths still succeed -- proving nothing touches the disk.
    """

    import builtins
    import tempfile

    # Warm the pypdf import + its .pyc cache BEFORE installing the guards, so the
    # import machinery's own (read-mode) file access and bytecode write happen now,
    # not under the patch. Once cached, `from pypdf import PdfReader` is a pure
    # sys.modules lookup with zero file I/O.
    try:
        from pypdf import PdfReader  # noqa: F401
    except ImportError:
        pass

    real_open = builtins.open
    write_calls: list[str] = []

    def guard_open(file, mode="r", *a, **k):
        if any(c in mode for c in "wax+"):
            write_calls.append(f"open({file!r}, {mode!r})")
            raise AssertionError(f"extraction tried to open for write: {file!r} mode={mode!r}")
        return real_open(file, mode, *a, **k)

    def guard_temp(*a, **k):
        write_calls.append("tempfile")
        raise AssertionError("extraction tried to create a temp file on disk")

    saved = {
        "open": builtins.open,
        "mkstemp": tempfile.mkstemp,
        "mkdtemp": tempfile.mkdtemp,
        "NamedTemporaryFile": tempfile.NamedTemporaryFile,
        "TemporaryDirectory": tempfile.TemporaryDirectory,
        "SpooledTemporaryFile": tempfile.SpooledTemporaryFile,
    }
    builtins.open = guard_open
    tempfile.mkstemp = guard_temp
    tempfile.mkdtemp = guard_temp
    tempfile.NamedTemporaryFile = guard_temp
    tempfile.TemporaryDirectory = guard_temp
    tempfile.SpooledTemporaryFile = guard_temp
    try:
        out_txt = extract_document_text(b"def f(): return 1", file_name="a.py")
        assert "def f()" in out_txt
        out_pdf = extract_document_text(_build_pdf("ram only pdf"), file_name="r.pdf")
        assert "ram only pdf" in out_pdf
    finally:
        builtins.open = saved["open"]
        tempfile.mkstemp = saved["mkstemp"]
        tempfile.mkdtemp = saved["mkdtemp"]
        tempfile.NamedTemporaryFile = saved["NamedTemporaryFile"]
        tempfile.TemporaryDirectory = saved["TemporaryDirectory"]
        tempfile.SpooledTemporaryFile = saved["SpooledTemporaryFile"]

    assert not write_calls, f"extraction touched the disk: {write_calls}"


TESTS = [
    ("extract_text_utf8", t_extract_text_utf8),
    ("extract_text_log", t_extract_text_log),
    ("extract_json", t_extract_json),
    ("extract_bad_utf8_replaced_not_raised", t_extract_bad_utf8_replaced_not_raised),
    ("extract_pdf", t_extract_pdf),
    ("pdf_by_mime_without_ext", t_pdf_by_mime_without_ext),
    ("max_download_bytes_is_20mb", t_max_download_bytes_is_20mb),
    ("oversize_rejected", t_oversize_rejected),
    ("unsupported_type_rejected", t_unsupported_type_rejected),
    ("empty_rejected", t_empty_rejected),
    ("blank_text_rejected", t_blank_text_rejected),
    ("truncated_to_max_chars", t_truncated_to_max_chars),
    ("is_supported_document", t_is_supported_document),
    ("extraction_never_writes_to_disk", t_extraction_never_writes_to_disk),
]


def main() -> int:
    print(f"\nHermes-Prime documents suite ({len(TESTS)} cases)\n" + "-" * 50)
    for name, fn in TESTS:
        check(name, fn)
    print("-" * 50)
    print(f"  {len(PASSED)} passed, {len(FAILED)} failed")
    for n, e in FAILED:
        print(f"    - {n}: {e}")
    return 1 if FAILED else 0


# pytest bridge: expose each case as a module-level test_* function.
for _name, _fn in TESTS:
    globals()[f"test_{_name}"] = _fn
del _name, _fn


if __name__ == "__main__":
    raise SystemExit(main())
