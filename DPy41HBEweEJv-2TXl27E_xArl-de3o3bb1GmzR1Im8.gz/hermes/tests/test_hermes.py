"""End-to-end + unit tests. Run: python -m pytest -q  (or)  python -m tests.test_hermes"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hermes import (  # noqa: E402
    HermesOrchestrator,
    MemoryConfig,
    RouterConfig,
    SchemaViolation,
    Settings,
    Tier,
    load_settings,
    parse_tool_args,
    validate,
)
from hermes.errors import SecurityViolation  # noqa: E402
from hermes.memory import heuristic_compression  # noqa: E402
from hermes.router import heuristic_route  # noqa: E402
from hermes.schemas import FACT_TRIPLET_SCHEMA, ROUTER_DECISION_SCHEMA  # noqa: E402
from hermes.tools import audit_python_source, sql_query  # noqa: E402
from tests.fake_transport import scripted_transport  # noqa: E402

PASSED, FAILED = [], []


def check(name, fn):
    try:
        fn()
        PASSED.append(name)
        print(f"  PASS  {name}")
    except AssertionError as e:
        FAILED.append((name, str(e)))
        print(f"  FAIL  {name}: {e}")
    except Exception as e:  # noqa: BLE001
        FAILED.append((name, f"{type(e).__name__}: {e}"))
        print(f"  ERROR {name}: {type(e).__name__}: {e}")


def _tmp_settings(**over):
    db = tempfile.mktemp(suffix=".db")
    s = Settings(
        router=RouterConfig(llm_routing_enabled=True),
        memory=MemoryConfig(db_path=db, compress_every_n_messages=4, keep_recent_messages=2),
        profiles=load_settings().profiles,
    )
    for k, v in over.items():
        setattr(s, k, v)
    return s


# ---- schema validation ----
def t_router_schema_valid():
    validate(ROUTER_DECISION_SCHEMA, {
        "tier": "tier2_deep", "confidence": 0.8, "intent": "architecture",
        "requires_tools": ["web_search"], "plan": ["step one"], "needs_memory": False, "reasoning": "x",
    }, schema_name="router")


def t_router_schema_rejects_bad_tier():
    try:
        validate(ROUTER_DECISION_SCHEMA, {
            "tier": "tier9_wrong", "confidence": 0.8, "intent": "chat",
            "requires_tools": [], "plan": [], "needs_memory": False, "reasoning": "x",
        }, schema_name="router")
        raise AssertionError("expected SchemaViolation")
    except SchemaViolation:
        pass


def t_tool_args_parse_and_reject():
    args = parse_tool_args("web_search", '{"query": "latest version", "max_results": 3}')
    assert args["query"] == "latest version"
    try:
        parse_tool_args("web_search", '{"max_results": 3}')  # missing required query
        raise AssertionError("expected SchemaViolation for missing query")
    except SchemaViolation:
        pass
    try:
        parse_tool_args("web_search", '{"query": "latest version", "bogus": 1}')  # additionalProperties
        raise AssertionError("expected SchemaViolation for extra prop")
    except SchemaViolation:
        pass


def t_triplet_schema():
    validate(FACT_TRIPLET_SCHEMA, {"subject": "a", "predicate": "b", "object": "c"}, schema_name="triplet")
    try:
        validate(FACT_TRIPLET_SCHEMA, {"subject": "a", "predicate": "b"}, schema_name="triplet")
        raise AssertionError("expected SchemaViolation")
    except SchemaViolation:
        pass


# ---- heuristic routing ----
def t_route_vision_hard_rule():
    v = heuristic_route("describe this", has_image=True, attachments=0, cfg=RouterConfig())
    assert v.tier is Tier.T3, v.tier


def t_route_heavy_context():
    big = "log line " * 40000  # ~ >100k tokens
    v = heuristic_route(big, has_image=False, attachments=0, cfg=RouterConfig())
    assert v.tier is Tier.T3, v.tier


def t_route_deep_algorithm():
    v = heuristic_route("Design a sharded, event-driven architecture with consensus", has_image=False, attachments=0, cfg=RouterConfig())
    assert v.tier is Tier.T2, v.tier


def t_route_light_chat():
    v = heuristic_route("hi there, how are you?", has_image=False, attachments=0, cfg=RouterConfig())
    assert v.tier is Tier.T1, v.tier


def t_route_research_tool():
    v = heuristic_route("search the latest release notes for the current version", has_image=False, attachments=0, cfg=RouterConfig())
    assert "web_search" in v.requires_tools, v.requires_tools


# ---- python exec guard ----
def t_guard_blocks_network():
    try:
        audit_python_source("import socket\nsocket.socket()")
        raise AssertionError("expected SecurityViolation")
    except SecurityViolation:
        pass


def t_guard_blocks_subprocess():
    try:
        audit_python_source("import subprocess")
        raise AssertionError("expected SecurityViolation")
    except SecurityViolation:
        pass


def t_guard_blocks_dunder_escape():
    try:
        audit_python_source("().__class__.__bases__[0].__subclasses__()")
        raise AssertionError("expected SecurityViolation")
    except SecurityViolation:
        pass


def t_guard_allows_math():
    audit_python_source("import math\nprint(math.sqrt(2))")


# ---- sql read-only guard ----
def t_sql_blocks_write():
    async def run():
        return await sql_query(sql="DELETE FROM messages", _db_path=":memory:")
    try:
        asyncio.run(run())
        raise AssertionError("expected SecurityViolation")
    except SecurityViolation:
        pass


def t_sql_blocks_batching():
    async def run():
        return await sql_query(sql="SELECT 1; DROP TABLE messages", _db_path=":memory:")
    try:
        asyncio.run(run())
        raise AssertionError("expected SecurityViolation")
    except SecurityViolation:
        pass


# ---- heuristic compression fallback ----
def t_heuristic_compression_valid():
    from hermes.memory import StoredMessage
    msgs = [StoredMessage(1, "user", "Hermes-Prime is an MoE router. It uses Groq for tier 1.", None, None, 10)]
    payload = heuristic_compression(msgs, max_summary_chars=1800)
    validate(
        __import__("hermes.schemas", fromlist=["TRIPLET_LIST_SCHEMA"]).TRIPLET_LIST_SCHEMA,
        payload, schema_name="compression",
    )


# ---- end-to-end orchestrator (offline) ----
def t_e2e_deep_route():
    async def run():
        s = _tmp_settings()
        async with HermesOrchestrator(s, transport=scripted_transport()) as agent:
            resp = await agent.handle("Design a distributed rate limiter architecture for a multi-tenant gateway")
        return resp
    resp = asyncio.run(run())
    assert resp.text, "empty answer"
    assert resp.tier in {"tier2_deep", "tier3_multimodal"}, resp.tier


def t_e2e_tool_call_loop():
    async def run():
        s = _tmp_settings()
        async with HermesOrchestrator(s, transport=scripted_transport()) as agent:
            resp = await agent.handle("search the web for the latest stable version and summarise")
        return resp
    resp = asyncio.run(run())
    # The scripted transport triggers a web_search tool call; it will fail (no creds)
    # but must produce a clean error envelope, never a crash.
    assert isinstance(resp.tool_results, list)


def t_e2e_memory_compression():
    async def run():
        s = _tmp_settings()
        async with HermesOrchestrator(s, transport=scripted_transport()) as agent:
            sid = None
            for i in range(6):
                resp = await agent.handle(f"architecture question {i} about sharding", session_id=sid)
                sid = resp.session_id
            triplets = agent.memory._conn.execute("SELECT COUNT(*) n FROM fact_triplets").fetchone()["n"]
            summaries = agent.memory._conn.execute("SELECT COUNT(*) n FROM summaries").fetchone()["n"]
        return triplets, summaries, sid
    triplets, summaries, sid = asyncio.run(run())
    assert summaries >= 1, f"expected compression to run, got {summaries} summaries"
    assert triplets >= 1, f"expected triplets, got {triplets}"


def t_e2e_recall():
    async def run():
        s = _tmp_settings()
        async with HermesOrchestrator(s, transport=scripted_transport()) as agent:
            sid = agent.memory.ensure_session("recall-test")
            agent.memory.commit_compression(sid, [], {"summary": "x", "triplets": []})  # no-op guard
            agent.memory._conn.execute(
                "INSERT INTO fact_triplets(session_id,subject,predicate,object,confidence,source,created_at) VALUES (?,?,?,?,?,?,?)",
                (sid, "Hermes-Prime", "is", "MoE router", 0.9, "user", 0.0),
            )
            recall = agent.memory.recall("router", session_id=sid)
        return recall
    recall = asyncio.run(run())
    assert recall["triplets"], "recall returned nothing"


def t_e2e_compression_fallback():
    """When the Tier-1 LLM compressor fails, _maybe_compress must degrade to
    heuristic_compression and STILL persist a summary + triplets (spec: concrete
    fallback, never a silent drop)."""

    from hermes.llm import LLMResult  # noqa: F401  (documentation of the seam)

    class FailingCompressor:
        """Routes + answers normally, but returns garbage for the compression call
        so extract_json raises ValueError -> heuristic fallback path."""

        def __init__(self):
            self.inner = scripted_transport()
            self.compress_calls = 0

        async def complete(self, profile, model, messages, **kw):
            system = ""
            for m in messages:
                if m.get("role") == "system":
                    system = (m.get("content") or "").lower()
                    break
            if "compress dialogue history" in system:
                self.compress_calls += 1
                # Malformed completion: no JSON object at all -> extract_json ValueError
                return {
                    "choices": [{"index": 0, "message": {"role": "assistant", "content": "sorry, I cannot compress right now"}, "finish_reason": "stop"}],
                    "usage": {"prompt_tokens": 5, "completion_tokens": 5, "total_tokens": 10},
                }
            return await self.inner.complete(profile, model, messages, **kw)

    async def run():
        s = _tmp_settings()  # compress_every_n_messages=4, keep_recent=2
        tr = FailingCompressor()
        async with HermesOrchestrator(s, transport=tr) as agent:
            sid = None
            for i in range(6):
                # Realistic dialogue with extractable S-V-O facts, so the
                # conservative extractive fallback has something to latch onto.
                resp = await agent.handle(
                    f"Hermes-Prime uses sharding pattern {i} for scale. The router requires consensus.",
                    session_id=sid,
                )
                sid = resp.session_id
            # Inspect what got persisted and by which compressor.
            row = agent.memory._conn.execute(
                "SELECT model, summary FROM summaries ORDER BY id DESC LIMIT 1"
            ).fetchone()
            trip = agent.memory._conn.execute("SELECT COUNT(*) n FROM fact_triplets").fetchone()["n"]
        return tr, row, trip

    tr, row, trip = asyncio.run(run())
    assert tr.compress_calls >= 1, "compressor was never invoked; test setup wrong"
    assert row is not None, "no summary persisted despite fallback"
    assert row["model"] == "heuristic", f"expected heuristic fallback, got model={row['model']!r}"
    assert row["summary"].startswith("[heuristic-extractive]"), row["summary"][:60]
    assert trip >= 1, "fallback must still produce triplets"


# ---- adversarial: sandbox execution + registry envelope ----
def _exec_registry():
    from hermes.config import ExecutorConfig
    from hermes.tools import ToolRegistry, make_python_exec
    cfg = ExecutorConfig(timeout_s=6, workspace_dir=tempfile.mkdtemp())
    reg = ToolRegistry()
    reg.register("python_exec", make_python_exec(cfg), timeout_s=cfg.timeout_s + 5)
    return reg


def t_exec_runs_legit_code():
    reg = _exec_registry()
    env = asyncio.run(reg.execute("python_exec", {"code": "import math; print(round(math.pi*3**2,2))"}))
    assert env["ok"] is True, env.get("error")
    assert env["data"]["exit_code"] == 0
    assert "28.27" in env["data"]["stdout"]


def t_exec_runtime_error_captured():
    reg = _exec_registry()
    env = asyncio.run(reg.execute("python_exec", {"code": "print(1/0)"}))
    assert env["ok"] is True  # the tool ran; the *program* failed
    assert env["data"]["exit_code"] != 0
    assert "ZeroDivisionError" in env["data"]["stderr"]


def t_exec_timeout_becomes_envelope():
    reg = _exec_registry()
    env = asyncio.run(reg.execute("python_exec", {"code": "while True: pass", "timeout_s": 1}))
    assert env["ok"] is False
    assert env["error"]["type"] == "ToolExecutionError"
    assert env["error"]["fallback"]


def t_exec_path_traversal_blocked():
    reg = _exec_registry()
    env = asyncio.run(reg.execute("python_exec", {"code": "print(1)", "files": [{"path": "../../etc/evil", "content": "x"}]}))
    assert env["ok"] is False
    assert env["error"]["type"] == "SecurityViolation"


def t_exec_blocked_import_via_registry():
    reg = _exec_registry()
    for src in ("import socket", "import subprocess", "().__class__.__bases__[0].__subclasses__()"):
        env = asyncio.run(reg.execute("python_exec", {"code": src}))
        assert env["ok"] is False, f"expected block for: {src}"
        assert env["error"]["type"] == "SecurityViolation"


def t_exec_secret_env_stripped():
    reg = _exec_registry()
    os.environ["HERMES_TEST_SECRET_KEY"] = "supersecret"
    try:
        env = asyncio.run(reg.execute("python_exec", {"code": "import os; print('LEAK' if os.environ.get('HERMES_TEST_SECRET_KEY') else 'CLEAN')"}))
        assert "CLEAN" in env["data"]["stdout"], "secret env var leaked into sandbox"
    finally:
        del os.environ["HERMES_TEST_SECRET_KEY"]


# ---- concurrency regression (thread-local SQLite connections) ----
def t_memory_thread_safety():
    """Hammer one MemoryStore from many threads at once.

    Guards the fix for the shared-connection bug: concurrent use of a single
    sqlite3.Connection corrupts cursor state (InterfaceError / IndexError).
    Each thread must get its own connection via threading.local.
    """
    import concurrent.futures

    from hermes.memory import MemoryStore

    db = tempfile.mktemp(suffix=".db")
    store = MemoryStore(MemoryConfig(db_path=db))
    sid = store.ensure_session("conc")
    # Seed some rows on the main thread.
    for i in range(20):
        store.add_message(sid, "user", f"message {i} about sharding and consensus")
    store.commit_compression(
        sid, [1], {"summary": "seed summary about sharding", "triplets": [
            {"subject": "system", "predicate": "uses", "object": "sharding"},
        ]}
    )

    errors: list[str] = []

    def worker(n: int) -> None:
        try:
            # Mixed reads (recall/context_block/recent) from many threads at once.
            for _ in range(25):
                store.recall("sharding consensus", top_k=5, scope="all", session_id=sid)
                store.context_block(sid)
                store.recent_messages(sid)
                store.uncompressed_count(sid)
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{type(exc).__name__}: {exc}")

    with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
        list(pool.map(worker, range(16)))

    # DB must still be structurally sound after the storm.
    integrity = store._conn.execute("PRAGMA integrity_check").fetchone()[0]
    store.close()
    for suffix in ("", "-wal", "-shm"):
        try:
            os.remove(db + suffix)
        except OSError:
            pass

    assert not errors, f"concurrent access raised {len(errors)} errors; first: {errors[0] if errors else ''}"
    assert integrity == "ok", f"DB integrity check failed: {integrity}"


def t_memory_distinct_connection_per_thread():
    """The store must hand each thread a DIFFERENT connection object."""

    import threading

    from hermes.memory import MemoryStore

    db = tempfile.mktemp(suffix=".db")
    store = MemoryStore(MemoryConfig(db_path=db))
    main_conn = store._conn
    seen: dict[str, int] = {}

    def grab():
        seen[threading.current_thread().name] = id(store._conn)

    threads = [threading.Thread(target=grab, name=f"t{i}") for i in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    store.close()
    for suffix in ("", "-wal", "-shm"):
        try:
            os.remove(db + suffix)
        except OSError:
            pass

    worker_ids = set(seen.values())
    assert len(worker_ids) == 4, f"expected 4 distinct worker connections, got {len(worker_ids)}"
    assert id(main_conn) not in worker_ids, "worker threads must not reuse the main-thread connection"


# ---- retention / disk hygiene (edge-case #4) ----
def _cleanup_db(db: str) -> None:
    for suffix in ("", "-wal", "-shm"):
        try:
            os.remove(db + suffix)
        except OSError:
            pass


def t_audit_prune_ttl():
    """audit rows older than audit_retention_days are deleted; fresh ones survive."""
    import time

    from hermes.memory import MemoryStore

    db = tempfile.mktemp(suffix=".db")
    store = MemoryStore(MemoryConfig(db_path=db, audit_retention_days=30, audit_max_rows=0))
    now = time.time()
    # Two ancient rows (45d old) + two fresh ones, inserted with explicit ts.
    for ts, step in ((now - 45 * 86400, "old1"), (now - 45 * 86400, "old2"), (now, "new1"), (now, "new2")):
        store._conn.execute("INSERT INTO audit_log(ts, step) VALUES(?,?)", (ts, step))
    deleted = store.prune_audit()
    remaining = [r["step"] for r in store._conn.execute("SELECT step FROM audit_log ORDER BY id")]
    store.close()
    _cleanup_db(db)
    assert deleted == 2, f"expected 2 TTL-expired rows deleted, got {deleted}"
    assert remaining == ["new1", "new2"], remaining


def t_audit_prune_row_cap():
    """Only the newest audit_max_rows survive regardless of age (cap=0 disables)."""
    from hermes.memory import MemoryStore

    db = tempfile.mktemp(suffix=".db")
    store = MemoryStore(MemoryConfig(db_path=db, audit_retention_days=0, audit_max_rows=5))
    for i in range(20):
        store.audit(session_id="s", step=f"step{i}")
    deleted = store.prune_audit()
    rows = [r["step"] for r in store._conn.execute("SELECT step FROM audit_log ORDER BY id")]
    store.close()
    _cleanup_db(db)
    assert deleted == 15, f"expected 15 over-cap rows deleted, got {deleted}"
    assert rows == [f"step{i}" for i in range(15, 20)], rows  # newest 5 kept


def t_maintenance_runs_and_checkpoints():
    """maintenance() prunes, runs PRAGMA optimize + wal_checkpoint(TRUNCATE), reports."""
    from hermes.memory import MemoryStore

    db = tempfile.mktemp(suffix=".db")
    store = MemoryStore(MemoryConfig(db_path=db, audit_retention_days=0, audit_max_rows=3))
    for i in range(10):
        store.audit(session_id="s", step=f"step{i}")
    report = store.maintenance()
    left = store._conn.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0]
    # DB must still be structurally sound after the checkpoint.
    integrity = store._conn.execute("PRAGMA integrity_check").fetchone()[0]
    store.close()
    _cleanup_db(db)
    assert report["audit_rows_pruned"] == 7, report
    assert left == 3, left
    assert isinstance(report["wal_checkpoint"], list), report
    assert integrity == "ok", integrity


# ---- adversarial: SSRF + SQL guard ----
def t_ssrf_metadata_blocked():
    import aiohttp

    from hermes.tools import web_fetch
    async def run():
        async with aiohttp.ClientSession() as s:
            for url in ("http://169.254.169.254/latest/meta-data/", "http://127.0.0.1:8080/", "http://localhost/admin"):
                try:
                    await web_fetch(s, url=url)
                    return f"NOT BLOCKED: {url}"
                except SecurityViolation:
                    continue
        return "ok"
    assert asyncio.run(run()) == "ok"


def t_sql_comment_obfuscation_harmless():
    # The comment is stripped, leaving a harmless SELECT — the DROP must not run.
    async def run():
        await sql_query(sql="SELECT 1 AS x /* ; DROP TABLE messages */", _db_path=":memory:")
    asyncio.run(run())  # must not raise, must not execute the DROP


def t_sql_blocked_keyword_in_select():
    async def run():
        # 'create' as a write keyword must be rejected even inside a SELECT prefix
        return await sql_query(sql="SELECT * FROM x; CREATE TABLE y(z int)", _db_path=":memory:")
    try:
        asyncio.run(run())
        raise AssertionError("expected SecurityViolation for batched CREATE")
    except SecurityViolation:
        pass


def t_missing_credential_error_is_hermes_error():
    # Regression: MissingCredentialError used to be a bare RuntimeError defined
    # in config.py, shadowed by an unused HermesError subclass in errors.py.
    # The CLI's `except HermesError` handler therefore never caught the
    # missing-key case and dumped a raw traceback to the user. It must now be a
    # single HermesError subclass, importable from both paths, and raised by
    # ModelProfile.api_key with a concrete fallback (spec requirement).
    from hermes import MissingCredentialError as FromPkg
    from hermes.config import ModelProfile
    from hermes.errors import HermesError
    from hermes.errors import MissingCredentialError as FromErrors

    assert FromPkg is FromErrors, "must be one class, exported from both paths"
    assert issubclass(FromPkg, HermesError), "must subclass HermesError so the CLI catches it"

    os.environ.pop("HERMES_TEST_ABSENT_KEY", None)
    profile = ModelProfile(
        tier=Tier.T1,
        provider="groq",
        model="m",
        base_url="https://example.invalid/v1/chat/completions",
        api_key_env="HERMES_TEST_ABSENT_KEY",
    )
    try:
        _ = profile.api_key
        raise AssertionError("expected MissingCredentialError for absent key")
    except FromPkg as exc:
        assert "HERMES_TEST_ABSENT_KEY" in exc.message
        assert exc.payload == {"env_var": "HERMES_TEST_ABSENT_KEY"}
        assert exc.fallback, "must carry a concrete fallback"
        assert isinstance(exc, HermesError)


# ---- budget cap / spend ledger ----
def _budget_settings(db: str, budget: int) -> Settings:
    return Settings(
        router=RouterConfig(llm_routing_enabled=True),
        memory=MemoryConfig(db_path=db, daily_token_budget=budget),
        profiles=load_settings().profiles,
    )


def t_record_spend_and_daily_tokens():
    """record_spend accumulates; daily_tokens sums today and filters by day."""
    from hermes.memory import MemoryStore

    db = tempfile.mktemp(suffix=".db")
    store = MemoryStore(MemoryConfig(db_path=db))
    try:
        assert store.daily_tokens() == 0
        store.record_spend(session_id="s", tier="tier1_planning", model="m", tokens_in=100, tokens_out=50)
        store.record_spend(session_id="s", tier="tier2_deep", model="m", tokens_in=200, tokens_out=0)
        assert store.daily_tokens() == 350
        today = store._utc_day()
        assert store.daily_tokens(today) == 350
        assert store.daily_tokens("1999-01-01") == 0
    finally:
        store.close()
        _cleanup_db(db)


def t_budget_degrades_to_tier1():
    """Once today's tokens cross the cap, routing degrades to the cheapest tier."""

    async def run():
        db = tempfile.mktemp(suffix=".db")
        s = _budget_settings(db, budget=100)
        try:
            async with HermesOrchestrator(s, transport=scripted_transport()) as agent:
                # Pre-fill the ledger past the 100-token cap.
                agent.memory.record_spend(session_id="x", tier="tier2_deep", model="m", tokens_in=200, tokens_out=0)
                resp = await agent.handle(
                    "Design a distributed rate limiter architecture for a multi-tenant gateway"
                )
            return resp
        finally:
            _cleanup_db(db)

    resp = asyncio.run(run())
    # The scripted router would pick tier2_deep; the budget guard must force T1.
    assert resp.tier == "tier1_planning", resp.tier


def t_budget_large_request_refused():
    """Budget exhausted + request too large for Tier-1 => fail fast with
    BudgetExceededError (zero LLM calls, zero tokens spent) instead of degrading
    an oversized payload that would overflow Groq's context window."""
    from hermes.errors import BudgetExceededError

    async def run():
        db = tempfile.mktemp(suffix=".db")
        # tier1_context_tokens tiny so the test payload deterministically exceeds it.
        s = Settings(
            router=RouterConfig(llm_routing_enabled=True, tier1_context_tokens=50),
            memory=MemoryConfig(db_path=db, daily_token_budget=100),
            profiles=load_settings().profiles,
        )
        tr = scripted_transport()
        try:
            async with HermesOrchestrator(s, transport=tr) as agent:
                agent.memory.record_spend(session_id="x", tier="tier2_deep", model="m", tokens_in=200, tokens_out=0)
                big = "Analyze this huge document. " * 200  # ~1.5k est. tokens >> 50 cap
                try:
                    await agent.handle(big, force_tier=Tier.T3)
                    exc = None
                except BudgetExceededError as e:
                    exc = e
            return exc, tr.calls
        finally:
            _cleanup_db(db)

    exc, calls = asyncio.run(run())
    assert exc is not None, "expected BudgetExceededError for an oversized request under budget"
    assert exc.payload["tier1_context_tokens"] == 50
    assert exc.payload["estimated_tokens"] > 50
    assert exc.fallback, "must carry a concrete fallback"
    # Fail-fast must happen BEFORE any router/completion call: force_tier skips the
    # router and the guard raises before the loop, so the LLM is never touched.
    assert calls == [], f"fail-fast must not touch any LLM, but calls={calls}"


def t_budget_disabled_when_zero():
    """budget=0 disables the guard: a deep request is NOT degraded."""

    async def run():
        db = tempfile.mktemp(suffix=".db")
        s = _budget_settings(db, budget=0)
        try:
            async with HermesOrchestrator(s, transport=scripted_transport()) as agent:
                agent.memory.record_spend(session_id="x", tier="tier2_deep", model="m", tokens_in=10**9, tokens_out=0)
                resp = await agent.handle(
                    "Design a distributed rate limiter architecture for a multi-tenant gateway"
                )
            return resp
        finally:
            _cleanup_db(db)

    resp = asyncio.run(run())
    assert resp.tier == "tier2_deep", resp.tier


def t_spend_recorded_after_handle():
    """handle() writes the request's tokens to the ledger exactly once."""

    async def run():
        db = tempfile.mktemp(suffix=".db")
        s = _budget_settings(db, budget=0)
        try:
            async with HermesOrchestrator(s, transport=scripted_transport()) as agent:
                before = agent.memory.daily_tokens()
                resp = await agent.handle("Design a distributed rate limiter architecture")
                after = agent.memory.daily_tokens()
            return before, after, resp
        finally:
            _cleanup_db(db)

    before, after, resp = asyncio.run(run())
    assert before == 0
    assert after == resp.usage["prompt_tokens"] + resp.usage["completion_tokens"], (after, resp.usage)
    assert after > 0


def t_budget_limited_blocks_escalation():
    """When budget-limited, a failing T1 call must NOT climb to T2/T3."""
    from hermes.errors import LLMError

    class FailT1Transport:
        def __init__(self) -> None:
            self.calls: list[str] = []

        async def complete(self, profile, model, messages, *, tools, json_mode, max_tokens, temperature, timeout_s):
            self.calls.append(profile.tier.value)
            system = next((m.get("content", "") for m in messages if m.get("role") == "system"), "")
            if "router" in system.lower() and "classify" in system.lower():
                import json as _json

                return _chat_json(
                    _json.dumps(
                        {
                            "tier": "tier1_planning",
                            "confidence": 0.9,
                            "intent": "chat",
                            "requires_tools": [],
                            "plan": [],
                            "needs_memory": False,
                            "reasoning": "light",
                        }
                    )
                )
            # Any real completion fails, forcing the escalation path.
            raise LLMError("upstream 500", status=500, payload={"tier": profile.tier.value})

    def _chat_json(content: str) -> dict:
        return {
            "id": "x",
            "model": "fake",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": content}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        }

    async def run():
        db = tempfile.mktemp(suffix=".db")
        s = _budget_settings(db, budget=10)
        tr = FailT1Transport()
        try:
            async with HermesOrchestrator(s, transport=tr) as agent:
                agent.memory.record_spend(session_id="x", tier="tier1_planning", model="m", tokens_in=999, tokens_out=0)
                resp = await agent.handle("hello there")
            return resp, tr.calls
        finally:
            _cleanup_db(db)

    resp, calls = asyncio.run(run())
    # Budget-limited => routed to T1 and pinned there; no tier2/tier3 completion attempts.
    assert resp.tier == "tier1_planning", resp.tier
    assert not any(c in {"tier2_deep", "tier3_multimodal"} for c in calls), calls


def t_maintenance_prunes_spend():
    """maintenance() drops spend rows older than the retention TTL, keeps today's."""
    import time

    from hermes.memory import MemoryStore

    db = tempfile.mktemp(suffix=".db")
    store = MemoryStore(MemoryConfig(db_path=db, audit_retention_days=30, audit_max_rows=0))
    try:
        old_ts = time.time() - 40 * 86_400
        old_day = store._utc_day(old_ts)
        store._conn.execute(
            "INSERT INTO spend_ledger(day, ts, session_id, tier, model, tokens_in, tokens_out) VALUES (?,?,?,?,?,?,?)",
            (old_day, old_ts, "s", "tier1_planning", "m", 10, 5),
        )
        store.record_spend(session_id="s", tier="tier1_planning", model="m", tokens_in=1, tokens_out=1)
        report = store.maintenance()
        assert report["spend_rows_pruned"] == 1, report
        assert store.daily_tokens() == 2  # only today's row survives
    finally:
        store.close()
        _cleanup_db(db)


TESTS = [
    ("router_schema_valid", t_router_schema_valid),
    ("router_schema_rejects_bad_tier", t_router_schema_rejects_bad_tier),
    ("tool_args_parse_and_reject", t_tool_args_parse_and_reject),
    ("triplet_schema", t_triplet_schema),
    ("route_vision_hard_rule", t_route_vision_hard_rule),
    ("route_heavy_context", t_route_heavy_context),
    ("route_deep_algorithm", t_route_deep_algorithm),
    ("route_light_chat", t_route_light_chat),
    ("route_research_tool", t_route_research_tool),
    ("guard_blocks_network", t_guard_blocks_network),
    ("guard_blocks_subprocess", t_guard_blocks_subprocess),
    ("guard_blocks_dunder_escape", t_guard_blocks_dunder_escape),
    ("guard_allows_math", t_guard_allows_math),
    ("sql_blocks_write", t_sql_blocks_write),
    ("sql_blocks_batching", t_sql_blocks_batching),
    ("heuristic_compression_valid", t_heuristic_compression_valid),
    ("e2e_deep_route", t_e2e_deep_route),
    ("e2e_tool_call_loop", t_e2e_tool_call_loop),
    ("e2e_memory_compression", t_e2e_memory_compression),
    ("e2e_recall", t_e2e_recall),
    ("e2e_compression_fallback", t_e2e_compression_fallback),
    ("exec_runs_legit_code", t_exec_runs_legit_code),
    ("exec_runtime_error_captured", t_exec_runtime_error_captured),
    ("exec_timeout_becomes_envelope", t_exec_timeout_becomes_envelope),
    ("exec_path_traversal_blocked", t_exec_path_traversal_blocked),
    ("exec_blocked_import_via_registry", t_exec_blocked_import_via_registry),
    ("exec_secret_env_stripped", t_exec_secret_env_stripped),
    ("memory_thread_safety", t_memory_thread_safety),
    ("memory_distinct_connection_per_thread", t_memory_distinct_connection_per_thread),
    ("audit_prune_ttl", t_audit_prune_ttl),
    ("audit_prune_row_cap", t_audit_prune_row_cap),
    ("maintenance_runs_and_checkpoints", t_maintenance_runs_and_checkpoints),
    ("record_spend_and_daily_tokens", t_record_spend_and_daily_tokens),
    ("budget_degrades_to_tier1", t_budget_degrades_to_tier1),
    ("budget_large_request_refused", t_budget_large_request_refused),
    ("budget_disabled_when_zero", t_budget_disabled_when_zero),
    ("spend_recorded_after_handle", t_spend_recorded_after_handle),
    ("budget_limited_blocks_escalation", t_budget_limited_blocks_escalation),
    ("maintenance_prunes_spend", t_maintenance_prunes_spend),
    ("ssrf_metadata_blocked", t_ssrf_metadata_blocked),
    ("sql_comment_obfuscation_harmless", t_sql_comment_obfuscation_harmless),
    ("sql_blocked_keyword_in_select", t_sql_blocked_keyword_in_select),
    ("missing_credential_error_is_hermes_error", t_missing_credential_error_is_hermes_error),
]


def main() -> int:
    print(f"\nHermes-Prime test suite ({len(TESTS)} cases)\n" + "-" * 50)
    for name, fn in TESTS:
        check(name, fn)
    print("-" * 50)
    print(f"  {len(PASSED)} passed, {len(FAILED)} failed")
    if FAILED:
        for n, e in FAILED:
            print(f"    - {n}: {e}")
        return 1
    return 0


# ---------------------------------------------------------------------------
# pytest bridge: expose each case as a module-level `test_*` function so that
# `pytest` collects them. The custom runner above and pytest share one source
# of truth (the TESTS list). The t_* cases are synchronous and take no args,
# so they are aliased directly (they raise AssertionError on failure).
# ---------------------------------------------------------------------------
for _name, _fn in TESTS:
    globals()[f"test_{_name}"] = _fn
del _name, _fn


if __name__ == "__main__":
    raise SystemExit(main())
