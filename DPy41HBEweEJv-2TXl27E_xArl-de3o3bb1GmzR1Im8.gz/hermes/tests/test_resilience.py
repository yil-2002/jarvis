"""Resilience-layer tests: retries, circuit breaker, model failover, tier escalation, JSON extraction.

These exercise the paths FakeTransport never touches — i.e. what happens when the
upstream LLM providers misbehave. This is the robustness core the spec demands
("log the exact error payload and suggest a concrete fallback").

Run: python -m tests.test_resilience   (or)   python -m pytest tests/test_resilience.py -q
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import aiohttp  # noqa: E402

from hermes.config import (  # noqa: E402
    MemoryConfig,
    ModelProfile,
    RetryPolicy,
    RouterConfig,
    Settings,
    Tier,
    load_settings,
)
from hermes.errors import LLMError  # noqa: E402
from hermes.llm import LLMClient, _CircuitBreaker, extract_json  # noqa: E402
from hermes.orchestrator import HermesOrchestrator, _next_tier  # noqa: E402
from tests.fake_transport import scripted_transport  # noqa: E402

PASSED, FAILED = [], []


def check(name, fn):
    try:
        fn()
        PASSED.append(name)
        print(f"  PASS  {name}")
    except AssertionError as e:
        FAILED.append((name, str(e)))
        print(f"  FAIL  {name}: {e}")
    except Exception as e:  # noqa: BLE001
        FAILED.append((name, f"{type(e).__name__}: {e}"))
        print(f"  ERROR {name}: {type(e).__name__}: {e}")


# --------------------------------------------------------------------------
# A programmable transport that can fail on demand.
# --------------------------------------------------------------------------
def _ok(text="ok", *, tool_calls=None):
    msg = {"role": "assistant", "content": text}
    if tool_calls:
        msg["tool_calls"] = tool_calls
    return {
        "choices": [{"index": 0, "message": msg, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
    }


class FlakyTransport:
    """Fails according to a per-(model) call schedule, then optionally succeeds.

    `plan[model]` is a list of outcomes consumed one per call:
      - an Exception instance -> raised
      - a dict                -> returned as the provider response
    When the list is exhausted, the last outcome repeats.
    """

    def __init__(self, plan: dict[str, list]):
        self.plan = plan
        self.calls: list[str] = []          # model ids in call order
        self.call_times: list[float] = []   # monotonic timestamps (for backoff checks)

    async def complete(self, profile, model, messages, *, tools, json_mode, max_tokens, temperature, timeout_s):
        import time

        self.calls.append(model)
        self.call_times.append(time.monotonic())
        outcomes = self.plan.get(model, [_ok()])
        idx = min(len([c for c in self.calls if c == model]) - 1, len(outcomes) - 1)
        outcome = outcomes[idx]
        if isinstance(outcome, Exception):
            raise outcome
        return outcome


def _fast_retry(attempts=3, base=0.001):
    """Near-zero-delay retry policy so tests don't actually sleep."""

    return RetryPolicy(attempts=attempts, base_delay_s=base, max_delay_s=base * 2, backoff_factor=2.0, jitter=0.0)


def _profile(model="m1", failover=(), retry=None, tier=Tier.T2):
    return ModelProfile(
        tier=tier,
        provider="test",
        model=model,
        base_url="http://localhost:9/v1",
        api_key_env="TEST_KEY_UNUSED",
        max_output_tokens=256,
        timeout_s=5.0,
        retry=retry or _fast_retry(),
        failover=failover,
    )


def _client(transport, profiles=None, breaker=None):
    profiles = profiles or {Tier.T2: _profile()}
    return LLMClient(profiles, transport=transport, breaker=breaker)


def _retryable(msg="rate limited", status=429):
    return LLMError(message=msg, status=status, payload={"detail": msg}, retryable=True)


def _fatal(msg="bad request", status=400):
    return LLMError(message=msg, status=status, payload={"detail": msg}, retryable=False)


# --------------------------------------------------------------------------
# retry / backoff
# --------------------------------------------------------------------------
def t_retry_recovers_after_transient_failures():
    tr = FlakyTransport({"m1": [_retryable(), _retryable(), _ok("recovered")]})
    client = _client(tr)
    res = asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
    assert res.text == "recovered", res.text
    assert res.attempts == 3, f"expected 3 attempts, got {res.attempts}"
    assert tr.calls == ["m1", "m1", "m1"], tr.calls


def t_retry_exhausts_then_raises():
    tr = FlakyTransport({"m1": [_retryable()]})  # always fails
    client = _client(tr, profiles={Tier.T2: _profile(retry=_fast_retry(attempts=3))})
    try:
        asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
        raise AssertionError("expected LLMError after exhausting retries")
    except LLMError as e:
        # All candidates exhausted (single model, no failover) -> wrapped error.
        assert "exhausted" in e.message.lower() or e.status == 429, e.message
    assert len(tr.calls) == 3, f"expected 3 attempts, got {len(tr.calls)}"


def t_non_retryable_fails_fast():
    tr = FlakyTransport({"m1": [_fatal()]})  # 400 -> not retryable
    client = _client(tr, profiles={Tier.T2: _profile(retry=_fast_retry(attempts=5))})
    try:
        asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
        raise AssertionError("expected LLMError")
    except LLMError:
        pass
    assert len(tr.calls) == 1, f"non-retryable error must not retry; got {len(tr.calls)} calls"


def t_backoff_actually_delays():
    # With a real (tiny) base delay and jitter=0, successive retries must be spaced.
    tr = FlakyTransport({"m1": [_retryable(), _retryable(), _ok()]})
    policy = RetryPolicy(attempts=3, base_delay_s=0.02, max_delay_s=1.0, backoff_factor=2.0, jitter=0.0)
    client = _client(tr, profiles={Tier.T2: _profile(retry=policy)})
    asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
    gap1 = tr.call_times[1] - tr.call_times[0]
    gap2 = tr.call_times[2] - tr.call_times[1]
    assert gap1 >= 0.015, f"first backoff too small: {gap1}"
    assert gap2 > gap1, f"backoff must grow: gap1={gap1} gap2={gap2}"


def t_timeout_becomes_llmtimeouterror():
    class TimeoutTransport:
        def __init__(self):
            self.n = 0

        async def complete(self, *a, **k):
            self.n += 1
            raise TimeoutError("simulated")

    tr = TimeoutTransport()
    client = _client(tr, profiles={Tier.T2: _profile(retry=_fast_retry(attempts=2))})
    try:
        asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
        raise AssertionError("expected LLMError/LLMTimeoutError")
    except LLMError:
        pass  # LLMTimeoutError is a subclass; wrapped-or-direct both acceptable
    assert tr.n == 2, f"expected 2 attempts before giving up, got {tr.n}"


def t_client_error_becomes_non_retryable():
    class ConnErrTransport:
        def __init__(self):
            self.n = 0

        async def complete(self, *a, **k):
            self.n += 1
            # ClientConnectionError is a ClientError subclass that constructs cleanly
            # (ClientConnectorError requires a real connection_key in its ctor).
            raise aiohttp.ClientConnectionError("connection refused")

    tr = ConnErrTransport()
    client = _client(tr, profiles={Tier.T2: _profile(retry=_fast_retry(attempts=3))})
    try:
        asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
        raise AssertionError("expected LLMError")
    except LLMError as e:
        assert e.retryable is False
    assert tr.n == 3, tr.n


# --------------------------------------------------------------------------
# model failover
# --------------------------------------------------------------------------
def t_failover_to_second_model():
    tr = FlakyTransport({"m1": [_retryable()], "m2": [_ok("from m2")]})
    prof = _profile(model="m1", failover=("m2",), retry=_fast_retry(attempts=1))
    client = _client(tr, profiles={Tier.T2: prof})
    res = asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
    assert res.text == "from m2", res.text
    assert res.model == "m2", res.model
    assert tr.calls == ["m1", "m2"], tr.calls


def test_failover_chain_exhausts_all():
    tr = FlakyTransport({"m1": [_retryable()], "m2": [_retryable()], "m3": [_retryable()]})
    prof = _profile(model="m1", failover=("m2", "m3"), retry=_fast_retry(attempts=1))
    client = _client(tr, profiles={Tier.T2: prof})
    try:
        asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
        raise AssertionError("expected exhaustion LLMError")
    except LLMError as e:
        assert "exhausted" in e.message.lower()
        assert e.payload["tried"] == ["m1", "m2", "m3"], e.payload
    assert tr.calls == ["m1", "m2", "m3"], tr.calls


def test_failover_error_payload_preserved():
    # The spec: "log the exact error payload". The final error must carry upstream detail.
    tr = FlakyTransport({"m1": [LLMError(message="upstream boom", status=503, payload={"provider": "x", "raw": "oops"}, retryable=True)]})
    prof = _profile(model="m1", retry=_fast_retry(attempts=1))
    client = _client(tr, profiles={Tier.T2: prof})
    try:
        asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
        raise AssertionError("expected LLMError")
    except LLMError as e:
        assert e.payload["last_payload"] == {"provider": "x", "raw": "oops"}, e.payload
        assert e.fallback, "error must carry a concrete fallback string"


# --------------------------------------------------------------------------
# circuit breaker
# --------------------------------------------------------------------------
def test_breaker_trips_after_threshold():
    b = _CircuitBreaker(failure_threshold=3, cooldown_s=100)
    key = "t:m1"
    assert b.allow(key) is True
    b.record_failure(key)
    b.record_failure(key)
    assert b.allow(key) is True, "must stay closed below threshold"
    b.record_failure(key)
    assert b.allow(key) is False, "must open at threshold"


def test_breaker_half_opens_after_cooldown():
    b = _CircuitBreaker(failure_threshold=1, cooldown_s=0.01)
    key = "t:m1"
    b.record_failure(key)
    assert b.allow(key) is False
    import time as _t

    _t.sleep(0.02)
    assert b.allow(key) is True, "must half-open after cooldown"


def test_breaker_success_resets():
    b = _CircuitBreaker(failure_threshold=2, cooldown_s=100)
    key = "t:m1"
    b.record_failure(key)
    b.record_success(key)
    b.record_failure(key)
    assert b.allow(key) is True, "success must reset the failure count"


def test_breaker_skips_open_model_in_failover():
    # m1's circuit is open -> client must skip straight to m2 without calling m1.
    b = _CircuitBreaker(failure_threshold=1, cooldown_s=100)
    b.record_failure(f"{Tier.T2.value}:m1")
    tr = FlakyTransport({"m1": [_ok("SHOULD NOT BE CALLED")], "m2": [_ok("from m2")]})
    prof = _profile(model="m1", failover=("m2",))
    client = _client(tr, profiles={Tier.T2: prof}, breaker=b)
    res = asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
    assert res.text == "from m2"
    assert "m1" not in tr.calls, f"open circuit must skip m1; calls={tr.calls}"


def test_breaker_all_open_raises():
    b = _CircuitBreaker(failure_threshold=1, cooldown_s=100)
    b.record_failure(f"{Tier.T2.value}:m1")
    tr = FlakyTransport({"m1": [_ok()]})
    client = _client(tr, profiles={Tier.T2: _profile(model="m1")}, breaker=b)
    try:
        asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
        raise AssertionError("expected exhaustion when all circuits open")
    except LLMError as e:
        assert "exhausted" in e.message.lower()
    assert tr.calls == [], "no model should be called when its circuit is open"


# --------------------------------------------------------------------------
# response normalisation
# --------------------------------------------------------------------------
def test_normalise_no_choices_is_retryable_error():
    tr = FlakyTransport({"m1": [{"choices": []}]})  # malformed but HTTP 200
    client = _client(tr, profiles={Tier.T2: _profile(retry=_fast_retry(attempts=1))})
    try:
        asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
        raise AssertionError("expected LLMError for empty choices")
    except LLMError:
        pass


def test_normalise_captures_invalid_tool_args():
    bad = _ok("", tool_calls=[{"id": "c1", "type": "function",
                               "function": {"name": "web_search", "arguments": "{not json"}}])
    tr = FlakyTransport({"m1": [bad]})
    client = _client(tr, profiles={Tier.T2: _profile()})
    res = asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
    assert res.wants_tools
    assert res.tool_calls[0]["argument_error"], "invalid args must be flagged, not crash"


def test_normalise_parses_valid_tool_args():
    good = _ok("", tool_calls=[{"id": "c1", "type": "function",
                                "function": {"name": "web_search", "arguments": json.dumps({"query": "latest news"})}}])
    tr = FlakyTransport({"m1": [good]})
    client = _client(tr, profiles={Tier.T2: _profile()})
    res = asyncio.run(client.complete(Tier.T2, [{"role": "user", "content": "hi"}]))
    assert res.tool_calls[0]["arguments"] == {"query": "latest news"}
    assert res.tool_calls[0]["argument_error"] is None


# --------------------------------------------------------------------------
# extract_json
# --------------------------------------------------------------------------
def test_extract_json_plain():
    assert extract_json('{"a": 1}') == {"a": 1}


def test_extract_json_fenced():
    assert extract_json('```json\n{"a": 1}\n```') == {"a": 1}
    assert extract_json('```\n{"a": 2}\n```') == {"a": 2}


def test_extract_json_in_prose():
    assert extract_json('Sure! Here you go: {"tier": "x"} hope that helps') == {"tier": "x"}


def test_extract_json_array():
    assert extract_json("blah [1, 2, 3] blah") == [1, 2, 3]


def test_extract_json_empty_raises():
    try:
        extract_json("")
        raise AssertionError("expected ValueError")
    except ValueError:
        pass


def test_extract_json_garbage_raises():
    try:
        extract_json("no json here at all")
        raise AssertionError("expected ValueError")
    except ValueError:
        pass


# --------------------------------------------------------------------------
# tier escalation (orchestrator level)
# --------------------------------------------------------------------------
def test_next_tier_mapping():
    assert _next_tier(Tier.T1) is Tier.T2
    assert _next_tier(Tier.T2) is Tier.T3
    assert _next_tier(Tier.T3) is Tier.T3, "T3 is terminal"


def test_orchestrator_escalates_on_upstream_failure():
    """When the routed tier's model fails hard, the orchestrator must escalate."""

    class EscalateTransport:
        """T1 (routing) works; T2 always fails; T3 succeeds."""

        def __init__(self):
            self.inner = scripted_transport()
            self.t2_calls = 0

        async def complete(self, profile, model, messages, **kw):
            if profile.tier is Tier.T2:
                self.t2_calls += 1
                raise LLMError(message="T2 down", status=503, payload={"m": model}, retryable=False)
            if profile.tier is Tier.T3:
                return _ok("answered by tier3")
            return await self.inner.complete(profile, model, messages, **kw)

    async def run():
        os.environ["HERMES_DB_PATH"] = tempfile.mktemp(suffix=".db")
        s = Settings(
            router=RouterConfig(llm_routing_enabled=True, max_agent_steps=6),
            memory=MemoryConfig(db_path=os.environ["HERMES_DB_PATH"]),
            profiles=load_settings().profiles,
        )
        tr = EscalateTransport()
        async with HermesOrchestrator(s, transport=tr) as agent:
            resp = await agent.handle("Design a sharded event-driven architecture with consensus")
        return resp, tr

    resp, tr = asyncio.run(run())
    assert resp.tier == Tier.T3.value, f"expected escalation to T3, stayed at {resp.tier}"
    assert "tier3" in resp.text.lower(), resp.text
    assert tr.t2_calls >= 1, "T2 should have been attempted before escalating"


TESTS = [
    ("retry_recovers_after_transient_failures", t_retry_recovers_after_transient_failures),
    ("retry_exhausts_then_raises", t_retry_exhausts_then_raises),
    ("non_retryable_fails_fast", t_non_retryable_fails_fast),
    ("backoff_actually_delays", t_backoff_actually_delays),
    ("timeout_becomes_llmtimeouterror", t_timeout_becomes_llmtimeouterror),
    ("client_error_becomes_non_retryable", t_client_error_becomes_non_retryable),
    ("failover_to_second_model", t_failover_to_second_model),
    ("failover_chain_exhausts_all", test_failover_chain_exhausts_all),
    ("failover_error_payload_preserved", test_failover_error_payload_preserved),
    ("breaker_trips_after_threshold", test_breaker_trips_after_threshold),
    ("breaker_half_opens_after_cooldown", test_breaker_half_opens_after_cooldown),
    ("breaker_success_resets", test_breaker_success_resets),
    ("breaker_skips_open_model_in_failover", test_breaker_skips_open_model_in_failover),
    ("breaker_all_open_raises", test_breaker_all_open_raises),
    ("normalise_no_choices_is_retryable_error", test_normalise_no_choices_is_retryable_error),
    ("normalise_captures_invalid_tool_args", test_normalise_captures_invalid_tool_args),
    ("normalise_parses_valid_tool_args", test_normalise_parses_valid_tool_args),
    ("extract_json_plain", test_extract_json_plain),
    ("extract_json_fenced", test_extract_json_fenced),
    ("extract_json_in_prose", test_extract_json_in_prose),
    ("extract_json_array", test_extract_json_array),
    ("extract_json_empty_raises", test_extract_json_empty_raises),
    ("extract_json_garbage_raises", test_extract_json_garbage_raises),
    ("next_tier_mapping", test_next_tier_mapping),
    ("orchestrator_escalates_on_upstream_failure", test_orchestrator_escalates_on_upstream_failure),
]


def main() -> int:
    print(f"\nHermes-Prime resilience suite ({len(TESTS)} cases)\n" + "-" * 50)
    for name, fn in TESTS:
        check(name, fn)
    print("-" * 50)
    print(f"  {len(PASSED)} passed, {len(FAILED)} failed")
    for n, e in FAILED:
        print(f"    - {n}: {e}")
    return 1 if FAILED else 0


# pytest bridge (shared source of truth with the custom runner above).
for _name, _fn in TESTS:
    if _name.startswith(("test_",)):
        globals()[_name] = _fn
    else:
        globals()[f"test_{_name}"] = _fn
del _name, _fn


if __name__ == "__main__":
    raise SystemExit(main())
