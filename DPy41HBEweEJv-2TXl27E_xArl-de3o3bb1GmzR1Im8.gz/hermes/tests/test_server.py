"""HTTP service tests: every endpoint, validation path, and CORS via aiohttp test client.

Run: python -m tests.test_server   (or)   python -m pytest tests/test_server.py -q
"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from aiohttp.test_utils import TestClient, TestServer  # noqa: E402

from server import _AGENT_KEY, create_app  # noqa: E402
from tests.fake_transport import scripted_transport  # noqa: E402

PASSED, FAILED = [], []


def _run_case(coro_fn):
    """Isolated per-case setup: fresh DB + app + test client. Raises on failure."""

    async def _runner():
        os.environ["HERMES_DB_PATH"] = tempfile.mktemp(suffix=".db")
        # Optional per-case env overrides (e.g. budget caps) must be applied BEFORE
        # create_app, because load_settings() reads the environment at build time.
        # Declared as a `_env` dict attribute on the case fn; defaults to {} so every
        # existing case is unaffected. Prior values are restored in `finally`.
        extra_env = getattr(coro_fn, "_env", {})
        saved = {k: os.environ.get(k) for k in extra_env}
        os.environ.update(extra_env)
        try:
            app = create_app(transport=scripted_transport())
            async with TestClient(TestServer(app)) as client:
                await coro_fn(client)
        finally:
            for k, prev in saved.items():
                if prev is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = prev
            for suffix in ("", "-wal", "-shm"):
                try:
                    os.remove(os.environ["HERMES_DB_PATH"] + suffix)
                except OSError:
                    pass

    asyncio.run(_runner())


def check(name, coro_fn):
    try:
        _run_case(coro_fn)
        PASSED.append(name)
        print(f"  PASS  {name}")
    except AssertionError as e:
        FAILED.append((name, str(e)))
        print(f"  FAIL  {name}: {e}")
    except Exception as e:  # noqa: BLE001
        FAILED.append((name, f"{type(e).__name__}: {e}"))
        print(f"  ERROR {name}: {type(e).__name__}: {e}")



# ---- happy paths ----
async def t_index(client):
    r = await client.get("/")
    assert r.status == 200
    assert r.headers["Content-Type"].startswith("text/html")
    body = await r.text()
    assert "JARVIS" in body and "/v1/chat" in body


async def t_healthz(client):
    r = await client.get("/healthz")
    assert r.status == 200
    d = await r.json()
    assert d["ok"] is True and d["service"] == "hermes-prime"


async def t_readyz(client):
    r = await client.get("/readyz")
    d = await r.json()
    assert d["checks"]["db"] == "ok"
    # No real keys in the test env -> tier keys report missing, but DB ok keeps it 200.
    assert r.status in (200, 503)


async def t_metrics(client):
    r = await client.get("/metrics")
    assert r.status == 200
    assert r.headers["Content-Type"].startswith("text/plain")
    body = await r.text()
    assert "hermes_audit_events_total" in body


async def t_models(client):
    r = await client.get("/v1/models")
    d = await r.json()
    assert d["ok"] is True
    tiers = {t["tier"] for t in d["tiers"]}
    assert tiers == {"tier1_planning", "tier2_deep", "tier3_multimodal"}
    assert "python_exec" in d["tools"]


async def t_route_dry_run(client):
    r = await client.post("/v1/route", json={"message": "Design a sharded event-driven architecture with consensus"})
    assert r.status == 200
    d = await r.json()
    assert d["ok"] is True
    assert d["decision"]["tier"] in {"tier1_planning", "tier2_deep", "tier3_multimodal"}


async def t_chat_full(client):
    r = await client.post("/v1/chat", json={"message": "Design a distributed rate limiter", "session_id": "srv1"})
    assert r.status == 200
    d = await r.json()
    assert d["ok"] is True
    assert d["answer"]
    assert d["session_id"] == "srv1"
    assert "steps" in d and "usage" in d


# ---- validation / error paths ----
async def t_chat_missing_message(client):
    r = await client.post("/v1/chat", json={})
    assert r.status == 422
    assert (await r.json())["error"]["code"] == "missing_message"


async def t_chat_empty_message(client):
    r = await client.post("/v1/chat", json={"message": "   "})
    assert r.status == 422


async def t_chat_bad_json(client):
    r = await client.post("/v1/chat", data="{not json", headers={"Content-Type": "application/json"})
    assert r.status == 400
    assert (await r.json())["error"]["code"] == "invalid_json"


async def t_chat_bad_tools_type(client):
    r = await client.post("/v1/chat", json={"message": "hi", "tools": "web_search"})
    assert r.status == 422
    assert (await r.json())["error"]["code"] == "bad_tools"


async def t_chat_bad_image_urls_type(client):
    r = await client.post("/v1/chat", json={"message": "hi", "image_urls": "not-a-list"})
    assert r.status == 422
    assert (await r.json())["error"]["code"] == "bad_image_urls"


async def t_chat_bad_session_id_type(client):
    r = await client.post("/v1/chat", json={"message": "hi", "session_id": 12345})
    assert r.status == 422
    assert (await r.json())["error"]["code"] == "bad_session_id"


async def t_chat_message_too_large(client):
    r = await client.post("/v1/chat", json={"message": "x" * 2_000_001})
    assert r.status == 413
    assert (await r.json())["error"]["code"] == "message_too_large"


async def t_chat_budget_exhausted_429(client):
    """Budget exhausted + request too large for Tier-1 => HTTP 429 budget_exceeded.

    A deliberate local quota refusal must NOT masquerade as a 502 upstream_error
    (no model was called). The exact payload + a concrete fallback must survive to
    the HTTP envelope. Env caps are applied before create_app via the `_env` attr.
    """
    agent = client.app[_AGENT_KEY]
    # Cross the 100-token daily cap so the budget guard arms.
    agent.memory.record_spend(session_id="srv", tier="tier2_deep", model="m", tokens_in=200, tokens_out=0)
    big = "Analyze this huge document. " * 200  # ~1.5k est. tokens >> 50 T1 cap, < 2M chars
    r = await client.post("/v1/chat", json={"message": big})
    assert r.status == 429, r.status
    d = await r.json()
    assert d["ok"] is False
    assert d["error"]["code"] == "budget_exceeded", d["error"]["code"]
    assert d["error"]["fallback"], "must carry a concrete fallback"
    assert d["error"]["payload"]["tier1_context_tokens"] == 50


# Applied BEFORE create_app (load_settings reads env at build time); tiny cap so the
# test payload deterministically exceeds Tier-1 without sending 64k tokens of text.
t_chat_budget_exhausted_429._env = {"HERMES_DAILY_TOKEN_BUDGET": "100", "HERMES_T1_CONTEXT_TOKENS": "50"}


async def t_route_missing_message(client):
    r = await client.post("/v1/route", json={"nope": 1})
    assert r.status == 422


# ---- CORS ----
async def t_cors_preflight(client):
    r = await client.options("/v1/chat")
    assert r.status == 204
    assert r.headers["Access-Control-Allow-Methods"] == "GET,POST,OPTIONS"


async def t_cors_header_on_get(client):
    r = await client.get("/healthz")
    assert "Access-Control-Allow-Origin" in r.headers


# ---- 404 ----
async def t_unknown_path(client):
    r = await client.get("/does-not-exist")
    assert r.status == 404


TESTS = [
    ("index_page", t_index),
    ("healthz", t_healthz),
    ("readyz", t_readyz),
    ("metrics", t_metrics),
    ("models", t_models),
    ("route_dry_run", t_route_dry_run),
    ("chat_full", t_chat_full),
    ("chat_missing_message", t_chat_missing_message),
    ("chat_empty_message", t_chat_empty_message),
    ("chat_bad_json", t_chat_bad_json),
    ("chat_bad_tools_type", t_chat_bad_tools_type),
    ("chat_bad_image_urls_type", t_chat_bad_image_urls_type),
    ("chat_bad_session_id_type", t_chat_bad_session_id_type),
    ("chat_message_too_large", t_chat_message_too_large),
    ("chat_budget_exhausted_429", t_chat_budget_exhausted_429),
    ("route_missing_message", t_route_missing_message),
    ("cors_preflight", t_cors_preflight),
    ("cors_header_on_get", t_cors_header_on_get),
    ("unknown_path_404", t_unknown_path),
]


def main() -> int:
    print(f"\nHermes-Prime HTTP suite ({len(TESTS)} cases)\n" + "-" * 50)
    for name, fn in TESTS:
        check(name, fn)
    print("-" * 50)
    print(f"  {len(PASSED)} passed, {len(FAILED)} failed")
    for n, e in FAILED:
        print(f"    - {n}: {e}")
    return 1 if FAILED else 0


# ---------------------------------------------------------------------------
# pytest bridge: expose each case as a module-level `test_*` function so that
# `pytest` collects them. The custom runner above and pytest share one source
# of truth (the TESTS list). Each wrapper raises on failure (pytest semantics)
# rather than recording into PASSED/FAILED (custom-runner semantics).
# ---------------------------------------------------------------------------
def _make_pytest_case(coro_fn):
    def _case():
        _run_case(coro_fn)  # raises AssertionError/Exception -> pytest reports it

    return _case


for _name, _fn in TESTS:
    globals()[f"test_{_name}"] = _make_pytest_case(_fn)
del _name, _fn


if __name__ == "__main__":
    raise SystemExit(main())

