"""Telegram integration tests.

Two layers, both network-free:
  * unit tests drive TelegramClient over a FakeTelegramTransport (the same
    Protocol seam production uses, so no real Bot API calls happen)
  * webhook tests drive the aiohttp app via TestClient with an injected fake
    telegram transport + the scripted LLM transport, exercising auth, dedup,
    fast-ack and background delivery end to end.

Run: python -m tests.test_telegram   (or)   python -m pytest tests/test_telegram.py -q
"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile
from typing import Any

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from aiohttp import web  # noqa: E402
from aiohttp.test_utils import TestClient, TestServer  # noqa: E402

from hermes.config import Settings, TelegramConfig  # noqa: E402
from hermes.errors import TelegramError  # noqa: E402
from hermes.telegram import TelegramClient, split_message  # noqa: E402
from server import (  # noqa: E402
    _SETTINGS_KEY,
    _TELEGRAM_TASKS_KEY,
    _on_cleanup,
    create_app,
)
from tests.fake_transport import scripted_transport, scripted_voice_transport  # noqa: E402

SECRET = "test-secret"
TOKEN = "test-token"

PASSED, FAILED = [], []


# --------------------------------------------------------------------------
# fake telegram transport (implements hermes.telegram.TelegramTransport)
# --------------------------------------------------------------------------
class FakeTelegramTransport:
    def __init__(
        self,
        *,
        fail_parse: bool = False,
        rate_limit: bool = False,
        fail_chat_action: bool = False,
        files: dict[str, bytes] | None = None,
    ) -> None:
        self.calls: list[dict[str, Any]] = []
        self.closed = False
        self._fail_parse = fail_parse
        self._rate_limit = rate_limit
        self._fail_chat_action = fail_chat_action
        self._files: dict[str, bytes] = dict(files or {})

    def set_file(self, file_id: str, data: bytes) -> None:
        self._files[file_id] = data

    async def call(self, method: str, payload: dict[str, Any]) -> dict[str, Any]:
        # Snapshot the payload: production code may mutate the dict after the
        # call (e.g. popping parse_mode on a retry), and we want to record what
        # was actually sent at call time.
        self.calls.append({"method": method, "payload": dict(payload)})
        if method == "sendMessage":
            if self._rate_limit:
                raise TelegramError(
                    "rate limited", status=429, payload={"parameters": {"retry_after": 1}}
                )
            if self._fail_parse and payload.get("parse_mode"):
                raise TelegramError(
                    "can't parse entities", status=400, payload={"description": "can't parse entities"}
                )
            return {"ok": True, "result": {"message_id": len(self.calls), "text": payload.get("text", "")}}
        if method == "sendChatAction":
            if self._fail_chat_action:
                raise TelegramError("chat action failed", status=400, payload={})
            return {"ok": True, "result": True}
        if method == "getWebhookInfo":
            return {"ok": True, "result": {"url": "", "pending_update_count": 0}}
        if method == "getFile":
            file_id = payload.get("file_id", "")
            data = self._files.get(file_id, b"")
            return {
                "ok": True,
                "result": {
                    "file_id": file_id,
                    "file_path": f"documents/{file_id}.bin",
                    "file_size": len(data),
                },
            }
        return {"ok": True, "result": True}

    async def download(self, file_path: str, max_bytes: int) -> bytes:
        self.calls.append({"method": "download", "payload": {"file_path": file_path}})
        file_id = file_path.rsplit("/", 1)[-1].removesuffix(".bin")
        data = self._files.get(file_id, b"")
        if len(data) > max_bytes:
            raise TelegramError(
                f"file exceeds {max_bytes} bytes", payload={"file_path": file_path, "size": len(data)}
            )
        return data

    async def upload(
        self,
        method: str,
        fields: dict[str, Any],
        *,
        file_field: str,
        file_bytes: bytes,
        filename: str,
        content_type: str,
    ) -> dict[str, Any]:
        self.calls.append(
            {
                "method": method,
                "payload": dict(fields),
                "file_field": file_field,
                "file_bytes": len(file_bytes),
                "filename": filename,
                "content_type": content_type,
            }
        )
        if method == "sendAudio":
            return {"ok": True, "result": {"message_id": len(self.calls), "audio": {"file_id": "fake-audio"}}}
        return {"ok": True, "result": True}

    async def close(self) -> None:
        self.closed = True

    def sends(self) -> list[dict[str, Any]]:
        return [c for c in self.calls if c["method"] == "sendMessage"]

    def uploads(self) -> list[dict[str, Any]]:
        return [c for c in self.calls if c["method"] == "sendAudio"]


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def check(name, fn):
    try:
        fn()
        PASSED.append(name)
        print(f"  PASS  {name}")
    except AssertionError as e:
        FAILED.append((name, str(e)))
        print(f"  FAIL  {name}: {e}")
    except Exception as e:  # noqa: BLE001
        FAILED.append((name, f"{type(e).__name__}: {e}"))
        print(f"  ERROR {name}: {type(e).__name__}: {e}")


async def _wait_for(pred, wait_s: float = 5.0) -> bool:
    loop = asyncio.get_event_loop()
    deadline = loop.time() + wait_s
    while loop.time() < deadline:
        if pred():
            return True
        await asyncio.sleep(0.05)
    return pred()


def _run_webhook_case(coro_fn, *, telegram_enabled: bool = True):
    """Fresh DB + app + TestClient per case; injects fake telegram + scripted LLM.

    Per-case env overrides (e.g. HERMES_DOMAIN for Mini App tests) may be declared
    as a ``_env`` dict attribute on ``coro_fn``; they are applied BEFORE create_app
    (load_settings reads the environment at build time) and restored afterwards.
    """

    async def _runner():
        os.environ["HERMES_DB_PATH"] = tempfile.mktemp(suffix=".db")
        if telegram_enabled:
            os.environ["TELEGRAM_BOT_TOKEN"] = TOKEN
            os.environ["TELEGRAM_WEBHOOK_SECRET"] = SECRET
        else:
            os.environ.pop("TELEGRAM_BOT_TOKEN", None)
            os.environ.pop("TELEGRAM_WEBHOOK_SECRET", None)
        extra_env = getattr(coro_fn, "_env", {})
        saved = {k: os.environ.get(k) for k in extra_env}
        os.environ.update(extra_env)
        tg = FakeTelegramTransport()
        # Always inject a scripted voice transport so the STT/TTS path is
        # exercisable; expose it on `tg` for voice tests (existing tests ignore it).
        voice = scripted_voice_transport()
        tg.voice_transport = voice
        app = create_app(
            transport=scripted_transport(), telegram_transport=tg, voice_transport=voice
        )
        try:
            async with TestClient(TestServer(app)) as client:
                await coro_fn(client, tg)
        finally:
            for k, prev in saved.items():
                if prev is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = prev
            for suffix in ("", "-wal", "-shm"):
                try:
                    os.remove(os.environ["HERMES_DB_PATH"] + suffix)
                except OSError:
                    pass

    asyncio.run(_runner())


def _webhook_case(coro_fn, *, enabled: bool = True):
    def _sync():
        _run_webhook_case(coro_fn, telegram_enabled=enabled)

    return _sync


# --------------------------------------------------------------------------
# unit: split_message
# --------------------------------------------------------------------------
def t_split_short():
    assert split_message("hello", 4096) == ["hello"]


def t_split_empty():
    assert split_message("", 4096) == [""]


def t_split_hard_cut_reassembles():
    text = "x" * 5000
    chunks = split_message(text, 4096)
    assert all(len(c) <= 4096 for c in chunks), [len(c) for c in chunks]
    assert "".join(chunks) == text  # no separators -> nothing stripped


def t_split_prefers_paragraph_break():
    para = "word " * 900  # ~4500 chars, no newlines inside
    text = para + "\n\n" + para
    chunks = split_message(text, 4096)
    assert len(chunks) >= 2
    assert all(len(c) <= 4096 for c in chunks)


# --------------------------------------------------------------------------
# unit: TelegramClient.send_message
# --------------------------------------------------------------------------
def t_send_parse_mode_fallback():
    async def run():
        tg = FakeTelegramTransport(fail_parse=True)
        client = TelegramClient(tg)
        await client.send_message(123, "hello *world*")
        sends = tg.sends()
        assert len(sends) == 2, sends
        assert sends[0]["payload"].get("parse_mode") == "Markdown"
        assert "parse_mode" not in sends[1]["payload"]

    asyncio.run(run())


def t_send_chunking():
    async def run():
        tg = FakeTelegramTransport()
        client = TelegramClient(tg)
        results = await client.send_message(123, "x" * 9000)
        assert len(tg.sends()) == 3, len(tg.sends())
        assert len(results) == 3

    asyncio.run(run())


def t_send_429_raises_with_payload():
    async def run():
        tg = FakeTelegramTransport(rate_limit=True)
        client = TelegramClient(tg)
        try:
            await client.send_message(123, "hi")
            raise AssertionError("expected TelegramError on 429")
        except TelegramError as exc:
            assert exc.status == 429
            assert exc.payload == {"parameters": {"retry_after": 1}}

    asyncio.run(run())


def t_send_chat_action_failure_swallowed():
    async def run():
        tg = FakeTelegramTransport(fail_chat_action=True)
        client = TelegramClient(tg)
        # must not raise: typing is best-effort UX
        await client.send_chat_action(123)

    asyncio.run(run())


# --------------------------------------------------------------------------
# unit: webhook management validation
# --------------------------------------------------------------------------
def t_set_webhook_requires_https():
    async def run():
        tg = FakeTelegramTransport()
        client = TelegramClient(tg)
        try:
            await client.set_webhook("http://x/webhook", secret_token="s", allowed_updates=("message",))
            raise AssertionError("expected TelegramError for http://")
        except TelegramError:
            pass

    asyncio.run(run())


def t_set_webhook_requires_secret():
    async def run():
        tg = FakeTelegramTransport()
        client = TelegramClient(tg)
        try:
            await client.set_webhook("https://x/webhook", secret_token="", allowed_updates=("message",))
            raise AssertionError("expected TelegramError for empty secret")
        except TelegramError:
            pass

    asyncio.run(run())


def t_set_webhook_sends_secret_and_updates():
    async def run():
        tg = FakeTelegramTransport()
        client = TelegramClient(tg, config=TelegramConfig())
        await client.set_webhook(
            "https://agent.example.uz/webhook/telegram",
            secret_token="s3cr3t",
            allowed_updates=("message", "edited_message"),
        )
        call = next(c for c in tg.calls if c["method"] == "setWebhook")
        assert call["payload"]["secret_token"] == "s3cr3t"
        assert call["payload"]["allowed_updates"] == ["message", "edited_message"]
        assert call["payload"]["drop_pending_updates"] is True

    asyncio.run(run())


# --------------------------------------------------------------------------
# unit: Mini App (Web App) menu button + reply_markup plumbing
# --------------------------------------------------------------------------
def t_set_chat_menu_button_sends_web_app():
    async def run():
        tg = FakeTelegramTransport()
        client = TelegramClient(tg, config=TelegramConfig())
        await client.set_chat_menu_button(
            url="https://slackness-vitality-silent.ngrok-free.dev/", text="Open J.A.R.V.I.S."
        )
        call = next(c for c in tg.calls if c["method"] == "setChatMenuButton")
        mb = call["payload"]["menu_button"]
        assert mb["type"] == "web_app"
        assert mb["text"] == "Open J.A.R.V.I.S."
        assert mb["web_app"]["url"] == "https://slackness-vitality-silent.ngrok-free.dev/"
        # No chat_id => bot-wide default menu button.
        assert "chat_id" not in call["payload"]

    asyncio.run(run())


def t_send_message_reply_markup_on_last_chunk_only():
    async def run():
        tg = FakeTelegramTransport()
        client = TelegramClient(tg, config=TelegramConfig(max_message_chars=10))
        markup = {"inline_keyboard": [[{"text": "Open", "web_app": {"url": "https://x/"}}]]}
        # 25 chars / limit 10 => 3 chunks; the keyboard must ride only the last.
        await client.send_message(1, "a" * 25, reply_markup=markup)
        sends = tg.sends()
        assert len(sends) == 3, len(sends)
        assert "reply_markup" not in sends[0]["payload"]
        assert "reply_markup" not in sends[1]["payload"]
        assert sends[2]["payload"]["reply_markup"] == markup

    asyncio.run(run())


def t_send_message_no_reply_markup_by_default():
    async def run():
        tg = FakeTelegramTransport()
        client = TelegramClient(tg, config=TelegramConfig())
        await client.send_message(1, "plain")
        assert "reply_markup" not in tg.sends()[0]["payload"]

    asyncio.run(run())


def t_miniapp_url_resolution():
    # Explicit HERMES_MINIAPP_URL wins, normalised with a trailing slash.
    c = TelegramConfig(miniapp_url="https://app.example.uz/console")
    assert c.resolved_miniapp_url == "https://app.example.uz/console/"
    assert c.miniapp_enabled is True
    # Falls back to the domain root (the JARVIS web console).
    c2 = TelegramConfig(domain="https://slackness-vitality-silent.ngrok-free.dev")
    assert c2.resolved_miniapp_url == "https://slackness-vitality-silent.ngrok-free.dev/"
    assert c2.miniapp_enabled is True
    # No domain and no explicit URL => disabled, empty (bot stays text-only).
    c3 = TelegramConfig()
    assert c3.resolved_miniapp_url == ""
    assert c3.miniapp_enabled is False
    # Plain-HTTP is rejected by Telegram => not "enabled".
    c4 = TelegramConfig(domain="http://insecure.example.uz")
    assert c4.miniapp_enabled is False


# --------------------------------------------------------------------------
# webhook endpoint
# --------------------------------------------------------------------------
async def t_webhook_disabled_503(client, tg):
    r = await client.post(
        "/webhook/telegram",
        json={"update_id": 1, "message": {"chat": {"id": 1}, "text": "hi"}},
    )
    assert r.status == 503
    assert (await r.json())["error"]["code"] == "telegram_disabled"


async def t_webhook_auth_failure_403(client, tg):
    r = await client.post(
        "/webhook/telegram",
        json={"update_id": 1, "message": {"chat": {"id": 1}, "text": "hi"}},
        headers={"X-Telegram-Bot-Api-Secret-Token": "wrong"},
    )
    assert r.status == 403
    assert not tg.sends()  # rejected before any work


async def t_webhook_missing_secret_403(client, tg):
    r = await client.post(
        "/webhook/telegram",
        json={"update_id": 1, "message": {"chat": {"id": 1}, "text": "hi"}},
    )
    assert r.status == 403


async def t_webhook_invalid_json_400(client, tg):
    r = await client.post(
        "/webhook/telegram",
        data="{bad json",
        headers={"X-Telegram-Bot-Api-Secret-Token": SECRET, "Content-Type": "application/json"},
    )
    assert r.status == 400


async def t_webhook_dedup(client, tg):
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {"update_id": 42, "message": {"chat": {"id": 7}, "text": "hello"}}
    r1 = await client.post("/webhook/telegram", json=update, headers=h)
    assert r1.status == 200
    d1 = await r1.json()
    assert d1["ok"] is True and "duplicate" not in d1
    r2 = await client.post("/webhook/telegram", json=update, headers=h)
    d2 = await r2.json()
    assert d2.get("duplicate") is True


async def t_webhook_processes_and_replies(client, tg):
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {"update_id": 99, "message": {"chat": {"id": 555}, "text": "Design a rate limiter"}}
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200  # fast-ack
    ok = await _wait_for(lambda: bool(tg.sends()))
    assert ok, "background task did not deliver a reply"
    send = tg.sends()[0]
    assert send["payload"]["chat_id"] == 555
    assert "·" in send["payload"]["text"]  # tier footer present


async def t_webhook_ignores_non_text(client, tg):
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {"update_id": 5, "message": {"chat": {"id": 1}, "photo": [{"file_id": "x"}]}}
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    await asyncio.sleep(0.2)
    assert not tg.sends()  # nothing routed for a photo-only update


async def t_webhook_session_continuity(client, tg):
    # Two messages from the same chat share a session id (tg_<chat_id>).
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    for uid in (201, 202):
        await client.post(
            "/webhook/telegram",
            json={"update_id": uid, "message": {"chat": {"id": 88}, "text": f"msg {uid}"}},
            headers=h,
        )
    ok = await _wait_for(lambda: len(tg.sends()) >= 2)
    assert ok, f"expected 2 replies, got {len(tg.sends())}"
    assert all(s["payload"]["chat_id"] == 88 for s in tg.sends())


# --------------------------------------------------------------------------
# graceful shutdown drain (edge-case #2): in-flight replies must survive a
# SIGTERM-style cleanup instead of being cancelled mid-run.
# --------------------------------------------------------------------------
def _app_with_drain(drain_s: float) -> web.Application:
    app = web.Application()
    app[_SETTINGS_KEY] = Settings(telegram=TelegramConfig(shutdown_drain_s=drain_s))
    app[_TELEGRAM_TASKS_KEY] = set()
    return app


def t_cleanup_drains_inflight_task():
    """A task that finishes within the drain window must complete, not be cut."""

    async def run():
        delivered: list[str] = []

        async def slow_worker():
            await asyncio.sleep(0.3)  # simulates a Tier-2/3 answer still running
            delivered.append("reply-sent")

        app = _app_with_drain(drain_s=5.0)
        task = asyncio.create_task(slow_worker())
        app[_TELEGRAM_TASKS_KEY].add(task)
        await _on_cleanup(app)
        assert delivered == ["reply-sent"], "in-flight reply was dropped during shutdown"
        assert not task.cancelled()

    asyncio.run(run())


def t_cleanup_cancels_straggler_past_deadline():
    """A task still running past shutdown_drain_s is cancelled so stop can't hang."""

    async def run():
        app = _app_with_drain(drain_s=0.2)

        async def stuck_worker():
            await asyncio.sleep(30)  # would hang shutdown forever if not bounded

        task = asyncio.create_task(stuck_worker())
        app[_TELEGRAM_TASKS_KEY].add(task)
        loop = asyncio.get_event_loop()
        start = loop.time()
        await _on_cleanup(app)
        elapsed = loop.time() - start
        assert task.cancelled(), "straggler past the deadline must be cancelled"
        assert elapsed < 5.0, f"drain ignored its deadline (took {elapsed:.1f}s)"

    asyncio.run(run())


# --------------------------------------------------------------------------
# whitelist (access control): unauthorized senders are rejected before any
# router/LLM spend and before a concurrency slot is taken.
# --------------------------------------------------------------------------
async def t_webhook_whitelist_rejects_unauthorized(client, tg):
    os.environ["HERMES_ALLOWED_USERS"] = "111,222"
    try:
        h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
        update = {
            "update_id": 500,
            "message": {"chat": {"id": 555}, "from": {"id": 999}, "text": "Design a rate limiter"},
        }
        r = await client.post("/webhook/telegram", json=update, headers=h)
        assert r.status == 200  # webhook still fast-acks
        ok = await _wait_for(lambda: bool(tg.sends()))
        assert ok, "expected a 403 rejection reply"
        text = tg.sends()[0]["payload"]["text"]
        assert "403" in text and "Ruxsat berilmagan" in text, text
        # No agent work happened: no typing signal (started only inside the gate)
        # and no tier footer in the reply.
        methods = [c["method"] for c in tg.calls]
        assert "sendChatAction" not in methods, methods
        assert "·" not in text, text
    finally:
        os.environ.pop("HERMES_ALLOWED_USERS", None)


async def t_webhook_whitelist_allows_authorized(client, tg):
    os.environ["HERMES_ALLOWED_USERS"] = "111,222"
    try:
        h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
        update = {
            "update_id": 501,
            "message": {"chat": {"id": 555}, "from": {"id": 111}, "text": "Design a rate limiter"},
        }
        r = await client.post("/webhook/telegram", json=update, headers=h)
        assert r.status == 200
        ok = await _wait_for(lambda: bool(tg.sends()))
        assert ok, "authorized user should get an answer"
        text = tg.sends()[0]["payload"]["text"]
        assert "403" not in text, text
        assert "·" in text, "agent should have answered with a tier footer"
    finally:
        os.environ.pop("HERMES_ALLOWED_USERS", None)


async def t_webhook_whitelist_disabled_allows_all(client, tg):
    # Empty/unset allowlist => gate disabled (single-user default): any sender is served.
    os.environ.pop("HERMES_ALLOWED_USERS", None)
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {
        "update_id": 502,
        "message": {"chat": {"id": 555}, "from": {"id": 424242}, "text": "Design a rate limiter"},
    }
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    ok = await _wait_for(lambda: bool(tg.sends()))
    assert ok, "with the gate disabled every sender is served"
    text = tg.sends()[0]["payload"]["text"]
    assert "403" not in text and "·" in text, text


# --------------------------------------------------------------------------
# Mini App entry: /start and /menu reply with the JARVIS greeting + a Web App
# inline button (no LLM spend). With no HTTPS domain the button is omitted and
# the greeting degrades to plain text.
# --------------------------------------------------------------------------
async def t_webhook_start_replies_with_miniapp_button(client, tg):
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {
        "update_id": 700,
        "message": {"chat": {"id": 900}, "from": {"id": 1, "first_name": "Tony"}, "text": "/start"},
    }
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    ok = await _wait_for(lambda: bool(tg.sends()))
    assert ok, "/start should reply with the greeting"
    send = tg.sends()[0]["payload"]
    assert send["chat_id"] == 900
    assert "J.A.R.V.I.S." in send["text"] and "Sir" in send["text"], send["text"]
    assert "Tony" in send["text"], send["text"]  # personalised with first_name
    # Inline keyboard carries the Web App button pointing at the domain root.
    kb = send["reply_markup"]["inline_keyboard"]
    btn = kb[0][0]
    assert btn["web_app"]["url"] == "https://slackness-vitality-silent.ngrok-free.dev/"
    # No agent run: /start must not consume an LLM call (no tier footer).
    assert "·" not in send["text"], send["text"]


t_webhook_start_replies_with_miniapp_button._env = {
    "HERMES_DOMAIN": "https://slackness-vitality-silent.ngrok-free.dev"
}


async def t_webhook_menu_command_also_opens(client, tg):
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {
        "update_id": 701,
        "message": {"chat": {"id": 901}, "from": {"id": 1}, "text": "/menu@jarvis_bot"},
    }
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    ok = await _wait_for(lambda: bool(tg.sends()))
    assert ok, "/menu@bot should reply with the greeting"
    send = tg.sends()[0]["payload"]
    assert "J.A.R.V.I.S." in send["text"], send["text"]
    assert send["reply_markup"]["inline_keyboard"][0][0]["web_app"]["url"].startswith("https://")


t_webhook_menu_command_also_opens._env = {"HERMES_DOMAIN": "https://slackness-vitality-silent.ngrok-free.dev"}


async def t_webhook_start_without_domain_is_plain_text(client, tg):
    # No HERMES_DOMAIN => miniapp_enabled False => greeting with no Web App button.
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {
        "update_id": 702,
        "message": {"chat": {"id": 902}, "from": {"id": 1}, "text": "/start"},
    }
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    ok = await _wait_for(lambda: bool(tg.sends()))
    assert ok, "/start should still reply when no Mini App URL is configured"
    send = tg.sends()[0]["payload"]
    assert "J.A.R.V.I.S." in send["text"], send["text"]
    assert "reply_markup" not in send, "no Web App button when no HTTPS domain is set"


t_webhook_start_without_domain_is_plain_text._env = {"HERMES_DOMAIN": ""}


async def t_webhook_non_command_text_still_routes(client, tg):
    # A message that merely starts with '/' but is not a known command is NOT
    # swallowed by the menu handler; it flows to the agent as usual.
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {
        "update_id": 703,
        "message": {"chat": {"id": 903}, "from": {"id": 1}, "text": "/explain quantum tunneling"},
    }
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    ok = await _wait_for(lambda: bool(tg.sends()))
    assert ok, "unknown /command should route to the agent"
    text = tg.sends()[0]["payload"]["text"]
    assert "·" in text, text  # tier footer => a real agent run happened


t_webhook_non_command_text_still_routes._env = {
    "HERMES_DOMAIN": "https://slackness-vitality-silent.ngrok-free.dev"
}


# --------------------------------------------------------------------------
# document ingestion: uploaded files are fetched, extracted, and pinned to T3.
# --------------------------------------------------------------------------
async def t_webhook_document_routes_to_tier3(client, tg):
    tg.set_file("doc1", b"def compute():\n    return 42\n")
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {
        "update_id": 600,
        "message": {
            "chat": {"id": 777},
            "from": {"id": 1},
            "caption": "Review this code",
            "document": {"file_id": "doc1", "file_name": "calc.py", "mime_type": "text/x-python", "file_size": 26},
        },
    }
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    ok = await _wait_for(lambda: bool(tg.sends()))
    assert ok, "document update should produce a reply"
    send = tg.sends()[0]["payload"]
    assert send["chat_id"] == 777
    assert "tier3_multimodal" in send["text"], send["text"]  # forced to Tier-3
    methods = [c["method"] for c in tg.calls]
    assert "getFile" in methods and "download" in methods, methods


async def t_webhook_document_unsupported_type(client, tg):
    tg.set_file("img1", b"\x89PNG\r\n\x1a\nfakedata")
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {
        "update_id": 601,
        "message": {
            "chat": {"id": 778},
            "from": {"id": 1},
            "document": {"file_id": "img1", "file_name": "photo.png", "mime_type": "image/png", "file_size": 16},
        },
    }
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    ok = await _wait_for(lambda: bool(tg.sends()))
    assert ok, "unsupported document should surface a DocumentError reply"
    text = tg.sends()[0]["payload"]["text"]
    assert "nsupported" in text, text  # "Unsupported file type ..."
    assert "Fallback" in text, text


# --------------------------------------------------------------------------
# voice: STT (Gemini via Tier-3) -> agent -> TTS (edge-tts) over the webhook
# --------------------------------------------------------------------------
async def t_webhook_voice_transcribes_and_speaks(client, tg):
    """Voice note -> STT transcript -> agent answer (text) + spoken reply (audio)."""

    tg.set_file("v1", b"OggS\x00\x02fake-opus-payload")
    tg.voice_transport._transcripts = ["Design a token bucket rate limiter"]
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {
        "update_id": 700,
        "message": {
            "chat": {"id": 910},
            "from": {"id": 1},
            "voice": {"file_id": "v1", "mime_type": "audio/ogg", "duration": 4},
        },
    }
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    # Text answer arrives first, then the spoken (sendAudio) reply.
    ok = await _wait_for(lambda: bool(tg.uploads()))
    assert ok, "voice update should produce a spoken (sendAudio) reply in mirror mode"
    # STT was invoked with the downloaded bytes.
    stt = tg.voice_transport.stt_calls()
    assert len(stt) == 1, stt
    assert stt[0]["bytes"] == len(b"OggS\x00\x02fake-opus-payload")
    # The transcript (not raw bytes) reached the agent -> a normal answer was sent.
    sends = tg.sends()
    assert sends, "a text answer should accompany the spoken reply"
    assert sends[0]["payload"]["chat_id"] == 910
    assert "rate limiter" in sends[0]["payload"]["text"].lower()
    # TTS ran exactly once and the audio was uploaded as sendAudio.
    assert len(tg.voice_transport.tts_calls()) == 1
    up = tg.uploads()[0]
    assert up["payload"]["chat_id"] == 910
    assert up["content_type"] == "audio/mpeg"


t_webhook_voice_transcribes_and_speaks._env = {
    "GEMINI_API_KEY": "test-gemini",  # STT rides Tier-3; TTS (edge-tts) is keyless
}


async def t_webhook_voice_stt_disabled_surfaces_error(client, tg):
    """No GEMINI_API_KEY -> STT unavailable -> VoiceError surfaced with fallback."""

    tg.set_file("v2", b"OggS\x00\x02fake")
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {
        "update_id": 701,
        "message": {
            "chat": {"id": 911},
            "from": {"id": 1},
            "voice": {"file_id": "v2", "mime_type": "audio/ogg", "duration": 2},
        },
    }
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    ok = await _wait_for(lambda: bool(tg.sends()))
    assert ok, "voice with STT disabled should surface a VoiceError reply"
    text = tg.sends()[0]["payload"]["text"]
    assert "speech-to-text is not configured" in text.lower(), text
    assert "Fallback" in text, text
    # No LLM answer and no audio: we never fabricated a transcript.
    assert not tg.voice_transport.stt_calls()
    assert not tg.uploads()


t_webhook_voice_stt_disabled_surfaces_error._env = {"GEMINI_API_KEY": ""}


async def t_webhook_voice_silence_no_llm(client, tg):
    """Empty transcript (silence) -> in-character nudge, zero LLM spend, no audio."""

    tg.set_file("v3", b"OggS\x00\x02silence")
    tg.voice_transport._transcripts = [""]  # Gemini heard nothing
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {
        "update_id": 702,
        "message": {
            "chat": {"id": 912},
            "from": {"id": 1},
            "voice": {"file_id": "v3", "mime_type": "audio/ogg", "duration": 1},
        },
    }
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    ok = await _wait_for(lambda: bool(tg.sends()))
    assert ok, "silence should still get a reply"
    text = tg.sends()[0]["payload"]["text"]
    assert "silence" in text.lower(), text
    assert len(tg.voice_transport.stt_calls()) == 1  # we did try to transcribe
    assert not tg.voice_transport.tts_calls()  # but never spoke
    assert not tg.uploads()


t_webhook_voice_silence_no_llm._env = {"GEMINI_API_KEY": "test-gemini"}


async def t_webhook_text_no_tts_in_mirror(client, tg):
    """Mirror mode: a typed message gets text only (no spoken reply, no TTS spend)."""

    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {"update_id": 703, "message": {"chat": {"id": 913}, "from": {"id": 1}, "text": "Design a rate limiter"}}
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    ok = await _wait_for(lambda: bool(tg.sends()))
    assert ok, "text update should produce a reply"
    assert not tg.voice_transport.tts_calls(), "mirror mode must not speak a typed message"
    assert not tg.uploads()


t_webhook_text_no_tts_in_mirror._env = {}  # text input: no STT; TTS (edge-tts) is keyless


async def t_webhook_tts_always_speaks_text(client, tg):
    """HERMES_TTS_REPLY_MODE=always: even a typed message gets a spoken reply."""

    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {"update_id": 704, "message": {"chat": {"id": 914}, "from": {"id": 1}, "text": "Design a rate limiter"}}
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    ok = await _wait_for(lambda: bool(tg.uploads()))
    assert ok, "always mode should speak even a typed message"
    assert len(tg.voice_transport.tts_calls()) == 1
    assert tg.uploads()[0]["payload"]["chat_id"] == 914


t_webhook_tts_always_speaks_text._env = {
    "HERMES_TTS_REPLY_MODE": "always",  # TTS (edge-tts) is keyless; text input needs no STT
}


async def t_webhook_tts_off_voice_gets_text_only(client, tg):
    """HERMES_TTS_REPLY_MODE=off: voice in -> STT -> text answer, but never speak."""

    tg.set_file("v4", b"OggS\x00\x02fake")
    tg.voice_transport._transcripts = ["Design a rate limiter"]
    h = {"X-Telegram-Bot-Api-Secret-Token": SECRET}
    update = {
        "update_id": 705,
        "message": {
            "chat": {"id": 915},
            "from": {"id": 1},
            "voice": {"file_id": "v4", "mime_type": "audio/ogg", "duration": 3},
        },
    }
    r = await client.post("/webhook/telegram", json=update, headers=h)
    assert r.status == 200
    ok = await _wait_for(lambda: bool(tg.sends()))
    assert ok, "voice with tts off should still answer in text"
    assert len(tg.voice_transport.stt_calls()) == 1  # transcription still happened
    assert not tg.voice_transport.tts_calls(), "tts off must never synthesize"
    assert not tg.uploads()


t_webhook_tts_off_voice_gets_text_only._env = {
    "GEMINI_API_KEY": "test-gemini",  # voice input needs STT; TTS off below
    "HERMES_TTS_REPLY_MODE": "off",
}


def t_download_file_returns_bytes():
    async def run():
        tg = FakeTelegramTransport()
        tg.set_file("d1", b"hello world")
        client = TelegramClient(tg, config=TelegramConfig())
        try:
            info, data = await client.download_file("d1", max_bytes=1000)
            return info, data
        finally:
            await client.aclose()

    info, data = asyncio.run(run())
    assert data == b"hello world"
    assert info["file_path"].endswith("d1.bin")


def t_download_file_rejects_oversize():
    async def run():
        tg = FakeTelegramTransport()
        tg.set_file("big", b"x" * 100)
        client = TelegramClient(tg, config=TelegramConfig())
        try:
            await client.download_file("big", max_bytes=10)
            raise AssertionError("expected TelegramError for oversize file")
        except TelegramError as exc:
            assert "limit" in exc.message or "over" in exc.message, exc.message
        finally:
            await client.aclose()

    asyncio.run(run())


TESTS = [
    ("split_short", t_split_short),
    ("split_empty", t_split_empty),
    ("split_hard_cut_reassembles", t_split_hard_cut_reassembles),
    ("split_prefers_paragraph_break", t_split_prefers_paragraph_break),
    ("send_parse_mode_fallback", t_send_parse_mode_fallback),
    ("send_chunking", t_send_chunking),
    ("send_429_raises_with_payload", t_send_429_raises_with_payload),
    ("send_chat_action_failure_swallowed", t_send_chat_action_failure_swallowed),
    ("set_webhook_requires_https", t_set_webhook_requires_https),
    ("set_webhook_requires_secret", t_set_webhook_requires_secret),
    ("set_webhook_sends_secret_and_updates", t_set_webhook_sends_secret_and_updates),
    ("set_chat_menu_button_sends_web_app", t_set_chat_menu_button_sends_web_app),
    ("send_message_reply_markup_on_last_chunk_only", t_send_message_reply_markup_on_last_chunk_only),
    ("send_message_no_reply_markup_by_default", t_send_message_no_reply_markup_by_default),
    ("miniapp_url_resolution", t_miniapp_url_resolution),
    ("webhook_disabled_503", _webhook_case(t_webhook_disabled_503, enabled=False)),
    ("webhook_auth_failure_403", _webhook_case(t_webhook_auth_failure_403)),
    ("webhook_missing_secret_403", _webhook_case(t_webhook_missing_secret_403)),
    ("webhook_invalid_json_400", _webhook_case(t_webhook_invalid_json_400)),
    ("webhook_dedup", _webhook_case(t_webhook_dedup)),
    ("webhook_processes_and_replies", _webhook_case(t_webhook_processes_and_replies)),
    ("webhook_ignores_non_text", _webhook_case(t_webhook_ignores_non_text)),
    ("webhook_session_continuity", _webhook_case(t_webhook_session_continuity)),
    ("webhook_whitelist_rejects_unauthorized", _webhook_case(t_webhook_whitelist_rejects_unauthorized)),
    ("webhook_whitelist_allows_authorized", _webhook_case(t_webhook_whitelist_allows_authorized)),
    ("webhook_whitelist_disabled_allows_all", _webhook_case(t_webhook_whitelist_disabled_allows_all)),
    ("webhook_start_replies_with_miniapp_button", _webhook_case(t_webhook_start_replies_with_miniapp_button)),
    ("webhook_menu_command_also_opens", _webhook_case(t_webhook_menu_command_also_opens)),
    ("webhook_start_without_domain_is_plain_text", _webhook_case(t_webhook_start_without_domain_is_plain_text)),
    ("webhook_non_command_text_still_routes", _webhook_case(t_webhook_non_command_text_still_routes)),
    ("webhook_document_routes_to_tier3", _webhook_case(t_webhook_document_routes_to_tier3)),
    ("webhook_document_unsupported_type", _webhook_case(t_webhook_document_unsupported_type)),
    ("webhook_voice_transcribes_and_speaks", _webhook_case(t_webhook_voice_transcribes_and_speaks)),
    ("webhook_voice_stt_disabled_surfaces_error", _webhook_case(t_webhook_voice_stt_disabled_surfaces_error)),
    ("webhook_voice_silence_no_llm", _webhook_case(t_webhook_voice_silence_no_llm)),
    ("webhook_text_no_tts_in_mirror", _webhook_case(t_webhook_text_no_tts_in_mirror)),
    ("webhook_tts_always_speaks_text", _webhook_case(t_webhook_tts_always_speaks_text)),
    ("webhook_tts_off_voice_gets_text_only", _webhook_case(t_webhook_tts_off_voice_gets_text_only)),
    ("download_file_returns_bytes", t_download_file_returns_bytes),
    ("download_file_rejects_oversize", t_download_file_rejects_oversize),
    ("cleanup_drains_inflight_task", t_cleanup_drains_inflight_task),
    ("cleanup_cancels_straggler_past_deadline", t_cleanup_cancels_straggler_past_deadline),
]


def main() -> int:
    print(f"\nHermes-Prime telegram suite ({len(TESTS)} cases)\n" + "-" * 50)
    for name, fn in TESTS:
        check(name, fn)
    print("-" * 50)
    print(f"  {len(PASSED)} passed, {len(FAILED)} failed")
    for n, e in FAILED:
        print(f"    - {n}: {e}")
    return 1 if FAILED else 0


# pytest bridge: expose each case as a module-level test_* function.
for _name, _fn in TESTS:
    globals()[f"test_{_name}"] = _fn
del _name, _fn


if __name__ == "__main__":
    raise SystemExit(main())
