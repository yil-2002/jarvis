"""Voice unit tests: STT/TTS client guards, speech truncation, and error envelopes.

Network-free: exercises VoiceClient over a FakeVoiceTransport, and the production
GeminiEdgeVoiceTransport over a fake LLMClient (STT) + a fake ``edge_tts`` module
(TTS). No real Gemini/edge-tts calls happen here.

Design under test
-----------------
* STT rides Tier-3 (Gemini via Omni Router) -> gated by GEMINI_API_KEY.
* TTS uses edge-tts -> keyless (only needs the package installed + mode != off).

Run: python -m pytest -q tests/test_voice.py  (or)  python -m tests.test_voice
"""

from __future__ import annotations

import asyncio
import base64
import os
import sys
import types
from contextlib import contextmanager
from typing import Any

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hermes.config import Tier, VoiceConfig  # noqa: E402
from hermes.errors import LLMError, VoiceError  # noqa: E402
from hermes.llm import LLMResult  # noqa: E402
from hermes.voice import (  # noqa: E402
    GeminiEdgeVoiceTransport,
    VoiceClient,
    _audio_format,
    truncate_for_speech,
)
from tests.fake_transport import FakeVoiceTransport  # noqa: E402

PASSED, FAILED = [], []
GEMINI_KEY = "GEMINI_API_KEY"


def check(name, fn):
    try:
        fn()
        PASSED.append(name)
        print(f"  PASS  {name}")
    except AssertionError as e:
        FAILED.append((name, str(e)))
        print(f"  FAIL  {name}: {e}")
    except Exception as e:  # noqa: BLE001
        FAILED.append((name, f"{type(e).__name__}: {e}"))
        print(f"  ERROR {name}: {type(e).__name__}: {e}")


def _with_gemini(fn):
    """Run ``fn`` with GEMINI_API_KEY set (enables STT), restoring env afterwards."""

    def _wrapped():
        saved = os.environ.get(GEMINI_KEY)
        os.environ[GEMINI_KEY] = "test-gemini"
        try:
            fn()
        finally:
            if saved is None:
                os.environ.pop(GEMINI_KEY, None)
            else:
                os.environ[GEMINI_KEY] = saved

    return _wrapped


def _without_gemini(fn):
    """Run ``fn`` with GEMINI_API_KEY cleared (disables STT)."""

    def _wrapped():
        saved = os.environ.get(GEMINI_KEY)
        os.environ.pop(GEMINI_KEY, None)
        try:
            fn()
        finally:
            if saved is not None:
                os.environ[GEMINI_KEY] = saved

    return _wrapped


# --------------------------------------------------------------------------
# test doubles for the production transport
# --------------------------------------------------------------------------
class FakeLLMClient:
    """Stand-in for hermes.llm.LLMClient: records complete() calls, replays a result."""

    def __init__(self, *, text: str = "  transcribed text  ", error: Exception | None = None, delay: float = 0.0) -> None:
        self.calls: list[dict[str, Any]] = []
        self.closed = False
        self._text = text
        self._error = error
        self._delay = delay

    async def complete(self, tier: Tier, messages: list[dict[str, Any]], **kwargs: Any) -> LLMResult:
        self.calls.append({"tier": tier, "messages": messages, "kwargs": kwargs})
        if self._delay:
            await asyncio.sleep(self._delay)
        if self._error is not None:
            raise self._error
        return LLMResult(text=self._text)

    async def close(self) -> None:
        self.closed = True


class _FakeCommunicate:
    """Mimics edge_tts.Communicate: stream() yields audio + non-audio chunks."""

    last: dict[str, Any] = {}
    chunks: list[dict[str, Any]] = [{"type": "audio", "data": b"\xff\xfb\x90\x00HDR"}, {"type": "audio", "data": b"BODY"}]
    raise_on_stream: Exception | None = None

    def __init__(self, text: str, voice: str, *, rate: str = "+0%", volume: str = "+0%", pitch: str = "+0Hz") -> None:
        _FakeCommunicate.last = {"text": text, "voice": voice, "rate": rate, "volume": volume, "pitch": pitch}

    async def stream(self):
        if _FakeCommunicate.raise_on_stream is not None:
            raise _FakeCommunicate.raise_on_stream
        for chunk in _FakeCommunicate.chunks:
            yield chunk


@contextmanager
def _fake_edge_tts():
    """Install a fake ``edge_tts`` module so synthesize() runs offline & deterministically."""

    mod = types.ModuleType("edge_tts")
    mod.Communicate = _FakeCommunicate
    _FakeCommunicate.last = {}
    _FakeCommunicate.chunks = [{"type": "audio", "data": b"\xff\xfb\x90\x00HDR"}, {"type": "audio", "data": b"BODY"}]
    _FakeCommunicate.raise_on_stream = None
    saved = sys.modules.get("edge_tts")
    sys.modules["edge_tts"] = mod
    try:
        yield mod
    finally:
        if saved is None:
            sys.modules.pop("edge_tts", None)
        else:
            sys.modules["edge_tts"] = saved


# --------------------------------------------------------------------------
# truncate_for_speech
# --------------------------------------------------------------------------
def t_truncate_short_unchanged():
    assert truncate_for_speech("hello world", 100) == "hello world"


def t_truncate_empty():
    assert truncate_for_speech("", 100) == ""


def t_truncate_collapses_whitespace():
    assert truncate_for_speech("a\n\n  b\t c", 100) == "a b c"


def t_truncate_strips_code_fences():
    out = truncate_for_speech("Run this:\n```python\nprint(1)\n```\nDone.", 200)
    assert "```" not in out and "`" not in out, out
    assert "print(1)" in out


def t_truncate_strips_inline_backticks():
    assert "`" not in truncate_for_speech("use `foo` here", 100)


def t_truncate_caps_at_word_boundary():
    text = "word " * 100
    out = truncate_for_speech(text, 50)
    assert len(out) <= 50 + len(" …"), len(out)
    assert out.endswith("…")
    assert not out.rstrip(" …").endswith("wor")


def t_truncate_zero_max_returns_all_cleaned():
    assert truncate_for_speech("a  b", 0) == "a b"


# --------------------------------------------------------------------------
# _audio_format: mime_type -> input_audio format token
# --------------------------------------------------------------------------
def t_audio_format_maps_mime():
    assert _audio_format("audio/ogg") == "ogg"
    assert _audio_format("audio/opus") == "ogg"
    assert _audio_format("audio/mpeg") == "mp3"
    assert _audio_format("audio/x-wav") == "wav"
    assert _audio_format("audio/mp4") == "m4a"
    # charset suffixes and unknown types fall back gracefully
    assert _audio_format("audio/ogg; codecs=opus") == "ogg"
    assert _audio_format("application/octet-stream") == "ogg"
    assert _audio_format("") == "ogg"


# --------------------------------------------------------------------------
# VoiceConfig: enablement + reply policy
# --------------------------------------------------------------------------
@_without_gemini
def t_config_stt_disabled_without_key():
    cfg = VoiceConfig()
    assert cfg.stt_enabled is False
    assert cfg.stt_api_key_env == "GEMINI_API_KEY"


@_with_gemini
def t_config_stt_enabled_with_key():
    cfg = VoiceConfig()
    assert cfg.stt_enabled is True


def t_config_tts_is_keyless():
    # No API key anywhere, yet TTS is available (edge-tts installed + mode != off).
    cfg = VoiceConfig()
    assert cfg.tts_reply_mode == "mirror"
    assert cfg.tts_enabled is True  # edge-tts is a declared dependency
    assert cfg.tts_voice == "en-GB-ThomasNeural"
    assert cfg.stt_tier == "tier3_multimodal"


def t_should_speak_mirror():
    cfg = VoiceConfig(tts_reply_mode="mirror")
    assert cfg.should_speak(incoming_was_voice=True) is True
    assert cfg.should_speak(incoming_was_voice=False) is False


def t_should_speak_always():
    cfg = VoiceConfig(tts_reply_mode="always")
    assert cfg.should_speak(incoming_was_voice=False) is True
    assert cfg.should_speak(incoming_was_voice=True) is True


def t_should_speak_off():
    cfg = VoiceConfig(tts_reply_mode="off")
    assert cfg.tts_enabled is False
    assert cfg.should_speak(incoming_was_voice=True) is False


# --------------------------------------------------------------------------
# VoiceClient: readiness guards (never fabricate, never call provider unkeyed)
# --------------------------------------------------------------------------
@_without_gemini
def t_client_stt_guard_without_key():
    async def run():
        client = VoiceClient(FakeVoiceTransport(), config=VoiceConfig())
        try:
            await client.transcribe(b"audio")
            raise AssertionError("expected VoiceError when STT is unconfigured")
        except VoiceError as exc:
            assert exc.stage == "stt"
            assert "GEMINI_API_KEY" in (exc.fallback or "")
            assert exc.to_envelope()["stage"] == "stt"

    asyncio.run(run())


def t_client_tts_guard_when_off():
    async def run():
        client = VoiceClient(FakeVoiceTransport(), config=VoiceConfig(tts_reply_mode="off"))
        try:
            await client.synthesize("hello")
            raise AssertionError("expected VoiceError when TTS mode is off")
        except VoiceError as exc:
            assert exc.stage == "tts"

    asyncio.run(run())


@_with_gemini
def t_client_transcribe_passes_config_through():
    async def run():
        vt = FakeVoiceTransport(transcripts=["the answer is 42"])
        client = VoiceClient(vt, config=VoiceConfig(stt_prompt="Say what you hear."))
        out = await client.transcribe(b"some-opus-bytes", mime_type="audio/ogg")
        assert out == "the answer is 42"
        call = vt.stt_calls()[0]
        assert call["prompt"] == "Say what you hear."
        assert call["tier"] == "tier3_multimodal"
        assert call["mime_type"] == "audio/ogg"
        assert call["bytes"] == len(b"some-opus-bytes")
        await client.aclose()
        assert vt.closed is True

    asyncio.run(run())


@_with_gemini
def t_client_transcribe_resolves_tier_and_falls_back():
    async def run():
        vt = FakeVoiceTransport(transcripts=["ok"])
        # Explicit tier string is honoured.
        c1 = VoiceClient(vt, config=VoiceConfig(stt_tier="tier3_multimodal"))
        await c1.transcribe(b"a")
        assert vt.stt_calls()[-1]["tier"] == "tier3_multimodal"
        # An invalid tier string falls back to Tier-3 rather than crashing.
        c2 = VoiceClient(vt, config=VoiceConfig(stt_tier="not-a-tier"))
        await c2.transcribe(b"a")
        assert vt.stt_calls()[-1]["tier"] == Tier.T3.value

    asyncio.run(run())


def t_client_synthesize_truncates_and_returns_bytes():
    async def run():
        vt = FakeVoiceTransport()
        client = VoiceClient(vt, config=VoiceConfig(tts_max_chars=40))
        audio = await client.synthesize("word " * 100)
        assert isinstance(audio, bytes) and audio
        assert vt.tts_calls()[0]["chars"] <= 40 + len(" …")

    asyncio.run(run())


def t_client_synthesize_empty_answer_skips():
    async def run():
        client = VoiceClient(FakeVoiceTransport(), config=VoiceConfig())
        try:
            await client.synthesize("   ")
            raise AssertionError("expected VoiceError for empty speech input")
        except VoiceError as exc:
            assert exc.stage == "tts"

    asyncio.run(run())


# --------------------------------------------------------------------------
# GeminiEdgeVoiceTransport.transcribe (STT via LLMClient) — network-free
# --------------------------------------------------------------------------
def t_gemini_transcribe_builds_input_audio():
    async def run():
        llm = FakeLLMClient(text="  hello there  ")
        t = GeminiEdgeVoiceTransport(llm)
        raw = b"OggS\x00\x02opus-payload"
        out = await t.transcribe(raw, mime_type="audio/ogg", prompt="Transcribe this.", tier=Tier.T3, timeout_s=30)
        assert out == "hello there"  # stripped
        call = llm.calls[0]
        assert call["tier"] is Tier.T3
        assert call["kwargs"].get("temperature") == 0.0  # deterministic transcription
        msg = call["messages"][0]
        assert msg["role"] == "user"
        text_part, audio_part = msg["content"]
        assert text_part == {"type": "text", "text": "Transcribe this."}
        assert audio_part["type"] == "input_audio"
        assert audio_part["input_audio"]["format"] == "ogg"
        # base64 round-trips to the exact bytes we handed in (no transcoding).
        assert base64.b64decode(audio_part["input_audio"]["data"]) == raw

    asyncio.run(run())


def t_gemini_transcribe_wraps_llmerror():
    async def run():
        err = LLMError(message="gemini HTTP 400", status=400, payload={"error": "bad audio"}, retryable=False)
        t = GeminiEdgeVoiceTransport(FakeLLMClient(error=err))
        try:
            await t.transcribe(b"audio", mime_type="audio/ogg", prompt="p", tier=Tier.T3, timeout_s=5)
            raise AssertionError("expected VoiceError wrapping the LLMError")
        except VoiceError as exc:
            assert exc.stage == "stt"
            assert exc.status == 400
            assert exc.payload == {"error": "bad audio"}

    asyncio.run(run())


def t_gemini_transcribe_rejects_empty_audio():
    async def run():
        llm = FakeLLMClient()
        t = GeminiEdgeVoiceTransport(llm)
        try:
            await t.transcribe(b"", mime_type="audio/ogg", prompt="p", tier=Tier.T3, timeout_s=5)
            raise AssertionError("expected VoiceError for empty audio")
        except VoiceError as exc:
            assert exc.stage == "stt"
        assert not llm.calls  # never hit the provider with empty audio

    asyncio.run(run())


def t_gemini_transcribe_timeout():
    async def run():
        t = GeminiEdgeVoiceTransport(FakeLLMClient(delay=0.5))
        try:
            await t.transcribe(b"audio", mime_type="audio/ogg", prompt="p", tier=Tier.T3, timeout_s=0.05)
            raise AssertionError("expected VoiceError on timeout")
        except VoiceError as exc:
            assert exc.stage == "stt"
            assert "timed out" in exc.message

    asyncio.run(run())


# --------------------------------------------------------------------------
# GeminiEdgeVoiceTransport.synthesize (TTS via edge-tts) — fake module, offline
# --------------------------------------------------------------------------
def t_gemini_synthesize_streams_mp3():
    async def run():
        with _fake_edge_tts():
            t = GeminiEdgeVoiceTransport(FakeLLMClient())
            audio = await t.synthesize(
                "Systems online, Sir.", voice="en-GB-ThomasNeural", rate="+0%", volume="+0%", pitch="+0Hz", timeout_s=30
            )
        assert audio == b"\xff\xfb\x90\x00HDRBODY"  # audio chunks concatenated, non-audio skipped
        assert _FakeCommunicate.last["voice"] == "en-GB-ThomasNeural"
        assert _FakeCommunicate.last["text"] == "Systems online, Sir."

    asyncio.run(run())


def t_gemini_synthesize_empty_audio_errors():
    async def run():
        with _fake_edge_tts():
            _FakeCommunicate.chunks = []  # provider returned no audio
            t = GeminiEdgeVoiceTransport(FakeLLMClient())
            try:
                await t.synthesize("hi", voice="en-GB-ThomasNeural", rate="+0%", volume="+0%", pitch="+0Hz", timeout_s=5)
                raise AssertionError("expected VoiceError for empty audio")
            except VoiceError as exc:
                assert exc.stage == "tts"

    asyncio.run(run())


def t_gemini_synthesize_wraps_stream_error():
    async def run():
        with _fake_edge_tts():
            _FakeCommunicate.raise_on_stream = RuntimeError("network down")
            t = GeminiEdgeVoiceTransport(FakeLLMClient())
            try:
                await t.synthesize("hi", voice="en-GB-ThomasNeural", rate="+0%", volume="+0%", pitch="+0Hz", timeout_s=5)
                raise AssertionError("expected VoiceError wrapping the stream failure")
            except VoiceError as exc:
                assert exc.stage == "tts"
                assert "non-fatal" in (exc.fallback or "")

    asyncio.run(run())


def t_gemini_close_does_not_close_llm():
    async def run():
        llm = FakeLLMClient()
        t = GeminiEdgeVoiceTransport(llm)
        await t.close()
        # The orchestrator owns the LLMClient lifecycle; the voice transport must not close it.
        assert llm.closed is False

    asyncio.run(run())


# --------------------------------------------------------------------------
# VoiceError envelope
# --------------------------------------------------------------------------
def t_voice_error_envelope_has_stage():
    exc = VoiceError("boom", stage="stt", status=401, payload={"error": "bad key"}, fallback="fix it")
    env = exc.to_envelope()
    assert env["type"] == "VoiceError"
    assert env["stage"] == "stt"
    assert env["http_status"] == 401
    assert env["provider_payload"] == {"error": "bad key"}
    assert env["fallback"] == "fix it"


def t_voice_error_default_fallback():
    exc = VoiceError("boom", stage="tts")
    assert exc.fallback and "fabricate" in exc.fallback
    assert exc.to_envelope()["stage"] == "tts"


TESTS = [
    ("truncate_short_unchanged", t_truncate_short_unchanged),
    ("truncate_empty", t_truncate_empty),
    ("truncate_collapses_whitespace", t_truncate_collapses_whitespace),
    ("truncate_strips_code_fences", t_truncate_strips_code_fences),
    ("truncate_strips_inline_backticks", t_truncate_strips_inline_backticks),
    ("truncate_caps_at_word_boundary", t_truncate_caps_at_word_boundary),
    ("truncate_zero_max_returns_all_cleaned", t_truncate_zero_max_returns_all_cleaned),
    ("audio_format_maps_mime", t_audio_format_maps_mime),
    ("config_stt_disabled_without_key", t_config_stt_disabled_without_key),
    ("config_stt_enabled_with_key", t_config_stt_enabled_with_key),
    ("config_tts_is_keyless", t_config_tts_is_keyless),
    ("should_speak_mirror", t_should_speak_mirror),
    ("should_speak_always", t_should_speak_always),
    ("should_speak_off", t_should_speak_off),
    ("client_stt_guard_without_key", t_client_stt_guard_without_key),
    ("client_tts_guard_when_off", t_client_tts_guard_when_off),
    ("client_transcribe_passes_config_through", t_client_transcribe_passes_config_through),
    ("client_transcribe_resolves_tier_and_falls_back", t_client_transcribe_resolves_tier_and_falls_back),
    ("client_synthesize_truncates_and_returns_bytes", t_client_synthesize_truncates_and_returns_bytes),
    ("client_synthesize_empty_answer_skips", t_client_synthesize_empty_answer_skips),
    ("gemini_transcribe_builds_input_audio", t_gemini_transcribe_builds_input_audio),
    ("gemini_transcribe_wraps_llmerror", t_gemini_transcribe_wraps_llmerror),
    ("gemini_transcribe_rejects_empty_audio", t_gemini_transcribe_rejects_empty_audio),
    ("gemini_transcribe_timeout", t_gemini_transcribe_timeout),
    ("gemini_synthesize_streams_mp3", t_gemini_synthesize_streams_mp3),
    ("gemini_synthesize_empty_audio_errors", t_gemini_synthesize_empty_audio_errors),
    ("gemini_synthesize_wraps_stream_error", t_gemini_synthesize_wraps_stream_error),
    ("gemini_close_does_not_close_llm", t_gemini_close_does_not_close_llm),
    ("voice_error_envelope_has_stage", t_voice_error_envelope_has_stage),
    ("voice_error_default_fallback", t_voice_error_default_fallback),
]


def main() -> int:
    print(f"\nHermes-Prime voice suite ({len(TESTS)} cases)\n" + "-" * 50)
    for name, fn in TESTS:
        check(name, fn)
    print("-" * 50)
    print(f"  {len(PASSED)} passed, {len(FAILED)} failed")
    for n, e in FAILED:
        print(f"    - {n}: {e}")
    return 1 if FAILED else 0


# pytest bridge: expose each case as a module-level test_* function.
for _name, _fn in TESTS:
    globals()[f"test_{_name}"] = _fn
del _name, _fn


if __name__ == "__main__":
    raise SystemExit(main())
